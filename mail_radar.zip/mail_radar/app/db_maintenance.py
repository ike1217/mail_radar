from __future__ import annotations

from collections import defaultdict

from sqlalchemy import inspect, select, text

from .db import SessionLocal, engine
from .models import MailAccount


def repair_duplicate_mail_accounts() -> int:
    """Remove duplicate mailbox rows left by older Mail Radar builds.

    Fresh databases enforce a unique provider/email/folder constraint. Older
    databases may predate that constraint, so upgrading in-place can otherwise
    show the same mailbox card more than once. We keep the most recently
    updated row (then the highest id as a tie-breaker).
    """
    db = SessionLocal()
    removed = 0
    try:
        accounts = list(db.scalars(select(MailAccount)))
        groups: dict[tuple[str, str, str], list[MailAccount]] = defaultdict(list)
        for account in accounts:
            key = (
                (account.provider or '').strip().lower(),
                (account.email or '').strip().lower(),
                (account.folder or 'INBOX').strip().upper(),
            )
            groups[key].append(account)

        for items in groups.values():
            if len(items) < 2:
                continue
            items.sort(
                key=lambda a: (
                    a.updated_at or a.created_at,
                    a.id,
                ),
                reverse=True,
            )
            for duplicate in items[1:]:
                db.delete(duplicate)
                removed += 1
        if removed:
            db.commit()
        return removed
    finally:
        db.close()


def ensure_timetable_event_schema() -> bool:
    """Upgrade older local databases with fields used by manual calendar editing."""
    inspector = inspect(engine)
    if 'timetable_events' not in inspector.get_table_names():
        return False
    columns = {column['name'] for column in inspector.get_columns('timetable_events')}
    if 'event_kind' in columns:
        return False
    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE timetable_events ADD COLUMN event_kind VARCHAR(32) NOT NULL DEFAULT 'class'"))
    return True
