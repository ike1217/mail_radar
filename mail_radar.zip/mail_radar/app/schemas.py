from __future__ import annotations

from datetime import date, datetime, time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Category = Literal['school', 'activity', 'career', 'ignore']


class IngestTextRequest(BaseModel):
    subject: str = ''
    sender: str = ''
    body: str
    body_type: Literal['text', 'html'] = 'text'
    received_at: datetime | None = None
    source_url: str | None = None
    graph_message_id: str | None = None
    source_provider: str = 'manual'
    source_account: str | None = None
    force_llm_review: bool = False


class NoticeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    category: str
    subcategory: str
    organizer: str | None
    source_subject: str
    source_sender: str
    source_date: datetime | None
    source_provider: str
    source_account: str | None
    event_date: datetime | None
    deadline: datetime | None
    location: str | None
    language: str
    action_required: bool
    registration_required: bool
    company_name: str | None
    company_size: str
    job_scope: str
    priority: float
    rank_score: float
    summary: str
    url: str | None

    rule_category: str
    rule_subcategory: str
    rule_confidence: float
    rule_reason: str
    llm_reviewed: bool
    llm_category: str | None
    llm_subcategory: str | None
    llm_confidence: float | None
    llm_reason: str | None
    llm_error: str | None
    decision_source: str
    privacy_redacted: bool


class DashboardOut(BaseModel):
    school: list[NoticeOut]
    activity: list[NoticeOut]
    career: list[NoticeOut]
    ignored_count: int
    llm_reviewed_count: int
    total_count: int


class UpdateNoticeRequest(BaseModel):
    category: Category | None = None
    subcategory: str | None = None
    event_date: datetime | None = None
    deadline: datetime | None = None
    location: str | None = None
    language: str | None = None
    company_name: str | None = None
    company_size: Literal['large', 'mid', 'startup', 'unknown'] | None = None
    job_scope: Literal['internal', 'external', 'unknown'] | None = None
    action_required: bool | None = None
    registration_required: bool | None = None
    summary: str | None = Field(default=None, max_length=2000)


class AccountOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    provider: str
    provider_label: str | None = None
    email: str
    display_name: str | None = None
    auth_type: str
    host: str | None = None
    port: int | None = None
    folder: str
    enabled: bool
    remember_credentials: bool
    interval_seconds: int
    message_limit: int
    last_sync_at: datetime | None = None
    last_error: str | None = None
    messages_scanned: int
    notices_processed: int
    sync_count: int
    credential_available: bool = False
    sync_mode: str | None = None


class AccountListOut(BaseModel):
    accounts: list[AccountOut]
    connected_count: int
    total_count: int




class BrowserConnectRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    provider: Literal['auto', 'outlook', 'gmail', 'yahoo', 'aol', 'icloud', 'qq', '163', '126', 'zoho', 'fastmail', 'proton', 'yandex', 'gmx', 'mailcom', 'custom']
    custom_url: str | None = Field(default=None, max_length=2000)
    interval_seconds: int = Field(default=300, ge=60, le=3600)
    message_limit: int = Field(default=30, ge=1, le=100)

class MicrosoftConnectRequest(BaseModel):
    client_id: str | None = Field(default=None, max_length=200)
    tenant_id: str | None = Field(default=None, max_length=200)
    login_hint: str | None = Field(default=None, max_length=320)
    interval_seconds: int = Field(default=300, ge=60, le=3600)
    message_limit: int = Field(default=100, ge=1, le=200)
    remember_app_setup: bool = True


class GmailConnectRequest(BaseModel):
    # Paste the contents of Google's OAuth desktop-client JSON here on first setup.
    client_config_json: str | None = Field(default=None, max_length=20000, repr=False)
    interval_seconds: int = Field(default=300, ge=60, le=3600)
    message_limit: int = Field(default=100, ge=1, le=500)
    remember_client_config: bool = True


class IMAPConnectRequest(BaseModel):
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=1024, repr=False)
    provider: Literal[
        'auto', 'gmail', 'icloud', 'yahoo', 'outlook', 'qq', '163', '126', 'zoho', 'fastmail', 'custom'
    ] = 'auto'
    imap_host: str | None = Field(default=None, max_length=255)
    imap_port: int = Field(default=993, ge=1, le=65535)
    username: str | None = Field(default=None, max_length=320)
    folder: str = Field(default='INBOX', min_length=1, max_length=255)
    interval_seconds: int = Field(default=300, ge=60, le=3600)
    message_limit: int = Field(default=100, ge=1, le=500)
    remember_password: bool = True


class DeepSeekSettingsIn(BaseModel):
    enabled: bool
    api_key: str | None = Field(default=None, max_length=512, repr=False)
    model: str = Field(default='deepseek-flash', max_length=120)


class DeepSeekSettingsOut(BaseModel):
    enabled: bool
    api_key_configured: bool
    model: str


class CalendarEventOut(BaseModel):
    id: str
    title: str
    start_at: datetime
    end_at: datetime
    all_day: bool = False
    location: str | None = None
    details: str | None = None
    kind: str
    category: str | None = None
    course_code: str | None = None
    source: str | None = None
    source_sender: str | None = None
    source_account: str | None = None
    source_notice_id: int | None = None
    url: str | None = None
    color: str | None = None
    editable: bool = False


class CalendarOut(BaseModel):
    events: list[CalendarEventOut]


class TimetableOut(BaseModel):
    events: list[CalendarEventOut]


class ManualClassIn(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    course_code: str | None = Field(default=None, max_length=80)
    weekday: int = Field(ge=0, le=6)  # Monday=0
    start_time: time
    end_time: time
    location: str | None = Field(default=None, max_length=255)
    details: str | None = Field(default=None, max_length=2000)


class ManualExamIn(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    course_code: str | None = Field(default=None, max_length=80)
    exam_date: date
    start_time: time
    end_time: time
    location: str | None = Field(default=None, max_length=255)
    details: str | None = Field(default=None, max_length=2000)


class ManualWeekIn(BaseModel):
    week_start: date
    repeat_weeks: int = Field(default=1, ge=1, le=52)
    classes: list[ManualClassIn] = Field(default_factory=list, max_length=40)
    exam: ManualExamIn | None = None


class ManualWeekOut(BaseModel):
    created_count: int
    skipped_duplicates: int
    class_count: int
    exam_count: int
