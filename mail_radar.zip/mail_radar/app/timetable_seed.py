"""Compatibility helpers for older imports.

Mail Radar 7.2 intentionally ships with no personal timetable data. Calendar/class
records belong to each device/user's local database and are never embedded in the
source package.
"""
from __future__ import annotations

from sqlalchemy.orm import Session


def default_timetable_events() -> list[dict]:
    return []


def seed_default_timetable(db: Session) -> None:
    return None
