from __future__ import annotations

from datetime import timezone, tzinfo
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def get_timezone(name: str | None) -> tzinfo:
    """Return an IANA timezone, falling back safely to UTC.

    Python on Windows does not ship the IANA timezone database. The project
    depends on ``tzdata`` so normal installations resolve names such as
    ``Asia/Hong_Kong``. This fallback prevents email synchronization from
    crashing even if the timezone package is missing or a custom timezone name
    is invalid.
    """
    candidate = (name or "UTC").strip() or "UTC"
    try:
        return ZoneInfo(candidate)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        try:
            return ZoneInfo("UTC")
        except Exception:
            return timezone.utc
