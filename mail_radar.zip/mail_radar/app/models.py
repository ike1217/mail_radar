from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class Notice(Base):
    __tablename__ = 'notices'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    fingerprint: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    graph_message_id: Mapped[str | None] = mapped_column(String(512), nullable=True, index=True)

    source_provider: Mapped[str] = mapped_column(String(32), default='manual', index=True)
    source_account: Mapped[str | None] = mapped_column(String(320), nullable=True, index=True)

    title: Mapped[str] = mapped_column(String(500), index=True)
    category: Mapped[str] = mapped_column(String(32), index=True)
    subcategory: Mapped[str] = mapped_column(String(80), default='general')

    organizer: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source_subject: Mapped[str] = mapped_column(String(500), default='')
    source_sender: Mapped[str] = mapped_column(String(255), default='')
    source_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    event_date: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    deadline: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    language: Mapped[str] = mapped_column(String(32), default='unknown')

    action_required: Mapped[bool] = mapped_column(Boolean, default=False)
    registration_required: Mapped[bool] = mapped_column(Boolean, default=False)

    company_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    company_size: Mapped[str] = mapped_column(String(32), default='unknown')
    job_scope: Mapped[str] = mapped_column(String(32), default='unknown')

    priority: Mapped[float] = mapped_column(Float, default=0.0)
    rank_score: Mapped[float] = mapped_column(Float, default=0.0)

    rule_category: Mapped[str] = mapped_column(String(32), default='ignore')
    rule_subcategory: Mapped[str] = mapped_column(String(80), default='other')
    rule_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    rule_reason: Mapped[str] = mapped_column(Text, default='')

    llm_reviewed: Mapped[bool] = mapped_column(Boolean, default=False)
    llm_category: Mapped[str | None] = mapped_column(String(32), nullable=True)
    llm_subcategory: Mapped[str | None] = mapped_column(String(80), nullable=True)
    llm_confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    llm_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    llm_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    decision_source: Mapped[str] = mapped_column(String(32), default='rule')
    privacy_redacted: Mapped[bool] = mapped_column(Boolean, default=True)

    summary: Mapped[str] = mapped_column(Text, default='')
    url: Mapped[str | None] = mapped_column(Text, nullable=True)
    raw_text: Mapped[str] = mapped_column(Text, default='')

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class MailAccount(Base):
    __tablename__ = 'mail_accounts'
    __table_args__ = (UniqueConstraint('provider', 'email', 'folder', name='uq_mail_account_provider_email_folder'),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    provider: Mapped[str] = mapped_column(String(32), index=True)  # browser / microsoft / gmail / imap
    email: Mapped[str] = mapped_column(String(320), index=True)
    display_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    auth_type: Mapped[str] = mapped_column(String(32), default='oauth')

    host: Mapped[str | None] = mapped_column(String(255), nullable=True)
    port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    folder: Mapped[str] = mapped_column(String(255), default='INBOX')
    provider_label: Mapped[str | None] = mapped_column(String(80), nullable=True)
    # Non-secret OAuth app identifiers required to reopen provider sessions.
    oauth_client_id: Mapped[str | None] = mapped_column(String(255), nullable=True)
    oauth_tenant_id: Mapped[str | None] = mapped_column(String(255), nullable=True)

    enabled: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    remember_credentials: Mapped[bool] = mapped_column(Boolean, default=True)
    interval_seconds: Mapped[int] = mapped_column(Integer, default=300)
    message_limit: Mapped[int] = mapped_column(Integer, default=100)

    # Provider-specific opaque cursor: Graph deltaLink, Gmail historyId, IMAP UIDVALIDITY:last_uid.
    sync_cursor: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    messages_scanned: Mapped[int] = mapped_column(Integer, default=0)
    notices_processed: Mapped[int] = mapped_column(Integer, default=0)
    sync_count: Mapped[int] = mapped_column(Integer, default=0)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class SyncState(Base):
    __tablename__ = 'sync_state'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    value: Mapped[str] = mapped_column(Text, default='')
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class TimetableEvent(Base):
    __tablename__ = 'timetable_events'

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_kind: Mapped[str] = mapped_column(String(32), default='class', index=True)
    title: Mapped[str] = mapped_column(String(255), index=True)
    course_code: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    start_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    location: Mapped[str | None] = mapped_column(String(255), nullable=True)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    color: Mapped[str | None] = mapped_column(String(32), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
