from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from .config import get_settings
from .db import Base, engine, get_db
from .db_maintenance import ensure_timetable_event_schema, repair_duplicate_mail_accounts
from .routers import accounts, ingest, notices, settings as settings_router, calendar
from .seed import seed_demo
from .services.account_manager import account_manager
from .services.ai_config import effective_ai_config

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    ensure_timetable_event_schema()
    repair_duplicate_mail_accounts()
    account_manager.start()
    yield
    account_manager.stop()


app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)
app.include_router(ingest.router)
app.include_router(notices.router)
app.include_router(accounts.router)
app.include_router(settings_router.router)
app.include_router(calendar.router)

WEB_DIR = Path(__file__).resolve().parent.parent / 'web'
app.mount('/static', StaticFiles(directory=WEB_DIR), name='static')


@app.get('/api/health')
def health():
    account_state = account_manager.list_accounts()
    return {
        'ok': True,
        'app': settings.app_name,
        'version': settings.app_version,
        'deepseek_enabled': effective_ai_config().enabled,
        'connected_accounts': account_state['connected_count'],
        'total_accounts': account_state['total_count'],
    }


@app.post('/api/demo/seed')
def demo_seed(db: Session = Depends(get_db)):
    seed_demo(db)
    return {'ok': True}


@app.get('/', include_in_schema=False)
def root():
    return FileResponse(WEB_DIR / 'index.html')
