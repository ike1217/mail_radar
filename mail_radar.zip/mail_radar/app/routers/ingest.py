from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..db import get_db
from ..schemas import IngestTextRequest, NoticeOut
from ..services.pipeline import ingest_email

router = APIRouter(prefix="/api/ingest", tags=["ingest"])


@router.post("/text", response_model=list[NoticeOut])
def ingest_text(payload: IngestTextRequest, db: Session = Depends(get_db)):
    return ingest_email(
        db=db,
        subject=payload.subject,
        sender=payload.sender,
        body=payload.body,
        body_type=payload.body_type,
        received_at=payload.received_at,
        source_url=payload.source_url,
        graph_message_id=payload.graph_message_id,
        force_llm_review=payload.force_llm_review,
        source_provider=payload.source_provider,
        source_account=payload.source_account,
    )
