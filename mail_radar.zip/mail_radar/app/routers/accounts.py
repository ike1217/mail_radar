from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..schemas import BrowserConnectRequest, GmailConnectRequest, IMAPConnectRequest, MicrosoftConnectRequest
from ..services.account_manager import account_manager

router = APIRouter(prefix='/api/accounts', tags=['mail-accounts'])


def _http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, KeyError):
        return HTTPException(status_code=404, detail=str(exc).strip("'"))
    return HTTPException(status_code=400, detail=str(exc))


@router.get('')
def list_accounts():
    return account_manager.list_accounts()


@router.get('/setup')
def setup_status():
    return account_manager.provider_setup_status()




@router.get('/browser/providers')
def browser_providers():
    return {'providers': account_manager.browser_provider_options()}


@router.post('/browser/connect')
def connect_browser(payload: BrowserConnectRequest):
    try:
        return account_manager.connect_browser(
            email=payload.email,
            provider=payload.provider,
            custom_url=payload.custom_url,
            interval_seconds=payload.interval_seconds,
            message_limit=payload.message_limit,
        )
    except Exception as exc:
        raise _http_error(exc) from exc

@router.post('/microsoft/connect')
def connect_microsoft(payload: MicrosoftConnectRequest):
    try:
        return account_manager.connect_microsoft(
            client_id=payload.client_id,
            tenant_id=payload.tenant_id,
            login_hint=payload.login_hint,
            interval_seconds=payload.interval_seconds,
            message_limit=payload.message_limit,
            remember_app_setup=payload.remember_app_setup,
        )
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/gmail/connect')
def connect_gmail(payload: GmailConnectRequest):
    try:
        return account_manager.connect_gmail(
            client_config_json=payload.client_config_json,
            interval_seconds=payload.interval_seconds,
            message_limit=payload.message_limit,
            remember_client_config=payload.remember_client_config,
        )
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/imap/connect')
def connect_imap(payload: IMAPConnectRequest):
    try:
        return account_manager.connect_imap(
            email=payload.email,
            password=payload.password,
            provider=payload.provider,
            host=payload.imap_host,
            port=payload.imap_port,
            username=payload.username,
            folder=payload.folder,
            interval_seconds=payload.interval_seconds,
            message_limit=payload.message_limit,
            remember_password=payload.remember_password,
        )
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/sync-all')
def sync_all():
    try:
        return account_manager.sync_all()
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/reconnect-browser')
def reconnect_browser(account_id: int):
    try:
        return account_manager.reconnect_browser(account_id)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/sync-visible')
def sync_browser_visible(account_id: int):
    try:
        return account_manager.sync_browser_visible(account_id)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/sync')
def sync_account(account_id: int):
    try:
        return account_manager.sync_account(account_id)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/rescan')
def rescan_account(account_id: int):
    try:
        return account_manager.sync_account(account_id, force_full=True)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/enable')
def enable_account(account_id: int):
    try:
        return account_manager.set_enabled(account_id, True)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.post('/{account_id}/pause')
def pause_account(account_id: int):
    try:
        return account_manager.set_enabled(account_id, False)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.delete('/{account_id}')
def remove_account(account_id: int):
    try:
        account_manager.remove_account(account_id)
        return {'ok': True}
    except Exception as exc:
        raise _http_error(exc) from exc
