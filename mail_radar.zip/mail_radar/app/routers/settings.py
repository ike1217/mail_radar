from __future__ import annotations

from fastapi import APIRouter

from ..schemas import DeepSeekSettingsIn, DeepSeekSettingsOut
from ..services.ai_config import effective_ai_config, save_ai_config

router = APIRouter(prefix='/api/settings', tags=['settings'])


@router.get('/ai', response_model=DeepSeekSettingsOut)
def get_ai_settings():
    config = effective_ai_config()
    return DeepSeekSettingsOut(enabled=config.enabled, api_key_configured=bool(config.api_key), model=config.model)


@router.post('/ai', response_model=DeepSeekSettingsOut)
def update_ai_settings(payload: DeepSeekSettingsIn):
    save_ai_config(enabled=payload.enabled, model=payload.model, api_key=payload.api_key)
    config = effective_ai_config()
    return DeepSeekSettingsOut(enabled=config.enabled, api_key_configured=bool(config.api_key), model=config.model)
