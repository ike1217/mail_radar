from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..models import Notice
from ..schemas import DashboardOut, NoticeOut, UpdateNoticeRequest
from ..services.ranker import activity_sort_key, career_sort_key, compute_priority, school_sort_key

router = APIRouter(prefix="/api", tags=["notices"])


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(db: Session = Depends(get_db)):
    notices = list(db.scalars(select(Notice)).all())
    school = sorted((n for n in notices if n.category == "school"), key=school_sort_key)
    activity = sorted((n for n in notices if n.category == "activity"), key=activity_sort_key)
    career = sorted((n for n in notices if n.category == "career"), key=career_sort_key)
    ignored = sum(1 for n in notices if n.category == "ignore")
    return DashboardOut(school=school, activity=activity, career=career, ignored_count=ignored, llm_reviewed_count=sum(1 for n in notices if n.llm_reviewed), total_count=len(notices))


@router.get("/notices", response_model=list[NoticeOut])
def list_notices(category: str | None = None, db: Session = Depends(get_db)):
    stmt = select(Notice)
    if category:
        stmt = stmt.where(Notice.category == category)
    return list(db.scalars(stmt.order_by(Notice.id.desc())).all())


@router.patch("/notices/{notice_id}", response_model=NoticeOut)
def update_notice(notice_id: int, payload: UpdateNoticeRequest, db: Session = Depends(get_db)):
    n = db.get(Notice, notice_id)
    if not n:
        raise HTTPException(404, "Notice not found")
    data = payload.model_dump(exclude_unset=True)
    for key, value in data.items():
        setattr(n, key, value)
    settings = get_settings()
    n.priority = compute_priority(n.category, n.subcategory, n.deadline, n.event_date, n.action_required, n.company_size, settings.timezone)
    n.rank_score = n.priority
    n.decision_source = "manual"
    db.commit()
    db.refresh(n)
    return n


@router.delete("/notices/{notice_id}")
def delete_notice(notice_id: int, db: Session = Depends(get_db)):
    n = db.get(Notice, notice_id)
    if not n:
        raise HTTPException(404, "Notice not found")
    db.delete(n)
    db.commit()
    return {"ok": True}


@router.delete("/notices")
def clear_notices(db: Session = Depends(get_db)):
    db.execute(delete(Notice))
    db.commit()
    return {"ok": True}
