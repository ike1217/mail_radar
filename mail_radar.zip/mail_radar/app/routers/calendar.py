from __future__ import annotations

import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..schemas import CalendarOut, ManualWeekIn, ManualWeekOut, TimetableOut
from ..services.calendar_service import calendar_events
from ..services.timetable_service import clear_timetable, create_manual_week, delete_timetable_event

router = APIRouter(prefix='/api', tags=['calendar'])
_MANUAL_EVENT_ID = re.compile(r'^(?:class|exam)-(\d+)$')


@router.get('/calendar/events', response_model=CalendarOut)
def get_calendar_events(db: Session = Depends(get_db)):
    return {'events': calendar_events(db)}


@router.post('/timetable/week', response_model=ManualWeekOut)
def add_manual_week(payload: ManualWeekIn, db: Session = Depends(get_db)):
    try:
        return create_manual_week(db, payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.delete('/calendar/events/{event_id}')
def delete_manual_calendar_event(event_id: str, db: Session = Depends(get_db)):
    match = _MANUAL_EVENT_ID.match(event_id)
    if not match:
        raise HTTPException(status_code=400, detail='Only manually added classes and exams can be deleted here.')
    if not delete_timetable_event(db, int(match.group(1))):
        raise HTTPException(status_code=404, detail='Calendar event not found.')
    return {'ok': True}


@router.delete('/timetable')
def clear_manual_timetable(db: Session = Depends(get_db)):
    return {'ok': True, 'deleted_count': clear_timetable(db)}


@router.get('/timetable', response_model=TimetableOut)
def get_timetable_compat(db: Session = Depends(get_db)):
    """Backward-compatible alias used by older frontends/tests."""
    events = [e for e in calendar_events(db) if e['kind'] == 'class']
    return {'events': events}
