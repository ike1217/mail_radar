from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

from .paths import (
    browser_profiles_dir,
    local_config_path,
    secrets_dir,
    sqlite_database_url,
    user_data_dir,
)


class Settings(BaseSettings):
    app_name: str = 'Mail Radar'
    app_version: str = '7.4.0'
    database_url: str = sqlite_database_url()
    timezone: str = 'Asia/Hong_Kong'

    scheduler_tick_seconds: int = 15
    default_sync_interval_seconds: int = 300
    default_initial_message_limit: int = 100

    # Private runtime state is outside the source tree so sharing/copying the code
    # never carries mail history, cookies, tokens, or passwords to another computer.
    browser_profiles_dir: str = str(browser_profiles_dir())
    browser_channel: str = ''
    browser_login_timeout_seconds: int = 300
    browser_headless_sync: bool = True
    browser_max_messages_per_sync: int = 100
    browser_page_settle_ms: int = 4500
    browser_open_message_wait_ms: int = 1200
    browser_back_wait_ms: int = 900
    browser_row_wait_ms: int = 15000

    graph_client_id: str = ''
    graph_tenant_id: str = 'organizations'
    graph_scopes: str = 'User.Read Mail.Read offline_access'
    graph_cache_file: str = str(secrets_dir() / 'microsoft_token_cache.bin')
    graph_cache_key_file: str = str(secrets_dir() / 'microsoft_token_cache.key')
    graph_delta_lookback_minutes: int = 5

    google_scopes: str = 'https://www.googleapis.com/auth/gmail.readonly openid https://www.googleapis.com/auth/userinfo.email'
    google_client_cache_file: str = str(secrets_dir() / 'google_client_config.bin')
    google_client_cache_key_file: str = str(secrets_dir() / 'google_client_config.key')

    credential_vault_file: str = str(secrets_dir() / 'credential_vault.bin')
    credential_vault_key_file: str = str(secrets_dir() / 'credential_vault.key')

    deepseek_enabled: bool = False
    deepseek_api_key: str = ''
    deepseek_base_url: str = 'https://api.deepseek.com'
    deepseek_model: str = 'deepseek-flash'
    deepseek_timeout_seconds: int = 35
    deepseek_max_tokens: int = 1200
    llm_confidence_threshold: float = 0.80
    llm_review_high_impact: bool = True
    llm_send_raw_email: bool = False

    university_domains: str = 'hku.hk,connect.hku.hk,info.hku.hk'

    # .env remains an advanced developer override only. The launcher does not create it.
    model_config = SettingsConfigDict(env_file=str(user_data_dir() / '.env'), env_file_encoding='utf-8', extra='ignore')

    @property
    def data_dir(self) -> Path:
        return user_data_dir()

    @property
    def graph_scope_list(self) -> list[str]:
        return [
            x.strip()
            for x in self.graph_scopes.split()
            if x.strip() and x.strip() not in {'openid', 'profile', 'offline_access'}
        ]

    @property
    def google_scope_list(self) -> list[str]:
        return [x.strip() for x in self.google_scopes.split() if x.strip()]

    @property
    def university_domain_list(self) -> list[str]:
        return [x.strip().lower() for x in self.university_domains.split(',') if x.strip()]

    @property
    def graph_cache_path(self) -> Path:
        return Path(self.graph_cache_file)

    @property
    def graph_cache_key_path(self) -> Path:
        return Path(self.graph_cache_key_file)

    @property
    def google_client_cache_path(self) -> Path:
        return Path(self.google_client_cache_file)

    @property
    def google_client_cache_key_path(self) -> Path:
        return Path(self.google_client_cache_key_file)

    @property
    def credential_vault_path(self) -> Path:
        return Path(self.credential_vault_file)

    @property
    def credential_vault_key_path(self) -> Path:
        return Path(self.credential_vault_key_file)


def load_local_config() -> dict:
    path = local_config_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_local_config(updates: dict) -> None:
    path = local_config_path()
    data = load_local_config()
    data.update(updates)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def save_local_graph_config(client_id: str, tenant_id: str) -> None:
    save_local_config({
        'graph_client_id': client_id.strip(),
        'graph_tenant_id': (tenant_id or 'organizations').strip(),
    })


def effective_graph_config() -> tuple[str, str]:
    settings = get_settings()
    local = load_local_config()
    client_id = (local.get('graph_client_id') or settings.graph_client_id or '').strip()
    tenant_id = (local.get('graph_tenant_id') or settings.graph_tenant_id or 'organizations').strip()
    return client_id, tenant_id


@lru_cache
def get_settings() -> Settings:
    return Settings()
