from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from .timezones import get_timezone

from .services.pipeline import ingest_email


DEMO_DAILY = """
HKU Daily Notices
Today's Highlights
Last Chance to Redeem a Gift: Register for HKU Facial Identity Access and Receive a Souvenir!
Information Technology Services | 27 SEP 2026
Equal Opportunity Festival 2026 | Understanding and Preventing Sexual Harassment on Campus
Equal Opportunity Unit | 29 SEP 2026
Body Banter - Bring it to the Table: Beauty Standards in Hong Kong
School of Humanities | 15 SEP 2026
Extending the ‘Withering Rights’ Thesis: Settlor Reserved Powers and Limited Judicial Review (Oct 26)
Centre for Private Law | 9 SEP 2026
Register Now! PHARM+Excellence 2026 Conference (31 Oct 2026) | HKU Pharmacy
Department of Pharmacology and Pharmacy | 16 SEP 2026
"""

DEMO_OPERATIONAL = """
COMP7404 lecture venue change. Tomorrow's lecture has been relocated to Room CPD-LG.18.
Please check the updated timetable before class.
"""

DEMO_ASSIGNMENT = """
Assignment 2 submission reminder. Please submit your coursework by 3 Oct 2026.
Submission is required via Moodle.
"""

DEMO_JOB_1 = """
Microsoft Software Engineer Internship 2027. Applications are now open. Apply by 15 Oct 2026.
"""

DEMO_JOB_2 = """
Student Research Assistant position available at HKU. Apply by 7 Oct 2026. Part-time appointment.
"""


def seed_demo(db: Session):
    tz = get_timezone("Asia/Hong_Kong")
    received = datetime(2026, 9, 29, 18, 10, tzinfo=tz)
    ingest_email(db, "HKU Daily Notices (29 SEP 2026)", "bulkemail@info.hku.hk", DEMO_DAILY, "text", received)
    ingest_email(db, "Urgent: COMP7404 venue change", "cs@hku.hk", DEMO_OPERATIONAL, "text", datetime(2026, 10, 2, 9, 0, tzinfo=tz))
    ingest_email(db, "Assignment 2 reminder", "teacher@hku.hk", DEMO_ASSIGNMENT, "text", datetime(2026, 10, 2, 10, 0, tzinfo=tz))
    ingest_email(db, "Microsoft Internship", "careers@hku.hk", DEMO_JOB_1, "text", datetime(2026, 10, 2, 11, 0, tzinfo=tz))
    ingest_email(db, "HKU Student Research Assistant", "department@hku.hk", DEMO_JOB_2, "text", datetime(2026, 10, 2, 12, 0, tzinfo=tz))
