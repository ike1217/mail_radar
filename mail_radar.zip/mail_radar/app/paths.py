from __future__ import annotations

import os
import platform
from pathlib import Path

APP_DIR_NAME = 'MailRadar'


def user_data_dir() -> Path:
    """Return a per-OS-user data directory that is never inside the source tree.

    Override with MAIL_RADAR_DATA_DIR for tests or advanced deployments.
    """
    override = os.environ.get('MAIL_RADAR_DATA_DIR', '').strip()
    if override:
        path = Path(override).expanduser().resolve()
    elif os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or os.environ.get('APPDATA')
        path = Path(base) / APP_DIR_NAME if base else Path.home() / 'AppData' / 'Local' / APP_DIR_NAME
    elif platform.system() == 'Darwin':
        path = Path.home() / 'Library' / 'Application Support' / APP_DIR_NAME
    else:
        base = os.environ.get('XDG_DATA_HOME')
        path = (Path(base) if base else Path.home() / '.local' / 'share') / 'mail_radar'
    path.mkdir(parents=True, exist_ok=True)
    return path


def database_path() -> Path:
    return user_data_dir() / 'mail_radar.db'


def sqlite_database_url() -> str:
    # SQLAlchemy accepts sqlite:///C:/... on Windows and sqlite:////home/... on POSIX.
    return 'sqlite:///' + database_path().as_posix()


def browser_profiles_dir() -> Path:
    path = user_data_dir() / 'browser_profiles'
    path.mkdir(parents=True, exist_ok=True)
    return path


def secrets_dir() -> Path:
    path = user_data_dir() / 'secrets'
    path.mkdir(parents=True, exist_ok=True)
    return path


def local_config_path() -> Path:
    return user_data_dir() / 'config.json'


def logs_dir() -> Path:
    path = user_data_dir() / 'logs'
    path.mkdir(parents=True, exist_ok=True)
    return path
