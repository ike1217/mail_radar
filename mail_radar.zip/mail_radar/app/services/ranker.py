from __future__ import annotations

from datetime import datetime

from ..timezones import get_timezone


SCHOOL_BASE = {
    "class-cancellation": 100,
    "venue-change": 95,
    "exam": 90,
    "assignment": 85,
    "timetable": 75,
    "registration": 70,
    "holiday": 60,
    "admin": 50,
    "it-admin": 35,
    "general": 20,
}

COMPANY_ORDER = {"large": 0, "mid": 1, "startup": 2, "unknown": 3}
SCOPE_ORDER = {"internal": 0, "external": 1, "unknown": 2}
LANGUAGE_ORDER = {"english": 0, "bilingual": 1, "cantonese": 2, "mandarin": 3, "chinese": 4, "unknown": 5}
ACTIVITY_TYPE_ORDER = {"conference": 0, "lecture": 1, "workshop": 2, "competition": 3, "volunteering": 4, "networking": 5, "career-talk": 6, "festival": 7, "wellbeing": 8, "event": 9}


def days_until(dt: datetime | None, now: datetime) -> int | None:
    if not dt:
        return None
    target = dt
    if target.tzinfo is None:
        target = target.replace(tzinfo=now.tzinfo)
    return (target.date() - now.date()).days


def urgency_bonus(deadline: datetime | None, event_date: datetime | None, now: datetime) -> float:
    dt = deadline or event_date
    days = days_until(dt, now)
    if days is None:
        return 0
    if days < 0:
        return -25
    if days == 0:
        return 40
    if days == 1:
        return 30
    if days <= 3:
        return 20
    if days <= 7:
        return 10
    if days <= 14:
        return 5
    return 0


def compute_priority(category: str, subcategory: str, deadline: datetime | None, event_date: datetime | None, action_required: bool, company_size: str, tz_name: str) -> float:
    now = datetime.now(get_timezone(tz_name))
    urgency = urgency_bonus(deadline, event_date, now)

    if category == "school":
        return float(SCHOOL_BASE.get(subcategory, 20) + urgency + (10 if action_required else 0))
    if category == "activity":
        return float(30 + urgency + (5 if action_required else 0))
    if category == "career":
        size_base = {"large": 60, "mid": 45, "startup": 30, "unknown": 20}.get(company_size, 20)
        return float(size_base + urgency + (10 if action_required else 0))
    return 0.0


def school_sort_key(n):
    # Higher priority first; then earliest deadline/event.
    dt = n.deadline or n.event_date or datetime.max
    return (-n.priority, dt, -n.id)


def activity_sort_key(n):
    dt = n.event_date or n.deadline or datetime.max
    return (
        LANGUAGE_ORDER.get(n.language, 99),
        ACTIVITY_TYPE_ORDER.get(n.subcategory, 99),
        dt,
        -n.id,
    )


def career_sort_key(n):
    dt = n.deadline or n.event_date or datetime.max
    return (
        SCOPE_ORDER.get(n.job_scope, 99),
        COMPANY_ORDER.get(n.company_size, 99),
        dt,
        -n.id,
    )
