from __future__ import annotations

from dataclasses import dataclass

from ..config import get_settings, load_local_config, save_local_config
from .secret_vault import secret_vault


@dataclass(slots=True)
class EffectiveAIConfig:
    enabled: bool
    api_key: str
    model: str
    base_url: str
    timeout_seconds: int
    max_tokens: int
    confidence_threshold: float
    review_high_impact: bool
    send_raw_email: bool


API_KEY_NAME = 'deepseek-api-key'


def effective_ai_config() -> EffectiveAIConfig:
    settings = get_settings()
    local = load_local_config()
    saved_key = secret_vault.get(API_KEY_NAME, '')
    enabled = bool(local.get('deepseek_enabled', settings.deepseek_enabled))
    model = str(local.get('deepseek_model') or settings.deepseek_model)
    return EffectiveAIConfig(
        enabled=enabled,
        api_key=str(saved_key or settings.deepseek_api_key or ''),
        model=model,
        base_url=settings.deepseek_base_url,
        timeout_seconds=settings.deepseek_timeout_seconds,
        max_tokens=settings.deepseek_max_tokens,
        confidence_threshold=settings.llm_confidence_threshold,
        review_high_impact=settings.llm_review_high_impact,
        send_raw_email=settings.llm_send_raw_email,
    )


def save_ai_config(*, enabled: bool, model: str, api_key: str | None = None) -> None:
    save_local_config({'deepseek_enabled': bool(enabled), 'deepseek_model': (model or 'deepseek-flash').strip()})
    if api_key is not None and api_key.strip():
        secret_vault.set(API_KEY_NAME, api_key.strip())


def clear_ai_key() -> None:
    secret_vault.delete(API_KEY_NAME)
