from __future__ import annotations

from datetime import date, datetime, timedelta

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import TimetableEvent
from ..schemas import ManualExamIn, ManualWeekIn
from ..timezones import get_timezone

CLASS_COLORS = ['#4f78d8', '#7a63d8', '#3b9f70', '#b7852f', '#5c82a8', '#9a6b8f']
EXAM_COLOR = '#d26a58'


def _week_monday(value: date) -> date:
    return value - timedelta(days=value.weekday())


def _local_datetime(day: date, clock) -> datetime:
    return datetime.combine(day, clock, tzinfo=get_timezone(get_settings().timezone))


def _validate_range(start: datetime, end: datetime, label: str) -> None:
    if end <= start:
        raise ValueError(f'{label}: end time must be after start time.')


def _is_duplicate(db: Session, *, kind: str, title: str, start_at: datetime, end_at: datetime, course_code: str | None) -> bool:
    rows = db.scalars(
        select(TimetableEvent).where(
            TimetableEvent.event_kind == kind,
            TimetableEvent.title == title,
            TimetableEvent.start_at == start_at,
            TimetableEvent.end_at == end_at,
        )
    ).all()
    normalized = (course_code or '').strip().casefold()
    return any(((row.course_code or '').strip().casefold() == normalized) for row in rows)


def _add_exam(db: Session, exam: ManualExamIn) -> tuple[int, int]:
    start = _local_datetime(exam.exam_date, exam.start_time)
    end = _local_datetime(exam.exam_date, exam.end_time)
    _validate_range(start, end, exam.title)
    if _is_duplicate(db, kind='exam', title=exam.title.strip(), start_at=start, end_at=end, course_code=exam.course_code):
        return 0, 1
    db.add(TimetableEvent(
        event_kind='exam',
        title=exam.title.strip(),
        course_code=(exam.course_code or '').strip() or None,
        start_at=start,
        end_at=end,
        location=(exam.location or '').strip() or None,
        details=(exam.details or '').strip() or None,
        color=EXAM_COLOR,
    ))
    return 1, 0


def create_manual_week(db: Session, payload: ManualWeekIn) -> dict:
    if not payload.classes and payload.exam is None:
        raise ValueError('Add at least one class or one exam.')

    monday = _week_monday(payload.week_start)
    created_classes = 0
    created_exams = 0
    skipped = 0

    for week_index in range(payload.repeat_weeks):
        base = monday + timedelta(days=week_index * 7)
        for row_index, item in enumerate(payload.classes):
            day = base + timedelta(days=item.weekday)
            start = _local_datetime(day, item.start_time)
            end = _local_datetime(day, item.end_time)
            _validate_range(start, end, item.title)
            title = item.title.strip()
            course_code = (item.course_code or '').strip() or None
            if _is_duplicate(db, kind='class', title=title, start_at=start, end_at=end, course_code=course_code):
                skipped += 1
                continue
            db.add(TimetableEvent(
                event_kind='class',
                title=title,
                course_code=course_code,
                start_at=start,
                end_at=end,
                location=(item.location or '').strip() or None,
                details=(item.details or '').strip() or None,
                color=CLASS_COLORS[row_index % len(CLASS_COLORS)],
            ))
            created_classes += 1

    if payload.exam is not None:
        created_exams, exam_skipped = _add_exam(db, payload.exam)
        skipped += exam_skipped

    db.commit()
    return {
        'created_count': created_classes + created_exams,
        'skipped_duplicates': skipped,
        'class_count': created_classes,
        'exam_count': created_exams,
    }


def delete_timetable_event(db: Session, event_id: int) -> bool:
    item = db.get(TimetableEvent, event_id)
    if item is None:
        return False
    db.delete(item)
    db.commit()
    return True


def clear_timetable(db: Session) -> int:
    result = db.execute(delete(TimetableEvent))
    db.commit()
    return int(result.rowcount or 0)
