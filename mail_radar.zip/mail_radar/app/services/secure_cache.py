from __future__ import annotations

import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken


class EncryptedFileStore:
    """Small encrypted-at-rest store for the MSAL token cache.

    The encryption key is generated locally on first use. The key and ciphertext are
    intentionally excluded from git. This protects the cache from casual plaintext
    exposure; normal OS account/file permissions remain part of the security model.
    """

    def __init__(self, data_path: Path, key_path: Path):
        self.data_path = Path(data_path)
        self.key_path = Path(key_path)
        self.data_path.parent.mkdir(parents=True, exist_ok=True)
        self.key_path.parent.mkdir(parents=True, exist_ok=True)

    def _key(self) -> bytes:
        if self.key_path.exists():
            return self.key_path.read_bytes().strip()
        key = Fernet.generate_key()
        self.key_path.write_bytes(key)
        try:
            os.chmod(self.key_path, 0o600)
        except OSError:
            pass
        return key

    def read_text(self) -> str:
        if not self.data_path.exists():
            return ''
        try:
            payload = self.data_path.read_bytes()
            if not payload:
                return ''
            return Fernet(self._key()).decrypt(payload).decode('utf-8')
        except (InvalidToken, ValueError, OSError):
            return ''

    def write_text(self, value: str) -> None:
        token = Fernet(self._key()).encrypt(value.encode('utf-8'))
        self.data_path.write_bytes(token)
        try:
            os.chmod(self.data_path, 0o600)
        except OSError:
            pass

    def clear(self) -> None:
        for path in (self.data_path, self.key_path):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
