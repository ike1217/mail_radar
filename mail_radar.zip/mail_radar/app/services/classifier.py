from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(slots=True)
class Classification:
    category: str
    subcategory: str
    confidence: float
    reason: str
    company_name: str | None = None
    company_size: str = "unknown"
    job_scope: str = "unknown"


CAREER_PATTERNS = {
    "internship": ["internship", "intern ", "summer analyst", "off-cycle", "placement", "industrial attachment"],
    "graduate": ["graduate programme", "graduate program", "management trainee", "graduate role"],
    "part-time": ["part-time job", "part time job", "student assistant", "research assistant", "teaching assistant", "vacancy"],
    "career-talk": ["career talk", "employer talk", "recruitment talk", "recruitment event"],
}

SCHOOL_PATTERNS = {
    "class-cancellation": ["class cancelled", "class canceled", "lecture cancelled", "lecture canceled", "teaching cancelled", "class suspension"],
    "venue-change": ["venue change", "room change", "classroom change", "change of venue", "relocated to", "venue has been changed"],
    "timetable": ["timetable", "class schedule", "teaching schedule", "rescheduled", "reschedule"],
    "assignment": ["assignment", "coursework", "submission", "submit your", "due date", "moodle submission"],
    "exam": ["exam", "examination", "assessment venue", "test venue", "quiz venue"],
    "registration": ["course registration", "add/drop", "add drop", "enrolment", "enrollment", "registration period"],
    "holiday": ["public holiday", "university holiday", "teaching suspension", "university closure", "campus closure", "no classes"],
    "it-admin": ["two-factor", "2fa", "mfa", "wifi", "information technology services", "facial identity access", "account activation"],
    "admin": ["student record", "tuition", "fee payment", "student status", "visa", "hall", "accommodation", "registry"],
}

ACTIVITY_PATTERNS = {
    "competition": ["competition", "challenge", "hackathon", "case competition", "contest"],
    "volunteering": ["volunteer", "volunteering", "community service"],
    "conference": ["conference", "symposium", "congress"],
    "workshop": ["workshop", "masterclass", "training session", "bootcamp"],
    "lecture": ["public lecture", "distinguished lecture", "seminar", "webinar", "talk", "thesis"],
    "festival": ["festival", "fair", "carnival"],
    "networking": ["networking", "meet-up", "meetup", "mixer"],
    "wellbeing": ["wellbeing", "well-being", "mental health", "body banter", "sports", "fitness"],
}

IGNORE_PATTERNS = [
    "redeem a gift", "souvenir", "lucky draw", "survey reminder", "promotional offer",
    "unsubscribe", "marketing preference"
]

HIGH_IMPACT_PATTERNS = [
    "deadline", "due ", "apply by", "register by", "registration closes", "closing date",
    "class cancelled", "lecture cancelled", "venue change", "room change", "rescheduled",
    "exam", "assignment", "internship", "vacancy", "job opening", "competition"
]

LARGE_COMPANIES = {
    "microsoft", "google", "alphabet", "amazon", "meta", "apple", "nvidia", "jpmorgan", "jp morgan",
    "goldman sachs", "morgan stanley", "hsbc", "standard chartered", "ubs", "citi", "citibank",
    "bank of america", "barclays", "blackrock", "deloitte", "pwc", "kpmg", "ey", "ernst & young",
    "accenture", "ibm", "oracle", "tencent", "alibaba", "bytedance", "byte dance", "huawei",
    "shell", "bp", "siemens", "tesla", "samsung", "sony", "visa", "mastercard", "bloomberg",
}

MID_COMPANIES = {
    "jane street", "jump trading", "optiver", "citadel securities", "databricks", "cloudflare",
    "canva", "grab", "revolut", "wise", "deliveroo", "foodpanda", "palantir",
}


def _first_match(text: str, mapping: dict[str, list[str]]) -> tuple[str | None, int, list[str]]:
    best_name = None
    best_score = 0
    best_hits: list[str] = []
    for name, kws in mapping.items():
        hits = [kw for kw in kws if kw in text]
        score = len(hits)
        if score > best_score:
            best_name, best_score, best_hits = name, score, hits
    return best_name, best_score, best_hits


def infer_company(title: str, text: str) -> tuple[str | None, str]:
    lower = f"{title} {text}".casefold()
    for company in sorted(LARGE_COMPANIES, key=len, reverse=True):
        if company in lower:
            return company.title(), "large"
    for company in sorted(MID_COMPANIES, key=len, reverse=True):
        if company in lower:
            return company.title(), "mid"

    blob = f"{title} {text}"
    m = re.search(r"(?:internship|graduate programme|graduate program|job|position)\s+(?:at|with)\s+([A-Z][A-Za-z0-9& .'-]{2,60})", blob)
    if m:
        return m.group(1).strip(" .,-"), "unknown"
    m = re.match(r"([A-Z][A-Za-z0-9& .'-]{2,60})\s*[-:|]\s*(?:intern|internship|graduate|career|job)", title)
    if m:
        return m.group(1).strip(), "unknown"
    return None, "unknown"


def _confidence(best: int, second: int, university_sender: bool, category: str) -> float:
    if best <= 0:
        return 0.58 if university_sender and category == "school" else 0.25
    base = 0.68 + min(best, 3) * 0.08
    margin = max(0, best - second) * 0.05
    return max(0.05, min(0.98, base + margin))


def classify(title: str, text: str, organizer: str | None, sender: str, university_domains: list[str]) -> Classification:
    combined = f"{title}\n{text}\n{organizer or ''}\n{sender}".casefold()

    career_sub, career_score, career_hits = _first_match(combined, CAREER_PATTERNS)
    school_sub, school_score, school_hits = _first_match(combined, SCHOOL_PATTERNS)
    activity_sub, activity_score, activity_hits = _first_match(combined, ACTIVITY_PATTERNS)

    is_university_sender = any(domain in sender.casefold() for domain in university_domains)
    internal_job = any(k in combined for k in ["student assistant", "research assistant", "teaching assistant", "hku careers", "university of hong kong"])

    if any(k in combined for k in IGNORE_PATTERNS):
        return Classification("ignore", "promotion", 0.97, "Matched promotional/noise pattern")

    category_scores = {"career": career_score, "school": school_score, "activity": activity_score}
    ranked = sorted(category_scores.items(), key=lambda x: x[1], reverse=True)
    second_score = ranked[1][1]

    if career_score > 0:
        real_job = any(k in combined for k in [
            "internship", "intern ", "graduate programme", "graduate program", "job opening", "vacancy",
            "position available", "student assistant", "research assistant", "teaching assistant", "apply now", "apply by"
        ])
        if career_sub == "career-talk" and not real_job:
            conf = _confidence(max(activity_score, 1), school_score, is_university_sender, "activity")
            return Classification("activity", "career-talk", conf, "Career/recruitment event without a job-opening signal")
        company, size = infer_company(title, text)
        conf = _confidence(career_score, max(school_score, activity_score), is_university_sender, "career")
        return Classification(
            "career", career_sub or "job", conf,
            f"Career keywords: {', '.join(career_hits[:4]) or 'generic career signal'}",
            company_name=company,
            company_size=size,
            job_scope="internal" if internal_job and is_university_sender else "external",
        )

    if school_score > 0:
        conf = _confidence(school_score, activity_score, is_university_sender, "school")
        return Classification("school", school_sub or "general", conf, f"School/academic keywords: {', '.join(school_hits[:4])}")

    if activity_score > 0:
        conf = _confidence(activity_score, school_score, is_university_sender, "activity")
        return Classification("activity", activity_sub or "event", conf, f"Activity keywords: {', '.join(activity_hits[:4])}")

    if is_university_sender:
        return Classification("school", "general", 0.58, "University sender but no strong semantic keyword")

    return Classification("ignore", "other", 0.35, "No supported school/activity/career signal")


def contains_high_impact_signal(title: str, text: str) -> bool:
    blob = f"{title}\n{text}".casefold()
    return any(k in blob for k in HIGH_IMPACT_PATTERNS)
