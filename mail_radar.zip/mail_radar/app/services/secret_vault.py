from __future__ import annotations

import json
import threading
from typing import Any

from ..config import get_settings
from .secure_cache import EncryptedFileStore


class SecretVault:
    """Tiny encrypted JSON key-value vault for local single-user deployments."""

    def __init__(self):
        settings = get_settings()
        self._store = EncryptedFileStore(settings.credential_vault_path, settings.credential_vault_key_path)
        self._lock = threading.RLock()

    def _read(self) -> dict[str, Any]:
        raw = self._store.read_text()
        if not raw:
            return {}
        try:
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _write(self, data: dict[str, Any]) -> None:
        self._store.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')))

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._read().get(key, default)

    def set(self, key: str, value: Any) -> None:
        with self._lock:
            data = self._read()
            data[key] = value
            self._write(data)

    def delete(self, key: str) -> None:
        with self._lock:
            data = self._read()
            if key in data:
                del data[key]
                self._write(data)

    def has(self, key: str) -> bool:
        with self._lock:
            return key in self._read()

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


secret_vault = SecretVault()
