from __future__ import annotations

import hashlib
import re
from datetime import datetime
from urllib.parse import urlparse

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Notice
from ..timezones import get_timezone
from .classifier import Classification, classify
from .deepseek import DeepSeekReviewer, LLMResult
from .extractor import extract_fields, parse_dates
from .llm_router import decide_llm_review
from .privacy_filter import redact_for_llm
from .ranker import compute_priority
from .splitter import NoticeChunk, split_email


def _fingerprint(subject: str, sender: str, title: str, organizer: str | None, source_date: datetime | None, graph_message_id: str | None = None, text: str = "") -> str:
    # Content-first fingerprint intentionally ignores provider-specific message IDs so
    # the same university notice delivered to two connected inboxes collapses to one card.
    normalized_text = re.sub(r"\s+", " ", text).strip().casefold()[:240]
    payload = "|".join([
        subject.strip().casefold(), sender.strip().casefold(), title.strip().casefold(),
        (organizer or "").strip().casefold(), source_date.isoformat() if source_date else "", normalized_text,
    ])
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _summary(title: str, text: str, subcategory: str) -> str:
    clean = re.sub(r"\s+", " ", text).strip()
    if clean.casefold().startswith(title.casefold()):
        clean = clean[len(title):].strip(" -|:\n")
    if not clean:
        return f"{subcategory.replace('-', ' ').title()} notice."
    if len(clean) > 320:
        clean = clean[:317].rstrip() + "..."
    return clean


def _posted_date_from_chunk(chunk: NoticeChunk, received_at: datetime | None, tz_name: str) -> datetime | None:
    if not chunk.posted_date_text:
        return received_at
    dates = parse_dates(chunk.posted_date_text, received_at, tz_name)
    return dates[0][0] if dates else received_at


def _sender_domain(sender: str) -> str:
    if "@" in sender:
        return sender.rsplit("@", 1)[-1].lower().strip()
    try:
        return urlparse(sender).hostname or ""
    except Exception:
        return ""


def _parse_iso_date(value: str | None, tz_name: str) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(hour=12, minute=0, second=0, microsecond=0, tzinfo=get_timezone(tz_name))
        return dt
    except ValueError:
        return None


def _rule_payload(c: Classification) -> dict:
    return {
        "category": c.category,
        "subcategory": c.subcategory,
        "confidence": round(c.confidence, 4),
        "reason": c.reason,
        "company_name": c.company_name,
        "company_size": c.company_size,
        "job_scope": c.job_scope,
    }


def ingest_email(
    db: Session,
    subject: str,
    sender: str,
    body: str,
    body_type: str = "text",
    received_at: datetime | None = None,
    source_url: str | None = None,
    graph_message_id: str | None = None,
    force_llm_review: bool = False,
    source_provider: str = "manual",
    source_account: str | None = None,
) -> list[Notice]:
    settings = get_settings()
    received_at = received_at or datetime.now(get_timezone(settings.timezone))
    chunks = split_email(subject, body, body_type, source_url)
    created: list[Notice] = []

    for chunk in chunks:
        rule = classify(chunk.title, chunk.text, chunk.organizer, sender, settings.university_domain_list)
        extracted = extract_fields(chunk.text, chunk.title, received_at, settings.timezone)
        source_date = _posted_date_from_chunk(chunk, received_at, settings.timezone)
        fp = _fingerprint(subject, sender, chunk.title, chunk.organizer, source_date, graph_message_id, chunk.text)

        existing = db.scalar(select(Notice).where(Notice.fingerprint == fp))
        if existing:
            created.append(existing)
            continue

        final_category = rule.category
        final_subcategory = rule.subcategory
        company_name = rule.company_name
        company_size = rule.company_size
        job_scope = rule.job_scope
        title = chunk.title
        summary = _summary(chunk.title, chunk.text, rule.subcategory)
        event_date = extracted.event_date
        deadline = extracted.deadline
        location = extracted.location
        language = extracted.language
        action_required = extracted.action_required
        registration_required = extracted.registration_required

        llm_reviewed = False
        llm_result: LLMResult | None = None
        llm_error: str | None = None
        decision_source = "rule"
        redacted_text, was_redacted = redact_for_llm(chunk.text)
        review_decision = decide_llm_review(rule, chunk.title, chunk.text, force_llm_review)

        if review_decision.should_review:
            try:
                llm_reviewed = True
                llm_result = DeepSeekReviewer().review(
                    title=chunk.title,
                    organizer=chunk.organizer,
                    sender_domain=_sender_domain(sender),
                    text=chunk.text if settings.llm_send_raw_email else redacted_text,
                    rule_result=_rule_payload(rule),
                )
                # LLM is a second-pass reviewer, not an unquestionable source.
                if llm_result.confidence >= 0.65:
                    decision_source = "llm"
                    final_category = llm_result.category
                    final_subcategory = llm_result.subcategory
                    title = llm_result.title or title
                    summary = llm_result.summary or summary
                    event_date = _parse_iso_date(llm_result.event_date, settings.timezone) or event_date
                    deadline = _parse_iso_date(llm_result.deadline, settings.timezone) or deadline
                    location = llm_result.location or location
                    language = llm_result.language if llm_result.language != "unknown" else language
                    company_name = llm_result.company_name or company_name
                    company_size = llm_result.company_size if llm_result.company_size != "unknown" else company_size
                    job_scope = llm_result.job_scope if llm_result.job_scope != "unknown" else job_scope
                    action_required = llm_result.action_required or action_required
                    registration_required = llm_result.registration_required or registration_required
            except Exception as exc:  # API failure must not block email ingestion.
                llm_reviewed = True
                llm_error = f"{type(exc).__name__}: {exc}"[:2000]

        priority = compute_priority(
            category=final_category,
            subcategory=final_subcategory,
            deadline=deadline,
            event_date=event_date,
            action_required=action_required,
            company_size=company_size,
            tz_name=settings.timezone,
        )

        notice = Notice(
            fingerprint=fp,
            graph_message_id=graph_message_id,
            source_provider=(source_provider or "manual")[:32],
            source_account=(source_account[:320] if source_account else None),
            title=title,
            category=final_category,
            subcategory=final_subcategory,
            organizer=chunk.organizer,
            source_subject=subject,
            source_sender=sender,
            source_date=source_date,
            event_date=event_date,
            deadline=deadline,
            location=location,
            language=language,
            action_required=action_required,
            registration_required=registration_required,
            company_name=company_name,
            company_size=company_size,
            job_scope=job_scope,
            priority=priority,
            rank_score=priority,
            rule_category=rule.category,
            rule_subcategory=rule.subcategory,
            rule_confidence=rule.confidence,
            rule_reason=rule.reason,
            llm_reviewed=llm_reviewed,
            llm_category=llm_result.category if llm_result else None,
            llm_subcategory=llm_result.subcategory if llm_result else None,
            llm_confidence=llm_result.confidence if llm_result else None,
            llm_reason=llm_result.reason if llm_result else review_decision.reason,
            llm_error=llm_error,
            decision_source=decision_source,
            privacy_redacted=was_redacted or not settings.llm_send_raw_email,
            summary=summary,
            url=chunk.url,
            raw_text=chunk.text,
        )
        db.add(notice)
        created.append(notice)

    db.commit()
    for notice in created:
        db.refresh(notice)
    return created
