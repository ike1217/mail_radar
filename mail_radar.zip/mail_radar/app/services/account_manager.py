from __future__ import annotations

import threading
from datetime import datetime, timedelta, timezone

import requests
from sqlalchemy import select

from ..config import effective_graph_config, get_settings
from ..db import SessionLocal
from ..models import MailAccount
from .browser_mail import BrowserMailboxClient, provider_options
from .gmail_mail import GmailHistoryExpired, GmailMailClient, google_client_store
from .graph_mail import GraphMailClient, sender_address
from .imap_mail import IMAPConfig, IMAPMailboxClient
from .pipeline import ingest_email
from .secret_vault import secret_vault


class AccountManager:
    """Unified multi-account scheduler for browser sessions plus API/IMAP fallbacks."""

    def __init__(self):
        self.settings = get_settings()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._syncing: set[int] = set()
        self._sync_lock = threading.RLock()
        self._session_imap_credentials: dict[int, dict[str, str | None]] = {}

    # ---------- lifecycle ----------
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._worker_loop, name='mail-radar-account-scheduler', daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive() and self._thread is not threading.current_thread():
            self._thread.join(timeout=3)
        self._thread = None

    # ---------- helpers ----------
    @staticmethod
    def _now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def _safe_aware(value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @staticmethod
    def _mask_email(value: str) -> str:
        if '@' not in value:
            return value
        name, domain = value.split('@', 1)
        if len(name) <= 2:
            masked = name[:1] + '*'
        else:
            masked = name[:2] + '*' * min(6, len(name) - 2)
        return f'{masked}@{domain}'

    @staticmethod
    def _imap_secret_key(account_id: int) -> str:
        return f'imap-password:{account_id}'

    @staticmethod
    def _browser_provider_key(account: MailAccount) -> str:
        prefix = 'browser:'
        if account.auth_type.startswith(prefix):
            return account.auth_type[len(prefix):] or 'custom'
        return 'custom'

    def _credential_available(self, account: MailAccount) -> bool:
        try:
            if account.provider == 'microsoft':
                default_client_id, default_tenant_id = effective_graph_config()
                client_id = account.oauth_client_id or default_client_id
                tenant_id = account.oauth_tenant_id or default_tenant_id
                if not client_id:
                    return False
                return GraphMailClient(
                    client_id=client_id,
                    tenant_id=tenant_id,
                    default_login_hint=account.email,
                ).has_cached_account(account.email)
            if account.provider == 'gmail':
                return GmailMailClient(account.email).credential_available()
            if account.provider == 'imap':
                return account.id in self._session_imap_credentials or secret_vault.has(self._imap_secret_key(account.id))
            if account.provider == 'browser':
                provider_key = self._browser_provider_key(account)
                custom_url = account.host if provider_key == 'custom' else None
                return BrowserMailboxClient(provider_key, account.email, custom_url=custom_url).session_available()
        except Exception:
            return False
        return False

    def _serialize(self, account: MailAccount) -> dict:
        mode = None
        if account.provider == 'microsoft':
            mode = 'Graph delta'
        elif account.provider == 'gmail':
            mode = 'Gmail history'
        elif account.provider == 'imap':
            mode = 'IMAP UID'
        elif account.provider == 'browser':
            mode = 'Webmail browser session'
        return {
            'id': account.id,
            'provider': account.provider,
            'provider_label': account.provider_label,
            'email': self._mask_email(account.email),
            'display_name': account.display_name,
            'auth_type': account.auth_type,
            'host': account.host,
            'port': account.port,
            'folder': account.folder,
            'enabled': account.enabled,
            'remember_credentials': account.remember_credentials,
            'interval_seconds': account.interval_seconds,
            'message_limit': account.message_limit,
            'last_sync_at': account.last_sync_at,
            'last_error': account.last_error,
            'messages_scanned': account.messages_scanned,
            'notices_processed': account.notices_processed,
            'sync_count': account.sync_count,
            'credential_available': self._credential_available(account),
            'sync_mode': mode,
        }

    def list_accounts(self) -> dict:
        db = SessionLocal()
        try:
            accounts = list(db.scalars(select(MailAccount).order_by(MailAccount.created_at.asc())))
            serialized = [self._serialize(a) for a in accounts]
            return {
                'accounts': serialized,
                'connected_count': sum(1 for a in serialized if a['enabled'] and a['credential_available']),
                'total_count': len(serialized),
            }
        finally:
            db.close()

    def _find_or_create(
        self,
        db,
        *,
        provider: str,
        email: str,
        folder: str,
        defaults: dict,
    ) -> MailAccount:
        account = db.scalar(
            select(MailAccount).where(
                MailAccount.provider == provider,
                MailAccount.email == email,
                MailAccount.folder == folder,
            )
        )
        if account is None:
            account = MailAccount(provider=provider, email=email, folder=folder, **defaults)
            db.add(account)
            db.flush()
        else:
            for key, value in defaults.items():
                setattr(account, key, value)
            account.enabled = True
            account.updated_at = self._now()
        return account

    def _record_result(self, account_id: int, scanned: int, notices: int, cursor: str | None, error: str | None = None) -> None:
        db = SessionLocal()
        try:
            account = db.get(MailAccount, account_id)
            if not account:
                return
            account.last_sync_at = self._now()
            account.last_error = error
            if error is None:
                account.messages_scanned = scanned
                account.notices_processed = notices
                account.sync_count += 1
                if cursor is not None:
                    account.sync_cursor = cursor
            account.updated_at = self._now()
            db.commit()
        finally:
            db.close()

    def _ingest_common(self, *, account: MailAccount, envelopes: list[dict]) -> tuple[int, int]:
        scanned = 0
        notices = 0
        db = SessionLocal()
        try:
            for item in envelopes:
                scanned += 1
                results = ingest_email(
                    db=db,
                    subject=item.get('subject') or '',
                    sender=item.get('sender') or '',
                    body=item.get('body') or '',
                    body_type=item.get('body_type') or 'text',
                    received_at=item.get('received_at'),
                    source_url=item.get('source_url'),
                    graph_message_id=item.get('message_id'),
                    source_provider=account.provider,
                    source_account=account.email,
                )
                notices += len(results)
        finally:
            db.close()
        return scanned, notices

    # ---------- universal webmail browser ----------
    def browser_provider_options(self) -> list[dict[str, str]]:
        return provider_options()

    def connect_browser(
        self,
        *,
        email: str,
        provider: str,
        custom_url: str | None,
        interval_seconds: int,
        message_limit: int,
    ) -> dict:
        email = email.strip().lower()
        if not email:
            raise ValueError('Email address is required.')
        client = BrowserMailboxClient(provider=provider, email=email, custom_url=custom_url)
        client.connect_interactive()

        db = SessionLocal()
        try:
            account = self._find_or_create(
                db,
                provider='browser',
                email=email,
                folder='INBOX',
                defaults={
                    'display_name': email.split('@', 1)[0],
                    'auth_type': f'browser:{client.provider}',
                    'provider_label': client.label,
                    # For custom webmail only, host stores the starting URL. Known providers
                    # reconstruct their official webmail URL from the provider registry.
                    'host': client.start_url if client.provider == 'custom' else None,
                    'port': None,
                    'remember_credentials': True,
                    'interval_seconds': max(60, min(interval_seconds, 3600)),
                    'message_limit': max(1, min(message_limit, self.settings.browser_max_messages_per_sync)),
                },
            )
            account.last_error = None
            db.commit()
            account_id = account.id
        finally:
            db.close()

        # First scan is deliberately visible. Webmail sites are much more consistent across
        # different PCs during an interactive browser session than in headless mode. Later
        # background syncs remain headless unless the user requests Visible sync.
        try:
            self.sync_browser_visible(account_id)
        except Exception:
            pass
        return self.get_account(account_id)

    def reconnect_browser(self, account_id: int) -> dict:
        # Reserve the account while a visible persistent browser owns its profile directory.
        with self._sync_lock:
            if account_id in self._syncing:
                raise RuntimeError('This mailbox is already synchronizing. Wait for the current sync to finish and reconnect again.')
            self._syncing.add(account_id)
        try:
            db = SessionLocal()
            try:
                account = db.get(MailAccount, account_id)
                if not account or account.provider != 'browser':
                    raise KeyError('Browser mailbox account not found.')
                provider_key = self._browser_provider_key(account)
                email = account.email
                custom_url = account.host if provider_key == 'custom' else None
            finally:
                db.close()

            client = BrowserMailboxClient(provider=provider_key, email=email, custom_url=custom_url)
            client.connect_interactive()

            db = SessionLocal()
            try:
                account = db.get(MailAccount, account_id)
                if account:
                    account.enabled = True
                    account.last_error = None
                    account.updated_at = self._now()
                    db.commit()
            finally:
                db.close()
        finally:
            with self._sync_lock:
                self._syncing.discard(account_id)

        try:
            return self.sync_browser_visible(account_id)
        except Exception:
            return self.get_account(account_id)

    def _sync_browser(self, account: MailAccount, force_full: bool, *, visible: bool = False) -> tuple[int, int, str | None]:
        provider_key = self._browser_provider_key(account)
        custom_url = account.host if provider_key == 'custom' else None
        client = BrowserMailboxClient(provider=provider_key, email=account.email, custom_url=custom_url)
        messages, cursor = client.scrape_messages(
            limit=account.message_limit,
            stop_cursor=None if force_full else account.sync_cursor,
            headless=False if visible else None,
        )
        envelopes = [{
            'message_id': f'browser:{provider_key}:{account.email}:{msg.message_id}',
            'subject': msg.subject,
            'sender': msg.sender,
            'body': msg.body,
            'body_type': 'text',
            'received_at': msg.received_at,
            'source_url': msg.source_url,
        } for msg in messages]
        scanned, notices = self._ingest_common(account=account, envelopes=envelopes)
        return scanned, notices, cursor

    def sync_browser_visible(self, account_id: int) -> dict:
        with self._sync_lock:
            if account_id in self._syncing:
                return self.get_account(account_id)
            self._syncing.add(account_id)
        try:
            db = SessionLocal()
            try:
                account = db.get(MailAccount, account_id)
                if not account or account.provider != 'browser':
                    raise KeyError('Browser mailbox account not found.')
                db.expunge(account)
            finally:
                db.close()
            try:
                scanned, notices, cursor = self._sync_browser(account, False, visible=True)
            except Exception as exc:
                self._record_result(account_id, 0, 0, None, f'{type(exc).__name__}: {exc}'[:2000])
                raise
            self._record_result(account_id, scanned, notices, cursor, None)
            return self.get_account(account_id)
        finally:
            with self._sync_lock:
                self._syncing.discard(account_id)

    # ---------- Microsoft ----------
    def connect_microsoft(
        self,
        *,
        client_id: str | None,
        tenant_id: str | None,
        login_hint: str | None,
        interval_seconds: int,
        message_limit: int,
        remember_app_setup: bool,
    ) -> dict:
        client = GraphMailClient(
            client_id=client_id,
            tenant_id=tenant_id,
            persist_config=remember_app_setup,
            default_login_hint=login_hint,
        )
        profile = client.connect_interactive(login_hint=login_hint)
        email = str(profile.get('mail') or profile.get('userPrincipalName') or login_hint or '').strip().lower()
        if not email:
            raise RuntimeError('Microsoft did not return an account email address.')
        db = SessionLocal()
        try:
            account = self._find_or_create(
                db,
                provider='microsoft',
                email=email,
                folder='INBOX',
                defaults={
                    'display_name': profile.get('displayName'),
                    'auth_type': 'oauth',
                    'provider_label': 'Microsoft 365 / Outlook',
                    'host': None,
                    'port': None,
                    'remember_credentials': True,
                    'oauth_client_id': client.client_id,
                    'oauth_tenant_id': client.tenant_id,
                    'interval_seconds': max(60, min(interval_seconds, 3600)),
                    'message_limit': max(1, min(message_limit, 200)),
                },
            )
            db.commit()
            account_id = account.id
        finally:
            db.close()
        self.sync_account(account_id, force_full=True)
        return self.get_account(account_id)

    def _sync_microsoft(self, account: MailAccount, force_full: bool) -> tuple[int, int, str]:
        default_client_id, default_tenant_id = effective_graph_config()
        client = GraphMailClient(
            client_id=account.oauth_client_id or default_client_id,
            tenant_id=account.oauth_tenant_id or default_tenant_id,
            default_login_hint=account.email,
        )

        def convert(messages: list[dict]) -> list[dict]:
            out = []
            for msg in messages:
                body = msg.get('body') or {}
                received = None
                if msg.get('receivedDateTime'):
                    try:
                        received = datetime.fromisoformat(msg['receivedDateTime'].replace('Z', '+00:00'))
                    except ValueError:
                        pass
                out.append({
                    'message_id': f'microsoft:{account.email}:{msg.get("id")}',
                    'subject': msg.get('subject') or '',
                    'sender': sender_address(msg),
                    'body': body.get('content') or msg.get('bodyPreview') or '',
                    'body_type': 'html' if (body.get('contentType') or '').casefold() == 'html' else 'text',
                    'received_at': received,
                    'source_url': msg.get('webLink'),
                })
            return out

        if force_full or not account.sync_cursor:
            recent = client.fetch_inbox(account.message_limit)
            overlap, cursor = client.delta_sync(None, lookback_minutes=self.settings.graph_delta_lookback_minutes)
            combined: dict[str, dict] = {}
            for msg in recent + overlap:
                if msg.get('id'):
                    combined[msg['id']] = msg
            scanned, notices = self._ingest_common(account=account, envelopes=convert(list(combined.values())))
            return scanned, notices, cursor

        try:
            messages, cursor = client.delta_sync(account.sync_cursor)
        except requests.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else None
            if status not in {400, 404, 410}:
                raise
            return self._sync_microsoft(account, True)
        scanned, notices = self._ingest_common(account=account, envelopes=convert(messages))
        return scanned, notices, cursor

    # ---------- Gmail ----------
    def connect_gmail(
        self,
        *,
        client_config_json: str | None,
        interval_seconds: int,
        message_limit: int,
        remember_client_config: bool,
    ) -> dict:
        client = GmailMailClient()
        profile = client.connect_interactive(client_config_json, remember_client_config=remember_client_config)
        email = str(profile.get('emailAddress') or '').strip().lower()
        db = SessionLocal()
        try:
            account = self._find_or_create(
                db,
                provider='gmail',
                email=email,
                folder='INBOX',
                defaults={
                    'display_name': email.split('@', 1)[0],
                    'auth_type': 'oauth',
                    'provider_label': 'Gmail / Google Workspace',
                    'host': None,
                    'port': None,
                    'remember_credentials': True,
                    'interval_seconds': max(60, min(interval_seconds, 3600)),
                    'message_limit': max(1, min(message_limit, 500)),
                },
            )
            db.commit()
            account_id = account.id
        finally:
            db.close()
        self.sync_account(account_id, force_full=True)
        return self.get_account(account_id)

    def _sync_gmail(self, account: MailAccount, force_full: bool) -> tuple[int, int, str]:
        client = GmailMailClient(account.email)
        if force_full or not account.sync_cursor:
            messages, cursor = client.initial_sync(account.message_limit)
        else:
            try:
                messages, cursor = client.history_sync(account.sync_cursor)
            except GmailHistoryExpired:
                messages, cursor = client.initial_sync(account.message_limit)

        envelopes = [{
            'message_id': f'gmail:{account.email}:{msg.message_id}',
            'subject': msg.subject,
            'sender': msg.sender,
            'body': msg.body,
            'body_type': msg.body_type,
            'received_at': msg.received_at,
            'source_url': msg.web_link,
        } for msg in messages]
        scanned, notices = self._ingest_common(account=account, envelopes=envelopes)
        return scanned, notices, cursor

    # ---------- IMAP ----------
    def connect_imap(
        self,
        *,
        email: str,
        password: str,
        provider: str,
        host: str | None,
        port: int,
        username: str | None,
        folder: str,
        interval_seconds: int,
        message_limit: int,
        remember_password: bool,
    ) -> dict:
        email = email.strip().lower()
        config = IMAPConfig(
            email=email,
            password=password,
            provider=provider,
            host=host,
            port=port,
            folder=folder.strip() or 'INBOX',
            username=(username or '').strip() or None,
        )
        client = IMAPMailboxClient(config)
        client.test_connection()
        db = SessionLocal()
        try:
            account = self._find_or_create(
                db,
                provider='imap',
                email=email,
                folder=config.folder,
                defaults={
                    'display_name': email.split('@', 1)[0],
                    'auth_type': 'app_password',
                    'provider_label': client.label,
                    'host': client.host,
                    'port': config.port,
                    'remember_credentials': remember_password,
                    'interval_seconds': max(60, min(interval_seconds, 3600)),
                    'message_limit': max(1, min(message_limit, 500)),
                },
            )
            db.commit()
            account_id = account.id
        finally:
            db.close()
        self._session_imap_credentials[account_id] = {'password': password, 'username': config.username}
        if remember_password:
            secret_vault.set(self._imap_secret_key(account_id), {
                'password': password,
                'username': config.username,
            })
        else:
            secret_vault.delete(self._imap_secret_key(account_id))
        self.sync_account(account_id, force_full=True)
        return self.get_account(account_id)

    def _imap_credentials(self, account: MailAccount) -> tuple[str, str | None]:
        if account.id in self._session_imap_credentials:
            data = self._session_imap_credentials[account.id]
            return str(data['password']), (str(data.get('username')) if data.get('username') else None)
        data = secret_vault.get(self._imap_secret_key(account.id))
        if isinstance(data, dict) and data.get('password'):
            return str(data['password']), (str(data.get('username')) if data.get('username') else None)
        raise RuntimeError('This IMAP account needs to be reconnected because its app password is not available.')

    def _sync_imap(self, account: MailAccount, force_full: bool) -> tuple[int, int, str]:
        password, username = self._imap_credentials(account)
        config = IMAPConfig(
            email=account.email,
            password=password,
            provider='custom',
            host=account.host,
            port=account.port or 993,
            folder=account.folder,
            username=username,
        )
        client = IMAPMailboxClient(config)
        messages, cursor = client.fetch_incremental(None if force_full else account.sync_cursor, account.message_limit)
        envelopes = [{
            'message_id': f'imap:{account.email}:{account.host}:{account.folder}:{msg.uid}',
            'subject': msg.subject,
            'sender': msg.sender,
            'body': msg.body,
            'body_type': msg.body_type,
            'received_at': msg.received_at,
            'source_url': None,
        } for msg in messages]
        scanned, notices = self._ingest_common(account=account, envelopes=envelopes)
        return scanned, notices, cursor

    # ---------- public account operations ----------
    def get_account(self, account_id: int) -> dict:
        db = SessionLocal()
        try:
            account = db.get(MailAccount, account_id)
            if not account:
                raise KeyError('Mailbox account not found.')
            return self._serialize(account)
        finally:
            db.close()

    def sync_account(self, account_id: int, force_full: bool = False) -> dict:
        with self._sync_lock:
            if account_id in self._syncing:
                return self.get_account(account_id)
            self._syncing.add(account_id)
        try:
            db = SessionLocal()
            try:
                account = db.get(MailAccount, account_id)
                if not account:
                    raise KeyError('Mailbox account not found.')
                db.expunge(account)
            finally:
                db.close()

            try:
                if account.provider == 'microsoft':
                    scanned, notices, cursor = self._sync_microsoft(account, force_full)
                elif account.provider == 'gmail':
                    scanned, notices, cursor = self._sync_gmail(account, force_full)
                elif account.provider == 'imap':
                    scanned, notices, cursor = self._sync_imap(account, force_full)
                elif account.provider == 'browser':
                    scanned, notices, cursor = self._sync_browser(account, force_full)
                else:
                    raise RuntimeError(f'Unsupported account provider: {account.provider}')
            except Exception as exc:
                self._record_result(account_id, 0, 0, None, f'{type(exc).__name__}: {exc}'[:2000])
                raise
            self._record_result(account_id, scanned, notices, cursor, None)
            return self.get_account(account_id)
        finally:
            with self._sync_lock:
                self._syncing.discard(account_id)

    def sync_all(self) -> dict:
        db = SessionLocal()
        try:
            ids = list(db.scalars(select(MailAccount.id).where(MailAccount.enabled.is_(True))))
        finally:
            db.close()
        synced = 0
        errors: list[dict] = []
        for account_id in ids:
            try:
                self.sync_account(account_id)
                synced += 1
            except Exception as exc:
                errors.append({'account_id': account_id, 'error': str(exc)})
        return {'synced_accounts': synced, 'errors': errors, 'accounts': self.list_accounts()['accounts']}

    def set_enabled(self, account_id: int, enabled: bool) -> dict:
        db = SessionLocal()
        try:
            account = db.get(MailAccount, account_id)
            if not account:
                raise KeyError('Mailbox account not found.')
            if enabled and not self._credential_available(account):
                raise RuntimeError('Stored authorization is unavailable. Reconnect this account instead.')
            account.enabled = enabled
            account.updated_at = self._now()
            db.commit()
            db.refresh(account)
            return self._serialize(account)
        finally:
            db.close()

    def remove_account(self, account_id: int) -> None:
        db = SessionLocal()
        try:
            account = db.get(MailAccount, account_id)
            if not account:
                return
            provider = account.provider
            email = account.email
            if provider == 'imap':
                self._session_imap_credentials.pop(account.id, None)
                secret_vault.delete(self._imap_secret_key(account.id))
            elif provider == 'gmail':
                GmailMailClient(email).sign_out()
            elif provider == 'microsoft':
                try:
                    default_client_id, default_tenant_id = effective_graph_config()
                    client_id = account.oauth_client_id or default_client_id
                    tenant_id = account.oauth_tenant_id or default_tenant_id
                    if client_id:
                        GraphMailClient(client_id=client_id, tenant_id=tenant_id, default_login_hint=email).sign_out_account(email)
                except Exception:
                    pass
            elif provider == 'browser':
                try:
                    provider_key = self._browser_provider_key(account)
                    custom_url = account.host if provider_key == 'custom' else None
                    BrowserMailboxClient(provider_key, email, custom_url=custom_url).clear_session()
                except Exception:
                    pass
            db.delete(account)
            db.commit()
        finally:
            db.close()

    def provider_setup_status(self) -> dict:
        client_id, tenant_id = effective_graph_config()
        return {
            'microsoft_configured': bool(client_id),
            'microsoft_tenant_id': tenant_id,
            'gmail_configured': google_client_store.configured(),
            'browser_connector_available': BrowserMailboxClient.dependency_available(),
            'browser_providers': provider_options(),
        }

    # ---------- scheduler ----------
    def _worker_loop(self) -> None:
        while not self._stop_event.wait(max(5, self.settings.scheduler_tick_seconds)):
            now = self._now()
            db = SessionLocal()
            try:
                accounts = list(db.scalars(select(MailAccount).where(MailAccount.enabled.is_(True))))
                due_ids = []
                for account in accounts:
                    last = self._safe_aware(account.last_sync_at)
                    if last is None or now - last >= timedelta(seconds=max(60, account.interval_seconds)):
                        due_ids.append(account.id)
            finally:
                db.close()
            for account_id in due_ids:
                if self._stop_event.is_set():
                    return
                try:
                    self.sync_account(account_id)
                except Exception:
                    continue


account_manager = AccountManager()
