from __future__ import annotations

import re
from datetime import datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Notice, TimetableEvent
from ..timezones import get_timezone

CATEGORY_COLORS = {
    'school': '#4f78d8',
    'activity': '#8d63d8',
    'career': '#3b9f70',
    'deadline': '#d26a58',
}

_TIME_RANGE_12H = re.compile(
    r'(?<!\d)(\d{1,2})(?::(\d{2}))?\s*(am|pm)\s*(?:-|–|—|to)\s*'
    r'(\d{1,2})(?::(\d{2}))?\s*(am|pm)(?!\w)', re.I
)
_TIME_RANGE_24H = re.compile(
    r'(?<!\d)([01]?\d|2[0-3]):([0-5]\d)\s*(?:-|–|—|to)\s*([01]?\d|2[0-3]):([0-5]\d)(?!\d)', re.I
)
_SINGLE_12H = re.compile(r'\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b', re.I)
_SINGLE_24H = re.compile(r'\b(?:at\s+)?([01]?\d|2[0-3]):([0-5]\d)\b', re.I)

_BODY_CUT_MARKERS = [
    re.compile(pattern, re.I)
    for pattern in [
        r'\bThis is an external email\b',
        r'\bDear\b',
        r'\bPlease see the details below\b',
        r'\bFurther details\b',
        r'\bThank you for your\b',
        r'\bBest regards\b',
        r'\bFrom\s*:',
    ]
]
_LOCATION_LINE = re.compile(
    r'\b(?:venue|location|where)\s*[:：]\s*(.+?)(?=(?:\s{2,}|\n|\r|\b(?:date|time|registration|please|thank|dear|from)\b|$))',
    re.I,
)
_LONG_TOKEN = re.compile(r'\b[A-Za-z0-9+/=_-]{18,}\b')


def ensure_aware(value: datetime) -> datetime:
    """Normalize SQLite's timezone-naive datetimes to the configured local timezone."""
    if value.tzinfo is not None:
        return value
    return value.replace(tzinfo=get_timezone(get_settings().timezone))


def _to_24(hour: int, minute: int, ampm: str) -> tuple[int, int]:
    hour %= 12
    if ampm.lower() == 'pm':
        hour += 12
    return hour, minute


def infer_time_range(text: str, base: datetime) -> tuple[datetime, datetime, bool]:
    """Infer a clock time from the notice text without inventing one.

    Returns (start, end, all_day). If no clock time is present, the date is
    preserved as an all-day item rather than fabricating a time.
    """
    base = ensure_aware(base)
    tz = base.tzinfo or get_timezone(get_settings().timezone)
    local = base.astimezone(tz)

    m = _TIME_RANGE_12H.search(text or '')
    if m:
        h1, mi1 = _to_24(int(m.group(1)), int(m.group(2) or 0), m.group(3))
        h2, mi2 = _to_24(int(m.group(4)), int(m.group(5) or 0), m.group(6))
        start = local.replace(hour=h1, minute=mi1, second=0, microsecond=0)
        end = local.replace(hour=h2, minute=mi2, second=0, microsecond=0)
        if end <= start:
            end += timedelta(days=1)
        return start, end, False

    m = _TIME_RANGE_24H.search(text or '')
    if m:
        start = local.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        end = local.replace(hour=int(m.group(3)), minute=int(m.group(4)), second=0, microsecond=0)
        if end <= start:
            end += timedelta(days=1)
        return start, end, False

    m = _SINGLE_12H.search(text or '')
    if m:
        h, mi = _to_24(int(m.group(1)), int(m.group(2) or 0), m.group(3))
        start = local.replace(hour=h, minute=mi, second=0, microsecond=0)
        return start, start + timedelta(hours=1), False

    m = _SINGLE_24H.search(text or '')
    if m:
        start = local.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        return start, start + timedelta(hours=1), False

    start = local.replace(hour=0, minute=0, second=0, microsecond=0)
    return start, start + timedelta(days=1), True



def _compact_calendar_title(title: str, *, deadline: bool = False) -> str:
    value = re.sub(r'\s+', ' ', title or '').strip()
    value = re.sub(r'^(?:re|fw|fwd)\s*:\s*', '', value, flags=re.I)
    value = _LONG_TOKEN.sub('', value)
    value = re.sub(r'\s+', ' ', value).strip(' -–—,:;')

    cut_at: int | None = None
    for marker in _BODY_CUT_MARKERS:
        m = marker.search(value)
        if m and m.start() > 12:
            cut_at = m.start() if cut_at is None else min(cut_at, m.start())
    if cut_at is not None:
        value = value[:cut_at].strip(' -–—,:;')

    if len(value) > 110:
        for sep in [' | ', ' — ', ' – ', ' - ', '. ']:
            head = value.split(sep)[0].strip(' -–—,:;')
            if 8 <= len(head) <= 90:
                value = head
                break

    if len(value) > 110:
        value = value[:107].rsplit(' ', 1)[0].rstrip(' -–—,:;') + '…'

    if deadline and value and 'deadline' not in value.casefold():
        value = f'{value} — deadline'
    return value or ('Deadline' if deadline else 'Untitled event')


def _extract_location(text: str) -> str | None:
    if not text:
        return None
    for raw in text.splitlines():
        line = re.sub(r'\s+', ' ', raw).strip()
        if not line:
            continue
        match = _LOCATION_LINE.search(line)
        if match:
            value = _LONG_TOKEN.sub('', match.group(1)).strip(' .;,-')
            value = re.sub(r'\s+', ' ', value)
            if 2 <= len(value) <= 180:
                return value
    match = _LOCATION_LINE.search(text)
    if match:
        value = _LONG_TOKEN.sub('', match.group(1)).strip(' .;,-')
        value = re.sub(r'\s+', ' ', value)
        if 2 <= len(value) <= 180:
            return value
    return None


def _notice_event(notice: Notice, when: datetime, *, deadline: bool = False) -> dict:
    text = '\n'.join(x for x in [notice.title, notice.raw_text, notice.summary] if x)
    start, end, all_day = infer_time_range(text, when)
    category = 'deadline' if deadline else notice.category
    details = notice.summary or notice.raw_text[:1000] or 'No additional details.'
    source = notice.source_account or notice.source_sender or notice.source_provider or 'Email'
    location = notice.location or _extract_location(text)
    return {
        'id': f"notice-{notice.id}-{'deadline' if deadline else 'event'}",
        'title': _compact_calendar_title(notice.title, deadline=deadline),
        'start_at': start,
        'end_at': end,
        'all_day': all_day,
        'location': location,
        'details': details,
        'kind': 'deadline' if deadline else notice.category,
        'category': notice.category,
        'course_code': None,
        'source': source,
        'source_sender': notice.source_sender or None,
        'source_account': notice.source_account,
        'source_notice_id': notice.id,
        'url': notice.url,
        'color': CATEGORY_COLORS.get(category, '#697586'),
        'editable': False,
    }


def calendar_events(db: Session) -> list[dict]:
    events: list[dict] = []

    classes = list(db.scalars(select(TimetableEvent).order_by(TimetableEvent.start_at.asc())).all())
    for item in classes:
        kind = item.event_kind if item.event_kind in {'class', 'exam'} else 'class'
        events.append({
            'id': f'{kind}-{item.id}',
            'title': item.title,
            'start_at': ensure_aware(item.start_at),
            'end_at': ensure_aware(item.end_at),
            'all_day': False,
            'location': item.location,
            'details': item.details or ('Scheduled exam.' if kind == 'exam' else 'Scheduled class session.'),
            'kind': kind,
            'category': 'school',
            'course_code': item.course_code,
            'source': 'Manual exam' if kind == 'exam' else 'Manual timetable',
            'source_sender': None,
            'source_account': None,
            'source_notice_id': None,
            'url': None,
            'color': item.color or ('#d26a58' if kind == 'exam' else '#4f78d8'),
            'editable': True,
        })

    notices = list(db.scalars(
        select(Notice).where(Notice.category != 'ignore').order_by(Notice.event_date.asc(), Notice.deadline.asc())
    ).all())
    for notice in notices:
        if notice.event_date is not None:
            events.append(_notice_event(notice, ensure_aware(notice.event_date)))
        if notice.deadline is not None:
            # Keep a separate deadline entry when it is a different calendar moment/date.
            if notice.event_date is None or notice.deadline.date() != notice.event_date.date():
                events.append(_notice_event(notice, ensure_aware(notice.deadline), deadline=True))

    events.sort(key=lambda e: ensure_aware(e['start_at']).timestamp())
    return events
