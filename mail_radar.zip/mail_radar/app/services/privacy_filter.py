from __future__ import annotations

import re

EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
PHONE_RE = re.compile(r"(?<!\d)(?:\+?852[-\s]?)?[2-9]\d{3}[-\s]?\d{4}(?!\d)")
STUDENT_ID_RE = re.compile(r"\b(?:uid|student\s*(?:id|no\.?|number)?|university\s*number)\s*[:#-]?\s*[A-Za-z]?\d{6,12}\b", re.I)
HKU_UID_RE = re.compile(r"\bu\d{6,10}\b", re.I)
TRACKING_RE = re.compile(r"https?://\S+(?:utm_[^\s&]+|tracking|click|redirect)\S*", re.I)

FOOTER_MARKERS = [
    "unsubscribe", "you are receiving this email", "confidentiality notice", "privacy notice",
    "this message is intended only", "do not reply to this email", "automatically generated"
]


def redact_for_llm(text: str, max_chars: int = 12000) -> tuple[str, bool]:
    """Return an LLM-safe copy. The original is still stored locally in raw_text."""
    original = text
    text = EMAIL_RE.sub("[EMAIL]", text)
    text = PHONE_RE.sub("[PHONE]", text)
    text = STUDENT_ID_RE.sub("[STUDENT_ID]", text)
    text = HKU_UID_RE.sub("[HKU_UID]", text)
    text = TRACKING_RE.sub("[TRACKING_URL]", text)

    lines = []
    for line in text.splitlines():
        low = line.casefold().strip()
        if any(marker in low for marker in FOOTER_MARKERS):
            break
        lines.append(line)
    text = "\n".join(lines).strip()
    if len(text) > max_chars:
        text = text[:max_chars] + "\n[TRUNCATED]"
    return text, text != original
