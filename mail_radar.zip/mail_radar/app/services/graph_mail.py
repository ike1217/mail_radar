from __future__ import annotations

from datetime import datetime, timedelta, timezone

import requests

from ..config import effective_graph_config, get_settings, save_local_graph_config
from .secure_cache import EncryptedFileStore

GRAPH_BASE = 'https://graph.microsoft.com/v1.0'
MESSAGE_SELECT = 'id,subject,from,receivedDateTime,body,bodyPreview,webLink,internetMessageId'


class GraphMailClient:
    """Microsoft Graph delegated client using browser OAuth + PKCE.

    A single encrypted MSAL cache can safely contain multiple Microsoft accounts.
    `default_login_hint` selects the account used by background synchronization.
    """

    def __init__(
        self,
        client_id: str | None = None,
        tenant_id: str | None = None,
        *,
        persist_config: bool = False,
        default_login_hint: str | None = None,
    ):
        self.settings = get_settings()
        saved_client_id, saved_tenant_id = effective_graph_config()
        self.client_id = (client_id or saved_client_id or '').strip()
        self.tenant_id = (tenant_id or saved_tenant_id or 'organizations').strip()
        self.default_login_hint = (default_login_hint or '').strip() or None
        if not self.client_id:
            raise RuntimeError('Microsoft OAuth is not configured. Enter an Entra Application (client) ID in the connection dialog.')
        if persist_config and client_id:
            save_local_graph_config(self.client_id, self.tenant_id)

        try:
            import msal
        except ImportError as exc:
            raise RuntimeError('The msal package is required. Run start_windows.bat again.') from exc

        self._msal = msal
        self.cache = msal.SerializableTokenCache()
        self.store = EncryptedFileStore(self.settings.graph_cache_path, self.settings.graph_cache_key_path)
        cached = self.store.read_text()
        if cached:
            try:
                self.cache.deserialize(cached)
            except Exception:
                pass
        self.app = msal.PublicClientApplication(
            client_id=self.client_id,
            authority=f'https://login.microsoftonline.com/{self.tenant_id}',
            token_cache=self.cache,
        )

    def _save_cache(self) -> None:
        if self.cache.has_state_changed:
            self.store.write_text(self.cache.serialize())

    def accounts(self) -> list[dict]:
        return list(self.app.get_accounts())

    def _pick_account(self, login_hint: str | None = None) -> dict | None:
        accounts = self.accounts()
        if not accounts:
            return None
        hint = (login_hint or self.default_login_hint or '').casefold()
        if hint:
            for account in accounts:
                if (account.get('username') or '').casefold() == hint:
                    return account
        return accounts[0]

    def has_cached_account(self, login_hint: str | None = None) -> bool:
        return self._pick_account(login_hint) is not None

    def acquire_token(
        self,
        *,
        interactive: bool = False,
        login_hint: str | None = None,
        prompt: str | None = None,
    ) -> str:
        scopes = self.settings.graph_scope_list
        result = None
        account = self._pick_account(login_hint)
        if account:
            result = self.app.acquire_token_silent(scopes, account=account)

        if not result and interactive:
            kwargs = {'scopes': scopes, 'timeout': 300}
            hint = login_hint or self.default_login_hint
            if hint:
                kwargs['login_hint'] = hint
            if prompt:
                kwargs['prompt'] = prompt
            result = self.app.acquire_token_interactive(**kwargs)

        self._save_cache()
        if not result or 'access_token' not in result:
            if isinstance(result, dict):
                description = result.get('error_description') or result.get('error') or 'No cached Microsoft session is available.'
            else:
                description = 'No cached Microsoft session is available.'
            raise RuntimeError(f'Microsoft authentication failed: {description}')
        return result['access_token']

    def connect_interactive(self, login_hint: str | None = None) -> dict:
        hint = login_hint or self.default_login_hint
        self.acquire_token(interactive=True, login_hint=hint, prompt='select_account')
        self.default_login_hint = hint
        profile = self.me()
        self.default_login_hint = profile.get('mail') or profile.get('userPrincipalName') or hint
        return profile

    def _headers(self, interactive: bool = False) -> dict[str, str]:
        return {
            'Authorization': f'Bearer {self.acquire_token(interactive=interactive, login_hint=self.default_login_hint)}',
            'Accept': 'application/json',
        }

    @staticmethod
    def _raise(response: requests.Response) -> None:
        if response.ok:
            return
        try:
            detail = response.json().get('error', {}).get('message') or response.text
        except Exception:
            detail = response.text
        raise requests.HTTPError(f'Microsoft Graph {response.status_code}: {detail}', response=response)

    def me(self) -> dict:
        response = requests.get(
            f'{GRAPH_BASE}/me',
            headers=self._headers(False),
            params={'$select': 'id,displayName,mail,userPrincipalName'},
            timeout=30,
        )
        self._raise(response)
        return response.json()

    def fetch_inbox(self, top: int = 50) -> list[dict]:
        params = {
            '$top': min(max(int(top), 1), 200),
            '$orderby': 'receivedDateTime desc',
            '$select': MESSAGE_SELECT,
        }
        response = requests.get(
            f'{GRAPH_BASE}/me/mailFolders/inbox/messages',
            headers=self._headers(False),
            params=params,
            timeout=30,
        )
        self._raise(response)
        return list(response.json().get('value', []))

    def fetch_message(self, message_id: str) -> dict:
        response = requests.get(
            f'{GRAPH_BASE}/me/messages/{message_id}',
            headers=self._headers(False),
            params={'$select': MESSAGE_SELECT},
            timeout=30,
        )
        self._raise(response)
        return response.json()

    def delta_sync(
        self,
        delta_link: str | None = None,
        *,
        lookback_minutes: int | None = None,
        max_pages: int = 50,
    ) -> tuple[list[dict], str]:
        if delta_link:
            url = delta_link
            params = None
        else:
            minutes = lookback_minutes if lookback_minutes is not None else self.settings.graph_delta_lookback_minutes
            since = datetime.now(timezone.utc) - timedelta(minutes=max(1, minutes))
            url = f'{GRAPH_BASE}/me/mailFolders/inbox/messages/delta'
            params = {
                'changeType': 'created',
                '$filter': f'receivedDateTime ge {since.isoformat().replace("+00:00", "Z")}',
                '$select': MESSAGE_SELECT,
                '$top': 100,
            }

        out: list[dict] = []
        final_link = ''
        headers = {**self._headers(False), 'Prefer': 'odata.maxpagesize=100'}
        pages = 0
        while url and pages < max_pages:
            pages += 1
            response = requests.get(url, headers=headers, params=params, timeout=30)
            self._raise(response)
            data = response.json()
            out.extend(item for item in data.get('value', []) if '@removed' not in item)
            if data.get('@odata.deltaLink'):
                final_link = data['@odata.deltaLink']
                break
            url = data.get('@odata.nextLink')
            params = None
        if not final_link:
            raise RuntimeError('Microsoft Graph delta sync did not return a deltaLink before the page safety limit.')
        return out, final_link

    def sign_out_account(self, login_hint: str) -> None:
        target = login_hint.casefold()
        for account in self.accounts():
            if (account.get('username') or '').casefold() == target:
                try:
                    self.app.remove_account(account)
                except Exception:
                    pass
        self._save_cache()


def sender_address(message: dict) -> str:
    return (((message.get('from') or {}).get('emailAddress') or {}).get('address') or '')
