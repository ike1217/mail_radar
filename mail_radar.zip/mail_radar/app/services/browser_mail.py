from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from ..config import get_settings


@dataclass(frozen=True)
class BrowserProvider:
    key: str
    label: str
    inbox_url: str
    inbox_hosts: tuple[str, ...]
    row_selectors: tuple[str, ...]
    subject_selectors: tuple[str, ...]
    body_selectors: tuple[str, ...]


@dataclass
class BrowserMessage:
    cursor_key: str
    message_id: str
    subject: str
    sender: str
    body: str
    received_at: datetime | None
    source_url: str | None


PROVIDERS: dict[str, BrowserProvider] = {
    'outlook': BrowserProvider(
        key='outlook',
        label='Microsoft 365 / Outlook Web',
        inbox_url='https://outlook.office.com/mail/',
        inbox_hosts=('outlook.office.com', 'outlook.office365.com', 'outlook.live.com'),
        row_selectors=(
            '[role="main"] [role="option"]',
            '[data-app-section*="MailList" i] [role="option"]',
            '[data-app-section*="MailList" i] [data-is-focusable="true"]',
            '[data-automationid*="MessageList" i] [role="option"]',
            '[data-automationid*="MessageList" i] [data-is-focusable="true"]',
            '[role="main"] [data-is-focusable="true"][tabindex]',
            '[aria-label*="Message list" i] [role="option"]',
            '[aria-label*="Mail list" i] [role="option"]',
            '[data-testid*="mail-list" i] [role="option"]',
            '[data-testid*="message-list" i] [role="option"]',
            '[data-testid*="mail-item" i]',
            '[data-testid*="message-item" i]',
            '[data-convid]',
            '[data-item-id]',
            '[role="listbox"] [role="option"]',
            '[role="grid"] [role="row"]',
        ),
        subject_selectors=(
            '[data-testid="message-subject"]',
            '[role="main"] h1',
            '[role="main"] h2',
            'h1',
            'h2',
        ),
        body_selectors=(
            '[aria-label*="Message body"]',
            '[aria-label*="message body"]',
            '[role="document"]',
            'div[role="main"] article',
            'article',
            '[role="main"]',
        ),
    ),
    'gmail': BrowserProvider(
        key='gmail',
        label='Gmail / Google Workspace Web',
        inbox_url='https://mail.google.com/mail/u/0/#inbox',
        inbox_hosts=('mail.google.com',),
        row_selectors=(
            'tr.zA',
            'table[role="grid"] tr[role="main"]',
            'table[role="grid"] tr',
            'tr[role="row"]',
        ),
        subject_selectors=(
            'h2.hP',
            '[role="main"] h2',
            '[role="main"] h1',
            'h2',
            'h1',
        ),
        body_selectors=(
            '.a3s.aiL',
            '.a3s',
            '[role="listitem"] [dir="ltr"]',
            '[role="main"] [role="listitem"]',
            '[role="main"]',
        ),
    ),
    'yahoo': BrowserProvider(
        key='yahoo',
        label='Yahoo Mail Web',
        inbox_url='https://mail.yahoo.com/d/folders/1',
        inbox_hosts=('mail.yahoo.com',),
        row_selectors=(
            '[data-test-id="message-list-item"]',
            '[data-test-id="virtual-list"] li',
            '[role="listitem"]',
        ),
        subject_selectors=(
            '[data-test-id="message-group-subject-text"]',
            '[data-test-id="message-view-subject"]',
            '[role="main"] h1',
            '[role="main"] h2',
        ),
        body_selectors=(
            '[data-test-id="message-view-body-content"]',
            '[data-test-id="message-body"]',
            '[role="main"] article',
            '[role="main"]',
        ),
    ),
    'aol': BrowserProvider(
        key='aol',
        label='AOL Mail Web',
        inbox_url='https://mail.aol.com/',
        inbox_hosts=('mail.aol.com',),
        row_selectors=(
            '[data-test-id="message-list-item"]',
            '[role="listitem"]',
            '[role="row"]',
        ),
        subject_selectors=(
            '[data-test-id="message-view-subject"]',
            '[role="main"] h1',
            '[role="main"] h2',
        ),
        body_selectors=(
            '[data-test-id="message-view-body-content"]',
            '[role="main"] article',
            '[role="main"]',
        ),
    ),
    'icloud': BrowserProvider(
        key='icloud',
        label='iCloud Mail Web',
        inbox_url='https://www.icloud.com/mail/',
        inbox_hosts=('www.icloud.com', 'icloud.com'),
        row_selectors=(
            '[role="row"]',
            '[role="listitem"]',
            '[aria-label*="message"]',
        ),
        subject_selectors=(
            '[role="main"] h1',
            '[role="main"] h2',
            'h1',
            'h2',
        ),
        body_selectors=(
            '[role="document"]',
            '[role="main"] article',
            'article',
            '[role="main"]',
        ),
    ),
    'qq': BrowserProvider(
        key='qq',
        label='QQ Mail Web',
        inbox_url='https://mail.qq.com/',
        inbox_hosts=('mail.qq.com',),
        row_selectors=(
            '[role="row"]',
            'tr[mailid]',
            'tr[data-mailid]',
            '.mail-list tr',
            'tr',
        ),
        subject_selectors=('h1', 'h2', '.subject', '[class*="subject"]'),
        body_selectors=('[role="document"]', '.mailcontent', '[class*="mail-content"]', '[class*="content"]'),
    ),
    '163': BrowserProvider(
        key='163',
        label='163 Mail Web',
        inbox_url='https://mail.163.com/',
        inbox_hosts=('mail.163.com',),
        row_selectors=('[role="row"]', '[class*="mailList"] [class*="item"]', 'tr'),
        subject_selectors=('h1', 'h2', '[class*="subject"]'),
        body_selectors=('[role="document"]', '[class*="mailContent"]', '[class*="content"]'),
    ),
    '126': BrowserProvider(
        key='126',
        label='126 Mail Web',
        inbox_url='https://mail.126.com/',
        inbox_hosts=('mail.126.com',),
        row_selectors=('[role="row"]', '[class*="mailList"] [class*="item"]', 'tr'),
        subject_selectors=('h1', 'h2', '[class*="subject"]'),
        body_selectors=('[role="document"]', '[class*="mailContent"]', '[class*="content"]'),
    ),
    'zoho': BrowserProvider(
        key='zoho',
        label='Zoho Mail Web',
        inbox_url='https://mail.zoho.com/zm/',
        inbox_hosts=('mail.zoho.com',),
        row_selectors=('[role="row"]', '[data-zcqa*="mail"]', '[class*="mailList"] [class*="item"]'),
        subject_selectors=('h1', 'h2', '[class*="subject"]'),
        body_selectors=('[role="document"]', '[class*="mailContent"]', '[class*="content"]', '[role="main"]'),
    ),
    'fastmail': BrowserProvider(
        key='fastmail',
        label='Fastmail Web',
        inbox_url='https://app.fastmail.com/mail/Inbox',
        inbox_hosts=('app.fastmail.com',),
        row_selectors=('[role="row"]', '[role="listitem"]', '[class*="v-MailboxItem"]'),
        subject_selectors=('h1', 'h2', '[class*="subject"]'),
        body_selectors=('[role="document"]', '[class*="messageBody"]', '[class*="mailBody"]', '[role="main"]'),
    ),
    'proton': BrowserProvider(
        key='proton',
        label='Proton Mail Web',
        inbox_url='https://mail.proton.me/u/0/inbox',
        inbox_hosts=('mail.proton.me',),
        row_selectors=('[data-testid*="message-item"]', '[role="row"]', '[role="listitem"]'),
        subject_selectors=('[data-testid*="message-view"] h1', '[role="main"] h1', '[role="main"] h2', 'h1', 'h2'),
        body_selectors=('[data-testid*="message-body"]', '[role="document"]', '[role="main"] article', '[role="main"]'),
    ),
    'yandex': BrowserProvider(
        key='yandex',
        label='Yandex Mail Web',
        inbox_url='https://mail.yandex.com/',
        inbox_hosts=('mail.yandex.com', 'mail.yandex.ru'),
        row_selectors=('[class*="mail-MessageSnippet"]', '[role="row"]', '[role="listitem"]'),
        subject_selectors=('[class*="MessageViewer-Header"] h1', '[role="main"] h1', 'h1', 'h2'),
        body_selectors=('[class*="MessageBody"]', '[role="document"]', '[role="main"]'),
    ),
    'gmx': BrowserProvider(
        key='gmx',
        label='GMX Mail Web',
        inbox_url='https://navigator.gmx.com/mail',
        inbox_hosts=('navigator.gmx.com', '3c.gmx.net'),
        row_selectors=('[role="row"]', '[role="listitem"]', 'tr'),
        subject_selectors=('[role="main"] h1', '[role="main"] h2', 'h1', 'h2'),
        body_selectors=('[role="document"]', '[role="main"] article', '[role="main"]'),
    ),
    'mailcom': BrowserProvider(
        key='mailcom',
        label='mail.com Webmail',
        inbox_url='https://navigator.mail.com/mail',
        inbox_hosts=('navigator.mail.com', '3c.mail.com'),
        row_selectors=('[role="row"]', '[role="listitem"]', 'tr'),
        subject_selectors=('[role="main"] h1', '[role="main"] h2', 'h1', 'h2'),
        body_selectors=('[role="document"]', '[role="main"] article', '[role="main"]'),
    ),
}


_GENERIC_ROWS = (
    '[role="option"]',
    '[role="row"]',
    '[role="listitem"]',
    '[data-automationid*="message" i]',
    '[data-app-section*="MailList" i] [data-is-focusable="true"]',
    '[role="main"] [data-is-focusable="true"]',
    '[role="main"] [tabindex="0"]',
    '[role="listbox"] > *',
    '[role="grid"] [role="row"]',
    'tr',
)
_GENERIC_SUBJECTS = ('[role="main"] h1', '[role="main"] h2', 'h1', 'h2', '[class*="subject"]')
_GENERIC_BODIES = ('[role="document"]', 'article', '[role="main"]', '[class*="messageBody"]', '[class*="mailBody"]')


def detect_provider(email: str) -> str | None:
    domain = email.strip().lower().rsplit('@', 1)[-1] if '@' in email else ''
    exact = {
        'gmail.com': 'gmail', 'googlemail.com': 'gmail',
        'outlook.com': 'outlook', 'hotmail.com': 'outlook', 'live.com': 'outlook',
        'connect.hku.hk': 'outlook', 'hku.hk': 'outlook',
        'icloud.com': 'icloud', 'me.com': 'icloud', 'mac.com': 'icloud',
        'yahoo.com': 'yahoo', 'yahoo.com.hk': 'yahoo', 'aol.com': 'aol',
        'qq.com': 'qq', '163.com': '163', '126.com': '126',
        'proton.me': 'proton', 'protonmail.com': 'proton',
        'yandex.com': 'yandex', 'yandex.ru': 'yandex',
        'gmx.com': 'gmx', 'gmx.de': 'gmx', 'mail.com': 'mailcom',
        'fastmail.com': 'fastmail', 'zoho.com': 'zoho',
    }
    return exact.get(domain)


def provider_options() -> list[dict[str, str]]:
    return ([{'key': 'auto', 'label': 'Auto-detect from email'}] +
            [{'key': p.key, 'label': p.label} for p in PROVIDERS.values()] +
            [{'key': 'custom', 'label': 'Custom webmail'}])


def _compact(text: str) -> str:
    return re.sub(r'\s+', ' ', text or '').strip()


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8', 'ignore')).hexdigest()


def _safe_profile_name(provider: str, email: str) -> str:
    hint = re.sub(r'[^a-zA-Z0-9._-]+', '_', email)[:48].strip('._-') or 'account'
    return f'{provider}-{hint}-{_hash(provider + "|" + email)[:10]}'


class BrowserMailboxClient:
    """Best-effort webmail automation using an isolated Playwright profile.

    The user signs in directly on the provider's website, including MFA/SSO/QR flows.
    Mail Radar never receives the password. Browser cookies/session storage live inside the
    isolated local profile directory and are reused for later background scans. Opening a
    message in a web UI can change its read/unread state depending on the provider.
    """

    def __init__(self, provider: str, email: str, custom_url: str | None = None):
        self.settings = get_settings()
        requested_provider = (provider or '').strip().lower()
        self.email = email.strip().lower()
        if requested_provider == 'auto':
            requested_provider = detect_provider(self.email) or ''
            if not requested_provider:
                raise ValueError('Mail Radar could not auto-detect this webmail provider. Choose a provider or Custom webmail.')
        self.provider = requested_provider
        if self.provider != 'custom' and self.provider not in PROVIDERS:
            raise ValueError(f'Unsupported webmail provider: {self.provider}')
        self.definition = PROVIDERS.get(self.provider)
        self.start_url = (custom_url or (self.definition.inbox_url if self.definition else '')).strip()
        if not self.start_url.startswith(('http://', 'https://')):
            raise ValueError('Custom webmail URL must start with http:// or https://.')
        root = Path(self.settings.browser_profiles_dir)
        self.profile_dir = root / _safe_profile_name(self.provider, self.email)
        self.marker_file = self.profile_dir / '.mail_radar_connected.json'

    @property
    def label(self) -> str:
        return self.definition.label if self.definition else 'Custom webmail'

    @staticmethod
    def dependency_available() -> bool:
        try:
            import playwright  # noqa: F401
            return True
        except Exception:
            return False

    def session_available(self) -> bool:
        return self.marker_file.exists() and self.profile_dir.exists()

    def clear_session(self) -> None:
        if self.profile_dir.exists():
            shutil.rmtree(self.profile_dir, ignore_errors=True)

    def _write_marker(self, page_url: str) -> None:
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        self.marker_file.write_text(
            json.dumps(
                {
                    'provider': self.provider,
                    'email': self.email,
                    'connected_at': datetime.now(timezone.utc).isoformat(),
                    'last_url': page_url,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding='utf-8',
        )

    def _launch(self, playwright: Any, *, headless: bool):
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        base: dict[str, Any] = {
            'user_data_dir': str(self.profile_dir),
            'headless': headless,
            'viewport': {'width': 1440, 'height': 980},
            'locale': 'en-US',
            'accept_downloads': False,
            'args': ['--disable-notifications'],
        }

        # Reuse a normal installed browser when possible. This avoids requiring a separate
        # Playwright browser download on most Windows machines and tends to work better with
        # enterprise SSO/MFA pages. Each attempt still uses Mail Radar's isolated profile.
        channels: list[str | None] = []
        configured = (self.settings.browser_channel or '').strip()
        if configured:
            channels.append(configured)
        for candidate in ('msedge', 'chrome'):
            if candidate not in channels:
                channels.append(candidate)
        channels.append(None)

        errors: list[str] = []
        for channel in channels:
            kwargs = dict(base)
            if channel:
                kwargs['channel'] = channel
            try:
                return playwright.chromium.launch_persistent_context(**kwargs)
            except Exception as exc:
                errors.append(f'{channel or "playwright-chromium"}: {exc}')

        raise RuntimeError(
            'No compatible Chromium browser could be started. Install Microsoft Edge/Google Chrome, '
            'or run `.venv\\Scripts\\python.exe -m playwright install chromium`. '
            f'Last browser errors: {" | ".join(errors[-2:])}'
        )

    def _looks_logged_in(self, page: Any) -> bool:
        url = (page.url or '').lower()
        parsed = urlparse(url)
        host = parsed.hostname or ''
        if self.provider == 'custom':
            bad = ('login', 'signin', 'sign-in', 'auth', 'sso', 'passport')
            if any(x in url for x in bad):
                return False
            return bool(host)

        assert self.definition is not None
        host_match = any(host == h or host.endswith('.' + h) for h in self.definition.inbox_hosts)
        if not host_match:
            return False
        # Common authentication routes can still live on the same host.
        if any(x in url for x in ('/login', '/signin', '/auth/', 'passport')):
            return False
        # Seeing at least one likely mailbox element is a stronger signal than URL alone.
        for selector in self.definition.row_selectors + ('[role="main"]',):
            try:
                if page.locator(selector).count() > 0:
                    return True
            except Exception:
                continue
        return host_match

    def connect_interactive(self, timeout_seconds: int | None = None) -> dict[str, Any]:
        if not self.dependency_available():
            raise RuntimeError('Playwright is not installed. Run: py bootstrap.py')
        from playwright.sync_api import sync_playwright

        timeout_seconds = timeout_seconds or self.settings.browser_login_timeout_seconds
        with sync_playwright() as p:
            context = self._launch(p, headless=False)
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.goto(self.start_url, wait_until='domcontentloaded', timeout=60000)
                deadline = time.monotonic() + timeout_seconds
                while time.monotonic() < deadline:
                    if page.is_closed():
                        raise RuntimeError('The sign-in browser was closed before Mail Radar detected the inbox.')
                    if self._looks_logged_in(page):
                        try:
                            page.wait_for_timeout(1500)
                        except Exception:
                            pass
                        self._write_marker(page.url)
                        return {'connected': True, 'url': page.url, 'provider': self.provider, 'label': self.label}
                    time.sleep(1)
                raise RuntimeError(
                    'Timed out waiting for the mailbox. Finish sign-in/MFA and wait until the inbox is visible, then reconnect.'
                )
            finally:
                try:
                    context.close()
                except Exception:
                    pass

    def _row_selectors(self) -> tuple[str, ...]:
        # Always append generic accessibility-based selectors. Provider-specific selectors
        # are faster and more precise, while the generic fallbacks survive many webmail UI
        # redesigns (for example when Outlook changes an option row from <div> to <button>).
        specific = self.definition.row_selectors if self.definition else ()
        return tuple(dict.fromkeys((*specific, *_GENERIC_ROWS)))

    def _subject_selectors(self) -> tuple[str, ...]:
        return self.definition.subject_selectors if self.definition else _GENERIC_SUBJECTS

    def _body_selectors(self) -> tuple[str, ...]:
        return self.definition.body_selectors if self.definition else _GENERIC_BODIES

    @staticmethod
    def _first_visible_text(page: Any, selectors: tuple[str, ...], max_chars: int = 1200) -> str:
        for selector in selectors:
            try:
                loc = page.locator(selector)
                count = min(loc.count(), 20)
                for idx in range(count):
                    el = loc.nth(idx)
                    if not el.is_visible():
                        continue
                    value = _compact(el.inner_text(timeout=1500))
                    if value:
                        return value[:max_chars]
            except Exception:
                continue
        return ''

    @staticmethod
    def _longest_visible_text(page: Any, selectors: tuple[str, ...], max_chars: int = 120000) -> str:
        best = ''
        for selector in selectors:
            try:
                loc = page.locator(selector)
                count = min(loc.count(), 30)
                for idx in range(count):
                    el = loc.nth(idx)
                    if not el.is_visible():
                        continue
                    value = el.inner_text(timeout=2000).strip()
                    if len(value) > len(best):
                        best = value
            except Exception:
                continue
        return best[:max_chars]

    @staticmethod
    def _extract_sender(page: Any, fallback: str = '') -> str:
        selectors = (
            'a[href^="mailto:"]',
            '[data-email-address]',
            '[email]',
            '[title*="@"]',
            '[aria-label*="@"]',
        )
        for selector in selectors:
            try:
                loc = page.locator(selector)
                count = min(loc.count(), 30)
                for idx in range(count):
                    el = loc.nth(idx)
                    if not el.is_visible():
                        continue
                    href = el.get_attribute('href') or ''
                    if href.lower().startswith('mailto:'):
                        return href[7:].split('?', 1)[0][:320]
                    for attr in ('data-email-address', 'email', 'title', 'aria-label'):
                        value = _compact(el.get_attribute(attr) or '')
                        match = re.search(r'[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}', value, re.I)
                        if match:
                            return match.group(0)[:320]
            except Exception:
                continue
        return fallback[:320]

    @staticmethod
    def _row_text(row: Any) -> str:
        try:
            text = row.inner_text(timeout=1500)
        except Exception:
            text = ''
        attrs = []
        for attr in (
            'aria-label', 'title', 'data-testid', 'data-test-id', 'data-automationid',
            'data-convid', 'data-item-id', 'data-itemid', 'data-message-id',
        ):
            try:
                value = row.get_attribute(attr)
            except Exception:
                value = None
            if value:
                attrs.append(value)
        return _compact(' '.join(attrs + [text]))

    @staticmethod
    def _row_cursor_key(row: Any, row_text: str) -> str:
        # Prefer identifiers used by major webmail SPAs. They are normally more stable than
        # visible row text, which may change when a message becomes read or its relative time updates.
        values: list[str] = []
        for attr in (
            'data-convid', 'data-item-id', 'data-itemid', 'data-message-id', 'data-thread-id',
            'data-legacy-thread-id', 'data-mailid', 'mailid', 'id', 'href',
        ):
            try:
                value = row.get_attribute(attr)
            except Exception:
                value = None
            if value and len(value) <= 2000:
                values.append(f'{attr}={value}')
        if values:
            return _hash('|'.join(values))
        return _hash(_compact(row_text).casefold())

    @staticmethod
    def _looks_like_navigation_row(text: str) -> bool:
        value = _compact(text).casefold()
        if not value:
            return True
        navigation = {
            'inbox', 'sent', 'sent items', 'drafts', 'deleted items', 'junk email',
            'archive', 'notes', 'calendar', 'people', 'groups', 'folders',
            '收件箱', '已发送', '草稿', '已删除', '垃圾邮件', '存档', '日历', '联系人',
        }
        if value in navigation:
            return True
        # Folder entries often append only an unread count, e.g. "Inbox 3".
        stripped = re.sub(r'[\s()\[\]0-9,+]+$', '', value).strip()
        return len(value) < 60 and stripped in navigation

    @staticmethod
    def _messageish_text_score(text: str) -> int:
        """Estimate whether visible/accessible text resembles a mail-list row.

        This intentionally uses several weak signals rather than one provider-specific DOM
        signature. Webmail SPAs frequently rename classes/test ids, while sender/subject/time
        information remains exposed for accessibility.
        """
        value = _compact(text)
        folded = value.casefold()
        if not value or len(value) < 10 or len(value) > 3000:
            return -20
        score = 1
        if re.search(r'[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}', value, re.I):
            score += 3
        if re.search(r'\b(?:today|yesterday|mon|tue|wed|thu|fri|sat|sun)\b', folded):
            score += 2
        if re.search(r'\b\d{1,2}:\d{2}(?:\s?[ap]m)?\b', folded):
            score += 2
        if re.search(r'\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{1,2}\b', folded):
            score += 2
        if re.search(r'\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b', folded):
            score += 1
        if any(token in folded for token in ('unread', 'read,', 'message', 'conversation', 'sender', 'subject')):
            score += 2
        # CJK Outlook/Gmail accessibility labels can contain these tokens.
        if any(token in value for token in ('未读', '已读', '邮件', '发件人', '主题')):
            score += 2
        return score

    def _candidate_score(self, loc: Any) -> tuple[int, int, int]:
        """Return (useful_rows, visible_rows, quality) for a candidate row locator.

        The old implementation accepted rows mostly by length. That was brittle when Outlook
        changed the element type used by its virtualised list. The new score also considers
        accessibility metadata, message identifiers and date/sender-like text.
        """
        try:
            count = min(loc.count(), 500)
        except Exception:
            return 0, 0, 0
        useful = 0
        visible = 0
        quality = 0
        for idx in range(min(count, 32)):
            try:
                el = loc.nth(idx)
                if not el.is_visible():
                    continue
                visible += 1
                row_text = self._row_text(el)
                if self._looks_like_navigation_row(row_text):
                    continue
                item_score = self._messageish_text_score(row_text)
                for attr in ('data-convid', 'data-item-id', 'data-itemid', 'data-message-id', 'data-thread-id', 'mailid'):
                    try:
                        if el.get_attribute(attr):
                            item_score += 4
                            break
                    except Exception:
                        pass
                try:
                    role = (el.get_attribute('role') or '').casefold()
                    if role in {'option', 'row', 'listitem'}:
                        item_score += 1
                except Exception:
                    pass
                try:
                    if el.locator('time').count() > 0:
                        item_score += 2
                except Exception:
                    pass
                if item_score >= 2:
                    useful += 1
                    quality += item_score
            except Exception:
                continue
        return useful, visible, quality

    def _mail_contexts(self, page: Any) -> list[Any]:
        # Most providers render the message list in the top frame. Some enterprise/custom
        # webmail products still embed mailbox panes in iframes, so inspect child frames too.
        contexts: list[Any] = [page]
        try:
            for frame in page.frames:
                if frame is page.main_frame:
                    continue
                contexts.append(frame)
        except Exception:
            pass
        return contexts

    def _find_rows(self, page: Any) -> tuple[Any | None, str | None, Any | None]:
        deadline = time.monotonic() + max(1.0, self.settings.browser_row_wait_ms / 1000.0)
        best: tuple[int, Any, str, Any] | None = None
        while time.monotonic() < deadline:
            for owner in self._mail_contexts(page):
                for selector in self._row_selectors():
                    try:
                        loc = owner.locator(selector)
                        useful, visible, quality = self._candidate_score(loc)
                        if useful:
                            specific = bool(self.definition and selector in self.definition.row_selectors)
                            # Multiple plausible siblings are a strong signal of a virtual mail list.
                            # Provider-specific selectors still win ties, while a high-quality generic
                            # candidate can recover from a provider DOM redesign.
                            score = useful * 14 + min(quality, 80) + min(visible, 12) + (28 if specific else 0)
                            if best is None or score > best[0]:
                                best = (score, loc, selector, owner)
                    except Exception:
                        continue
            if best is not None:
                return best[1], best[2], best[3]
            try:
                page.wait_for_timeout(500)
            except Exception:
                time.sleep(0.5)
        return None, None, None

    def _open_inbox_if_possible(self, page: Any) -> bool:
        """Best-effort recovery when a provider opens a landing/focused view instead of Inbox.

        Exact labels are used deliberately so we do not click arbitrary controls containing
        the word Inbox. This is only a recovery path after normal row discovery failed.
        """
        labels = ('Inbox', '收件箱')
        selectors = []
        for label in labels:
            selectors.extend((
                f'[role="treeitem"][aria-label^="{label}" i]',
                f'[title="{label}" i]',
                f'[aria-label="{label}" i]',
            ))
        for owner in self._mail_contexts(page):
            for selector in selectors:
                try:
                    loc = owner.locator(selector)
                    for idx in range(min(loc.count(), 8)):
                        el = loc.nth(idx)
                        if not el.is_visible():
                            continue
                        el.click(timeout=3000)
                        page.wait_for_timeout(max(1200, self.settings.browser_back_wait_ms))
                        return True
                except Exception:
                    continue
        return False

    def _inbox_looks_empty(self, page: Any) -> bool:
        phrases = (
            'your inbox is empty', 'nothing to see here', 'no messages', 'no mail',
            'this folder is empty', 'there are no items to show in this view',
            '收件箱为空', '没有邮件', '暂无邮件', '此文件夹为空',
        )
        for owner in self._mail_contexts(page):
            try:
                body = _compact(owner.locator('body').inner_text(timeout=1500)).casefold()
            except Exception:
                continue
            if any(phrase.casefold() in body for phrase in phrases):
                return True
        return False

    def _row_search_diagnostics(self, page: Any) -> str:
        """Return privacy-safe DOM counts for troubleshooting; never include message text."""
        try:
            host = urlparse(page.url or '').hostname or 'unknown-host'
        except Exception:
            host = 'unknown-host'
        contexts = self._mail_contexts(page)
        probes = (
            '[role="option"]', '[role="row"]', '[role="listitem"]',
            '[data-is-focusable="true"]', '[tabindex="0"]', 'tr',
        )
        totals: list[str] = []
        for selector in probes:
            total = 0
            for owner in contexts:
                try:
                    total += min(owner.locator(selector).count(), 9999)
                except Exception:
                    pass
            totals.append(f'{selector}={total}')
        return f'host={host}; frames={max(0, len(contexts)-1)}; ' + ', '.join(totals)

    @staticmethod
    def _fallback_subject(row_text: str) -> str:
        lines = [x.strip() for x in re.split(r'[\r\n]+', row_text) if x.strip()]
        if len(lines) >= 2:
            return lines[1][:500]
        return (lines[0] if lines else 'Email message')[:500]

    def _extract_open_message(self, page: Any, row_text: str, cursor_key: str) -> BrowserMessage:
        subject = self._first_visible_text(page, self._subject_selectors(), max_chars=500) or self._fallback_subject(row_text)
        body = self._longest_visible_text(page, self._body_selectors())
        if len(_compact(body)) < 30:
            body = row_text
        sender = self._extract_sender(page, fallback='')
        url = page.url or None
        canonical = '|'.join((self.provider, self.email, url or '', subject, sender, _compact(body)[:2000]))
        return BrowserMessage(
            cursor_key=cursor_key,
            message_id=_hash(canonical),
            subject=subject,
            sender=sender,
            body=body,
            received_at=None,
            source_url=url,
        )

    def scrape_messages(self, limit: int, stop_cursor: str | None = None, *, headless: bool | None = None) -> tuple[list[BrowserMessage], str | None]:
        if not self.session_available():
            raise RuntimeError('Browser sign-in session is unavailable. Use Reconnect in browser.')
        if not self.dependency_available():
            raise RuntimeError('Playwright is not installed. Run: py bootstrap.py')
        from playwright.sync_api import sync_playwright

        limit = max(1, min(int(limit), self.settings.browser_max_messages_per_sync))
        if headless is None:
            headless = self.settings.browser_headless_sync

        messages: list[BrowserMessage] = []
        new_cursor: str | None = None
        with sync_playwright() as p:
            context = self._launch(p, headless=headless)
            try:
                page = context.pages[0] if context.pages else context.new_page()
                page.goto(self.start_url, wait_until='domcontentloaded', timeout=60000)
                try:
                    page.wait_for_timeout(self.settings.browser_page_settle_ms)
                except Exception:
                    pass
                if not self._looks_logged_in(page):
                    raise RuntimeError('Webmail session expired. Click Reconnect in browser and sign in again.')

                rows, selector, row_owner = self._find_rows(page)
                if rows is None or selector is None or row_owner is None:
                    # Some Outlook/enterprise layouts restore the previous app pane instead of
                    # the Inbox after sign-in. Try the explicit Inbox entry once, then rescan.
                    if self._open_inbox_if_possible(page):
                        rows, selector, row_owner = self._find_rows(page)

                if rows is None or selector is None or row_owner is None:
                    if self._inbox_looks_empty(page):
                        return [], stop_cursor
                    diagnostics = self._row_search_diagnostics(page)
                    raise RuntimeError(
                        'Inbox opened, but Mail Radar could not recognize the message list after waiting for it to load. '
                        'The page may be using a new/virtualized layout, or the message pane may still be loading. '
                        'Use Visible sync and leave the Inbox open; if that still fails, reconnect the mailbox. '
                        f'Diagnostics: {diagnostics}'
                    )

                # Re-query after every navigation because single-page apps frequently recycle DOM nodes.
                row_index = 0
                examined = 0
                while len(messages) < limit and examined < max(limit * 4, 40):
                    examined += 1
                    rows = row_owner.locator(selector)
                    count = rows.count()
                    if row_index >= count:
                        break
                    row = rows.nth(row_index)
                    row_index += 1
                    try:
                        if not row.is_visible():
                            continue
                    except Exception:
                        continue
                    row_text = self._row_text(row)
                    if not (12 <= len(row_text) <= 2500):
                        continue
                    cursor_key = self._row_cursor_key(row, row_text)
                    if new_cursor is None:
                        new_cursor = cursor_key
                    if stop_cursor and cursor_key == stop_cursor:
                        break

                    inbox_url = page.url
                    try:
                        row.scroll_into_view_if_needed(timeout=2500)
                        row.click(timeout=5000)
                        page.wait_for_timeout(self.settings.browser_open_message_wait_ms)
                        msg = self._extract_open_message(page, row_text, cursor_key)
                        messages.append(msg)
                    except Exception:
                        # Even if opening the message fails, the inbox row still contains enough
                        # information for a conservative subject/snippet classification.
                        subject = self._fallback_subject(row_text)
                        canonical = '|'.join((self.provider, self.email, cursor_key, subject, row_text))
                        messages.append(BrowserMessage(
                            cursor_key=cursor_key,
                            message_id=_hash(canonical),
                            subject=subject,
                            sender='',
                            body=row_text,
                            received_at=None,
                            source_url=inbox_url,
                        ))

                    # Return to inbox before reading the next row.
                    try:
                        if page.url != inbox_url:
                            page.go_back(wait_until='domcontentloaded', timeout=15000)
                            page.wait_for_timeout(self.settings.browser_back_wait_ms)
                        else:
                            page.keyboard.press('Escape')
                    except Exception:
                        try:
                            page.goto(self.start_url, wait_until='domcontentloaded', timeout=30000)
                            page.wait_for_timeout(self.settings.browser_back_wait_ms)
                        except Exception:
                            break

                return messages, new_cursor or stop_cursor
            finally:
                try:
                    context.close()
                except Exception:
                    pass
