from __future__ import annotations

from dataclasses import dataclass

from .ai_config import effective_ai_config
from .classifier import Classification, contains_high_impact_signal


@dataclass(slots=True)
class ReviewDecision:
    should_review: bool
    reason: str


def decide_llm_review(classification: Classification, title: str, text: str, force: bool = False) -> ReviewDecision:
    config = effective_ai_config()
    if not config.enabled:
        return ReviewDecision(False, 'DeepSeek disabled')
    if not config.api_key:
        return ReviewDecision(False, 'DeepSeek API key missing')
    if force:
        return ReviewDecision(True, 'Forced by caller')
    if classification.confidence < config.confidence_threshold:
        return ReviewDecision(True, f'Rule confidence {classification.confidence:.2f} below threshold {config.confidence_threshold:.2f}')
    if config.review_high_impact and contains_high_impact_signal(title, text):
        return ReviewDecision(True, 'High-impact notice requires second-pass review')
    return ReviewDecision(False, 'Rule result sufficiently confident')
