from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parseaddr, parsedate_to_datetime
from typing import Any
from urllib.parse import quote

from ..config import get_settings
from .secret_vault import secret_vault
from .secure_cache import EncryptedFileStore


class GmailHistoryExpired(RuntimeError):
    pass


@dataclass(slots=True)
class GmailEnvelope:
    message_id: str
    subject: str
    sender: str
    received_at: datetime | None
    body: str
    body_type: str
    internet_message_id: str | None
    web_link: str | None
    history_id: str | None


class GoogleClientConfigStore:
    def __init__(self):
        settings = get_settings()
        self.store = EncryptedFileStore(settings.google_client_cache_path, settings.google_client_cache_key_path)

    @staticmethod
    def validate(data: dict[str, Any]) -> dict[str, Any]:
        # Desktop OAuth is the easiest and safest local flow for this project.
        installed = data.get('installed')
        if not isinstance(installed, dict):
            raise ValueError('Use a Google OAuth Client ID of type Desktop app. The JSON must contain an "installed" section.')
        if not installed.get('client_id') or not installed.get('auth_uri') or not installed.get('token_uri'):
            raise ValueError('The Google OAuth client JSON is missing required fields.')
        return data

    def save_json_text(self, raw: str) -> None:
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError('Google OAuth JSON is not valid JSON.') from exc
        self.validate(data)
        self.store.write_text(json.dumps(data, ensure_ascii=False))

    def load(self) -> dict[str, Any] | None:
        raw = self.store.read_text()
        if not raw:
            return None
        try:
            return self.validate(json.loads(raw))
        except Exception:
            return None

    def configured(self) -> bool:
        return self.load() is not None


google_client_store = GoogleClientConfigStore()


class GmailMailClient:
    """Gmail API read-only client with encrypted per-account OAuth token storage."""

    def __init__(self, email: str | None = None):
        self.settings = get_settings()
        self.email = (email or '').strip().lower() or None

    @staticmethod
    def _token_key(email: str) -> str:
        return f'gmail-token:{email.strip().lower()}'

    def _imports(self):
        try:
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
            from google_auth_oauthlib.flow import InstalledAppFlow
            from googleapiclient.discovery import build
            from googleapiclient.errors import HttpError
        except ImportError as exc:
            raise RuntimeError('Google API packages are missing. Run start_windows.bat again.') from exc
        return Request, Credentials, InstalledAppFlow, build, HttpError

    def connect_interactive(self, client_config_json: str | None = None, remember_client_config: bool = True) -> dict:
        if client_config_json:
            if remember_client_config:
                google_client_store.save_json_text(client_config_json)
            else:
                try:
                    client_config = GoogleClientConfigStore.validate(json.loads(client_config_json))
                except json.JSONDecodeError as exc:
                    raise ValueError('Google OAuth JSON is not valid JSON.') from exc
        else:
            client_config = None

        if client_config_json and remember_client_config:
            client_config = google_client_store.load()
        elif not client_config_json:
            client_config = google_client_store.load()
        if not client_config:
            raise RuntimeError('Google OAuth is not configured. Select the Desktop app credentials JSON downloaded from Google Cloud.')

        _, _, InstalledAppFlow, build, _ = self._imports()
        flow = InstalledAppFlow.from_client_config(client_config, scopes=self.settings.google_scope_list)
        credentials = flow.run_local_server(
            host='localhost',
            port=0,
            open_browser=True,
            authorization_prompt_message='Opening Google sign-in in your browser...',
            success_message='Mail Radar connected to Gmail. You can close this tab and return to the dashboard.',
        )
        service = build('gmail', 'v1', credentials=credentials, cache_discovery=False)
        profile = service.users().getProfile(userId='me').execute()
        email = str(profile.get('emailAddress') or '').strip().lower()
        if not email:
            raise RuntimeError('Google sign-in succeeded but Gmail did not return an account email address.')
        self.email = email
        secret_vault.set(self._token_key(email), json.loads(credentials.to_json()))
        return profile

    def _credentials(self):
        if not self.email:
            raise RuntimeError('A Gmail account email is required.')
        Request, Credentials, _, _, _ = self._imports()
        data = secret_vault.get(self._token_key(self.email))
        if not isinstance(data, dict):
            raise RuntimeError('Gmail authorization is not available. Reconnect this Gmail account.')
        creds = Credentials.from_authorized_user_info(data, scopes=self.settings.google_scope_list)
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            secret_vault.set(self._token_key(self.email), json.loads(creds.to_json()))
        if not creds.valid:
            raise RuntimeError('Gmail authorization expired or was revoked. Reconnect this Gmail account.')
        return creds

    def service(self):
        _, _, _, build, _ = self._imports()
        return build('gmail', 'v1', credentials=self._credentials(), cache_discovery=False)

    def credential_available(self) -> bool:
        return bool(self.email and secret_vault.has(self._token_key(self.email)))

    def sign_out(self) -> None:
        if self.email:
            secret_vault.delete(self._token_key(self.email))

    @staticmethod
    def _headers(message: dict) -> dict[str, str]:
        headers = {}
        for item in (message.get('payload') or {}).get('headers') or []:
            name = str(item.get('name') or '').casefold()
            if name and name not in headers:
                headers[name] = str(item.get('value') or '')
        return headers

    @staticmethod
    def _decode_b64(data: str | None) -> str:
        if not data:
            return ''
        try:
            padding = '=' * ((4 - len(data) % 4) % 4)
            raw = base64.urlsafe_b64decode(data + padding)
            for enc in ('utf-8', 'gb18030', 'big5', 'latin-1'):
                try:
                    return raw.decode(enc, errors='replace')
                except (LookupError, UnicodeDecodeError):
                    continue
        except Exception:
            return ''
        return ''

    @classmethod
    def _collect_parts(cls, part: dict, plain: list[str], html: list[str]) -> None:
        mime = str(part.get('mimeType') or '').casefold()
        body = part.get('body') or {}
        if mime == 'text/plain' and body.get('data'):
            plain.append(cls._decode_b64(body.get('data')))
        elif mime == 'text/html' and body.get('data'):
            html.append(cls._decode_b64(body.get('data')))
        for child in part.get('parts') or []:
            cls._collect_parts(child, plain, html)

    @classmethod
    def _to_envelope(cls, message: dict, account_email: str) -> GmailEnvelope | None:
        headers = cls._headers(message)
        plain: list[str] = []
        html: list[str] = []
        cls._collect_parts(message.get('payload') or {}, plain, html)
        body = '\n'.join(x for x in (html if html else plain) if x.strip())
        body_type = 'html' if html else 'text'
        if not body.strip():
            snippet = str(message.get('snippet') or '').strip()
            if not snippet:
                return None
            body = snippet
            body_type = 'text'

        received_at = None
        date_header = headers.get('date')
        if date_header:
            try:
                received_at = parsedate_to_datetime(date_header)
                if received_at and received_at.tzinfo is None:
                    received_at = received_at.replace(tzinfo=timezone.utc)
            except Exception:
                received_at = None
        if received_at is None and message.get('internalDate'):
            try:
                received_at = datetime.fromtimestamp(int(message['internalDate']) / 1000, tz=timezone.utc)
            except Exception:
                pass

        sender_header = headers.get('from', '')
        sender = parseaddr(sender_header)[1] or sender_header
        mid = str(message.get('id') or '')
        web_link = f'https://mail.google.com/mail/u/?authuser={quote(account_email)}#inbox/{mid}' if mid else None
        return GmailEnvelope(
            message_id=mid,
            subject=headers.get('subject', ''),
            sender=sender,
            received_at=received_at,
            body=body,
            body_type=body_type,
            internet_message_id=headers.get('message-id') or None,
            web_link=web_link,
            history_id=str(message.get('historyId') or '') or None,
        )

    def _get_message(self, service, message_id: str) -> GmailEnvelope | None:
        raw = service.users().messages().get(userId='me', id=message_id, format='full').execute()
        return self._to_envelope(raw, self.email or '')

    def initial_sync(self, limit: int = 100) -> tuple[list[GmailEnvelope], str]:
        service = self.service()
        limit = min(max(int(limit), 1), 500)
        response = service.users().messages().list(userId='me', labelIds=['INBOX'], maxResults=limit).execute()
        items = response.get('messages') or []
        envelopes: list[GmailEnvelope] = []
        newest_history = None
        for item in items:
            env = self._get_message(service, item['id'])
            if env:
                envelopes.append(env)
                if env.history_id:
                    try:
                        if newest_history is None or int(env.history_id) > int(newest_history):
                            newest_history = env.history_id
                    except ValueError:
                        newest_history = env.history_id
        if not newest_history:
            profile = service.users().getProfile(userId='me').execute()
            newest_history = str(profile.get('historyId') or '')
        return envelopes, newest_history or '0'

    def history_sync(self, start_history_id: str) -> tuple[list[GmailEnvelope], str]:
        service = self.service()
        _, _, _, _, HttpError = self._imports()
        page_token = None
        message_ids: list[str] = []
        newest_history = str(start_history_id)
        try:
            while True:
                request = service.users().history().list(
                    userId='me',
                    startHistoryId=str(start_history_id),
                    historyTypes=['messageAdded'],
                    labelId='INBOX',
                    pageToken=page_token,
                    maxResults=500,
                )
                data = request.execute()
                newest_history = str(data.get('historyId') or newest_history)
                for history in data.get('history') or []:
                    for added in history.get('messagesAdded') or []:
                        message = added.get('message') or {}
                        mid = message.get('id')
                        if mid and mid not in message_ids:
                            message_ids.append(mid)
                page_token = data.get('nextPageToken')
                if not page_token:
                    break
        except HttpError as exc:
            if getattr(exc, 'resp', None) is not None and exc.resp.status == 404:
                raise GmailHistoryExpired('Gmail history cursor expired; a full sync is required.') from exc
            raise

        envelopes: list[GmailEnvelope] = []
        for message_id in message_ids:
            env = self._get_message(service, message_id)
            if env:
                envelopes.append(env)
        return envelopes, newest_history
