from __future__ import annotations

import re
from dataclasses import dataclass

from bs4 import BeautifulSoup


@dataclass(slots=True)
class NoticeChunk:
    title: str
    text: str
    organizer: str | None = None
    posted_date_text: str | None = None
    url: str | None = None


META_RE = re.compile(
    r"^(?P<org>[^|]{2,200})\s*\|\s*(?P<date>\d{1,2}\s+[A-Za-z]{3,9}(?:\s+\d{4})?)\s*$",
    re.IGNORECASE,
)


def _normalize_lines(text: str) -> list[str]:
    lines = []
    for raw in text.replace("\xa0", " ").splitlines():
        line = re.sub(r"\s+", " ", raw).strip()
        if line:
            lines.append(line)
    return lines


def html_to_text(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    return soup.get_text("\n", strip=True)


def _links_by_text(html: str) -> dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    out: dict[str, str] = {}
    for a in soup.find_all("a", href=True):
        label = re.sub(r"\s+", " ", a.get_text(" ", strip=True)).strip()
        if label and len(label) >= 4:
            out[label.casefold()] = a["href"]
    return out


def split_email(subject: str, body: str, body_type: str = "text", source_url: str | None = None) -> list[NoticeChunk]:
    text = html_to_text(body) if body_type == "html" else body
    lines = _normalize_lines(text)
    links = _links_by_text(body) if body_type == "html" else {}

    # HKU Daily Notices / digest pattern: title line followed by "Organizer | date".
    chunks: list[NoticeChunk] = []
    for i, line in enumerate(lines):
        meta = META_RE.match(line)
        if not meta or i == 0:
            continue
        title = lines[i - 1]
        # Ignore headings that accidentally precede metadata.
        if title.casefold() in {"today's highlights", "todays highlights", "hku daily notices", "daily notices"}:
            continue
        chunks.append(
            NoticeChunk(
                title=title,
                text=f"{title}\n{line}",
                organizer=meta.group("org").strip(),
                posted_date_text=meta.group("date").strip(),
                url=links.get(title.casefold()) or source_url,
            )
        )

    if chunks:
        # De-duplicate while preserving source order.
        seen: set[tuple[str, str | None]] = set()
        result: list[NoticeChunk] = []
        for chunk in chunks:
            key = (chunk.title.casefold(), chunk.organizer.casefold() if chunk.organizer else None)
            if key not in seen:
                seen.add(key)
                result.append(chunk)
        return result

    # Generic newsletter fallback: headings/bullets as independent items only when enough signal exists.
    bullet_re = re.compile(r"^(?:[-•▪◦*]|\d+[.)])\s+(.+)$")
    bullet_chunks: list[NoticeChunk] = []
    for line in lines:
        m = bullet_re.match(line)
        if m and len(m.group(1)) >= 12:
            title = m.group(1).strip()
            bullet_chunks.append(NoticeChunk(title=title, text=title, url=source_url))
    if len(bullet_chunks) >= 3:
        return bullet_chunks

    # Normal email = one notice.
    fallback_title = subject.strip() or (lines[0] if lines else "Untitled notice")
    return [NoticeChunk(title=fallback_title, text=text.strip(), url=source_url)]
