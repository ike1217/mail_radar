from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

from ..timezones import get_timezone

MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

DATE_DMY = re.compile(r"\b(\d{1,2})\s+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)(?:\s+(\d{4}))?\b", re.I)
DATE_MDY = re.compile(r"\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2})(?:,?\s+(\d{4}))?\b", re.I)


@dataclass(slots=True)
class Extracted:
    event_date: datetime | None
    deadline: datetime | None
    location: str | None
    language: str
    action_required: bool
    registration_required: bool


def _make_date(day: int, month: int, year: int, tz_name: str) -> datetime | None:
    try:
        return datetime(year, month, day, 12, 0, tzinfo=get_timezone(tz_name))
    except ValueError:
        return None


def parse_dates(text: str, reference: datetime | None, tz_name: str) -> list[tuple[datetime, tuple[int, int]]]:
    ref = reference or datetime.now(get_timezone(tz_name))
    found: list[tuple[datetime, tuple[int, int]]] = []

    for m in DATE_DMY.finditer(text):
        day = int(m.group(1))
        month = MONTHS[m.group(2).lower()[:3]]
        year = int(m.group(3)) if m.group(3) else ref.year
        dt = _make_date(day, month, year, tz_name)
        if dt:
            found.append((dt, m.span()))

    for m in DATE_MDY.finditer(text):
        month = MONTHS[m.group(1).lower()[:3]]
        day = int(m.group(2))
        year = int(m.group(3)) if m.group(3) else ref.year
        dt = _make_date(day, month, year, tz_name)
        if dt:
            found.append((dt, m.span()))

    found.sort(key=lambda x: x[1][0])
    return found


def detect_language(text: str) -> str:
    lower = text.casefold()
    if any(k in lower for k in ["cantonese", "廣東話", "粤语", "粵語"]):
        if "english" in lower or "bilingual" in lower:
            return "bilingual"
        return "cantonese"
    if any(k in lower for k in ["mandarin", "普通話", "普通话"]):
        if "english" in lower or "bilingual" in lower:
            return "bilingual"
        return "mandarin"
    if any(k in lower for k in ["bilingual", "english and chinese", "english & chinese", "雙語", "双语"]):
        return "bilingual"
    if "english" in lower:
        return "english"
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    latin_chars = len(re.findall(r"[A-Za-z]", text))
    if chinese_chars > 15 and latin_chars > 30:
        return "bilingual"
    if chinese_chars > latin_chars:
        return "chinese"
    if latin_chars >= 20:
        return "english"
    return "unknown"


def detect_location(text: str) -> str | None:
    patterns = [
        r"(?:venue|location|room)\s*[:：]\s*([^\n;|]{2,100})",
        r"\b(?:at|in|to)\s+((?:CPD|CYPP|LE|MB|KK|MW|TT|KB|CBA|LG|Room|Lecture Theatre)[A-Za-z0-9 ._-]{1,50})",
    ]
    for p in patterns:
        m = re.search(p, text, re.I)
        if m:
            return re.sub(r"\s+", " ", m.group(1)).strip(" .,-")
    return None


def extract_fields(text: str, title: str, reference: datetime | None, tz_name: str) -> Extracted:
    combined = f"{title}\n{text}"
    lower = combined.casefold()
    dates = parse_dates(combined, reference, tz_name)

    deadline = None
    event_date = None
    for dt, span in dates:
        context = combined[max(0, span[0] - 50): min(len(combined), span[1] + 50)].casefold()
        if any(k in context for k in ["deadline", "due", "apply by", "register by", "registration closes", "closing date", "last day"]):
            if deadline is None:
                deadline = dt
        elif event_date is None:
            event_date = dt

    if event_date is None and dates:
        event_date = dates[0][0]

    # Common operational email language often uses relative dates instead of absolute dates.
    ref = reference or datetime.now(get_timezone(tz_name))
    ref_local = ref.astimezone(get_timezone(tz_name)) if ref.tzinfo else ref.replace(tzinfo=get_timezone(tz_name))
    relative_dt = None
    if re.search(r"\btomorrow\b", lower):
        from datetime import timedelta
        relative_dt = ref_local + timedelta(days=1)
    elif re.search(r"\b(today|tonight)\b", lower):
        relative_dt = ref_local
    if relative_dt is not None:
        relative_dt = relative_dt.replace(hour=12, minute=0, second=0, microsecond=0)
        if any(k in lower for k in ["due tomorrow", "due today", "due tonight", "deadline tomorrow", "deadline today", "submit tomorrow", "submit today"]):
            deadline = deadline or relative_dt
        else:
            event_date = event_date or relative_dt

    action_required = any(k in lower for k in [
        "action required", "please submit", "submit by", "deadline", "due ", "register now",
        "registration", "apply now", "apply by", "complete the", "must ", "required to",
    ])
    registration_required = any(k in lower for k in ["register", "registration", "rsvp", "sign up", "enrol now", "enroll now"])

    return Extracted(
        event_date=event_date,
        deadline=deadline,
        location=detect_location(combined),
        language=detect_language(combined),
        action_required=action_required,
        registration_required=registration_required,
    )
