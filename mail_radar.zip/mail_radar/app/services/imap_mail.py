from __future__ import annotations

import imaplib
import ssl
from dataclasses import dataclass
from datetime import datetime, timezone
from email import message_from_bytes
from email.header import decode_header
from email.message import Message
from email.utils import parseaddr, parsedate_to_datetime


@dataclass(slots=True)
class IMAPConfig:
    email: str
    password: str
    provider: str = 'auto'
    host: str | None = None
    port: int = 993
    folder: str = 'INBOX'
    username: str | None = None


@dataclass(slots=True)
class MailEnvelope:
    uid: str
    subject: str
    sender: str
    received_at: datetime | None
    body: str
    body_type: str
    internet_message_id: str | None


_PROVIDER_HOSTS = {
    'outlook': 'outlook.office365.com',
    'microsoft': 'outlook.office365.com',
    'office365': 'outlook.office365.com',
    'gmail': 'imap.gmail.com',
    'icloud': 'imap.mail.me.com',
    'yahoo': 'imap.mail.yahoo.com',
    'qq': 'imap.qq.com',
    '163': 'imap.163.com',
    '126': 'imap.126.com',
    'zoho': 'imap.zoho.com',
    'fastmail': 'imap.fastmail.com',
}

_PROVIDER_LABELS = {
    'outlook': 'Microsoft / Outlook IMAP',
    'gmail': 'Gmail IMAP',
    'icloud': 'iCloud Mail',
    'yahoo': 'Yahoo Mail',
    'qq': 'QQ Mail',
    '163': '163 Mail',
    '126': '126 Mail',
    'zoho': 'Zoho Mail',
    'fastmail': 'Fastmail',
    'custom': 'Custom IMAP',
}


def infer_provider(email_address: str) -> str:
    domain = email_address.strip().lower().rsplit('@', 1)[-1] if '@' in email_address else ''
    if domain in {'outlook.com', 'hotmail.com', 'live.com', 'msn.com', 'hku.hk', 'connect.hku.hk'} or domain.endswith('.hku.hk'):
        return 'outlook'
    if domain in {'gmail.com', 'googlemail.com'}:
        return 'gmail'
    if domain in {'icloud.com', 'me.com', 'mac.com'}:
        return 'icloud'
    if domain in {'yahoo.com', 'yahoo.co.uk', 'ymail.com'} or domain.startswith('yahoo.'):
        return 'yahoo'
    if domain == 'qq.com':
        return 'qq'
    if domain == '163.com':
        return '163'
    if domain == '126.com':
        return '126'
    if domain.endswith('zoho.com') or domain.endswith('zohomail.com'):
        return 'zoho'
    if domain in {'fastmail.com', 'fastmail.fm'}:
        return 'fastmail'
    return 'custom'


def resolve_host(provider: str, email_address: str, custom_host: str | None = None) -> tuple[str, str]:
    provider = (provider or 'auto').strip().lower()
    if provider == 'auto':
        provider = infer_provider(email_address)
    if provider == 'custom':
        if not custom_host or not custom_host.strip():
            raise ValueError('A custom IMAP server is required for the selected provider.')
        return provider, custom_host.strip()
    if provider not in _PROVIDER_HOSTS:
        raise ValueError(f'Unsupported provider: {provider}')
    return provider, _PROVIDER_HOSTS[provider]


def provider_label(provider: str) -> str:
    return _PROVIDER_LABELS.get(provider, provider.upper())


def _decode_header_value(value: str | None) -> str:
    if not value:
        return ''
    parts: list[str] = []
    for chunk, encoding in decode_header(value):
        if isinstance(chunk, bytes):
            tried = []
            for enc in (encoding, 'utf-8', 'gb18030', 'big5', 'latin-1'):
                if not enc or enc in tried:
                    continue
                tried.append(enc)
                try:
                    parts.append(chunk.decode(enc, errors='replace'))
                    break
                except (LookupError, UnicodeDecodeError):
                    continue
            else:
                parts.append(chunk.decode('utf-8', errors='replace'))
        else:
            parts.append(chunk)
    return ''.join(parts).strip()


def _decode_payload(part: Message) -> str:
    payload = part.get_payload(decode=True)
    if payload is None:
        raw = part.get_payload()
        return raw if isinstance(raw, str) else ''
    charset = part.get_content_charset() or 'utf-8'
    for enc in (charset, 'utf-8', 'gb18030', 'big5', 'latin-1'):
        try:
            return payload.decode(enc, errors='replace')
        except LookupError:
            continue
    return payload.decode('utf-8', errors='replace')


def _extract_body(msg: Message) -> tuple[str, str]:
    plain_parts: list[str] = []
    html_parts: list[str] = []
    if msg.is_multipart():
        for part in msg.walk():
            if part.is_multipart():
                continue
            disposition = (part.get('Content-Disposition') or '').lower()
            if 'attachment' in disposition:
                continue
            ctype = part.get_content_type().lower()
            if ctype == 'text/plain':
                plain_parts.append(_decode_payload(part))
            elif ctype == 'text/html':
                html_parts.append(_decode_payload(part))
    else:
        ctype = msg.get_content_type().lower()
        if ctype == 'text/html':
            html_parts.append(_decode_payload(msg))
        elif ctype == 'text/plain':
            plain_parts.append(_decode_payload(msg))
    if html_parts:
        return '\n'.join(p for p in html_parts if p.strip()), 'html'
    return '\n'.join(p for p in plain_parts if p.strip()), 'text'


def _received_at(msg: Message) -> datetime | None:
    value = msg.get('Date')
    if not value:
        return None
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except (TypeError, ValueError, OverflowError):
        return None


def _uidvalidity(conn: imaplib.IMAP4_SSL) -> str:
    try:
        status, data = conn.response('UIDVALIDITY')
        if status == 'UIDVALIDITY' and data and data[0]:
            raw = data[0]
            if isinstance(raw, bytes):
                return raw.decode('ascii', errors='ignore') or '0'
            return str(raw)
    except Exception:
        pass
    return '0'


class IMAPMailboxClient:
    """Read-only IMAP client using BODY.PEEK so fetched messages remain unread."""

    def __init__(self, config: IMAPConfig):
        self.config = config
        self.provider, self.host = resolve_host(config.provider, config.email, config.host)

    @property
    def label(self) -> str:
        return provider_label(self.provider)

    def _connect(self) -> imaplib.IMAP4_SSL:
        context = ssl.create_default_context()
        conn = imaplib.IMAP4_SSL(self.host, self.config.port, ssl_context=context, timeout=30)
        username = (self.config.username or self.config.email).strip()
        try:
            conn.login(username, self.config.password)
        except imaplib.IMAP4.error as exc:
            try:
                conn.logout()
            except Exception:
                pass
            if self.provider == 'outlook':
                raise RuntimeError(
                    'Microsoft/Outlook rejected password-only IMAP sign-in. Use Microsoft OAuth in Mail Radar instead.'
                ) from exc
            if self.provider == 'gmail':
                raise RuntimeError(
                    'Gmail rejected password IMAP sign-in. Use the Gmail OAuth button, or an app password if your account allows one.'
                ) from exc
            if self.provider == 'icloud':
                raise RuntimeError(
                    'iCloud rejected the sign-in. Use an Apple app-specific password rather than your normal Apple Account password.'
                ) from exc
            raise RuntimeError(f'Mailbox authentication failed: {exc}') from exc
        return conn

    def _select(self, conn: imaplib.IMAP4_SSL) -> str:
        status, _ = conn.select(self.config.folder, readonly=True)
        if status != 'OK':
            raise RuntimeError(f'Could not open mailbox folder: {self.config.folder}')
        return _uidvalidity(conn)

    def test_connection(self) -> None:
        conn = self._connect()
        try:
            self._select(conn)
        finally:
            try:
                conn.logout()
            except Exception:
                pass

    @staticmethod
    def _parse_message(uid: str, raw: bytes) -> MailEnvelope | None:
        msg = message_from_bytes(raw)
        subject = _decode_header_value(msg.get('Subject'))
        sender_header = _decode_header_value(msg.get('From'))
        sender = parseaddr(sender_header)[1] or sender_header
        body, body_type = _extract_body(msg)
        if not body.strip():
            return None
        message_id = (msg.get('Message-ID') or '').strip() or None
        return MailEnvelope(
            uid=uid,
            subject=subject,
            sender=sender,
            received_at=_received_at(msg),
            body=body,
            body_type=body_type,
            internet_message_id=message_id,
        )

    @staticmethod
    def _fetch_uid(conn: imaplib.IMAP4_SSL, uid: str) -> MailEnvelope | None:
        status, fetched = conn.uid('fetch', uid, '(BODY.PEEK[])')
        if status != 'OK' or not fetched:
            return None
        raw = next((item[1] for item in fetched if isinstance(item, tuple) and len(item) > 1), None)
        if not raw:
            return None
        return IMAPMailboxClient._parse_message(uid, raw)

    def fetch_incremental(self, cursor: str | None = None, limit: int = 100) -> tuple[list[MailEnvelope], str]:
        """Fetch recent/new messages and return an opaque `UIDVALIDITY:last_uid` cursor."""
        limit = min(max(int(limit), 1), 500)
        conn = self._connect()
        try:
            validity = self._select(conn)
            previous_validity = None
            last_uid = 0
            if cursor and ':' in cursor:
                previous_validity, raw_uid = cursor.split(':', 1)
                try:
                    last_uid = int(raw_uid)
                except ValueError:
                    last_uid = 0
            if previous_validity != validity:
                last_uid = 0

            status, data = conn.uid('search', None, 'ALL')
            if status != 'OK' or not data:
                return [], f'{validity}:{last_uid}'
            all_uids = []
            for raw in data[0].split():
                try:
                    value = int(raw.decode('ascii', errors='ignore'))
                except ValueError:
                    continue
                if value > last_uid:
                    all_uids.append(value)

            # Initial connection scans only the newest N; later syncs process all new
            # messages up to the safety cap so normal polling cannot skip mail.
            if not cursor or previous_validity != validity:
                selected = all_uids[-limit:]
            else:
                selected = all_uids[:500]

            messages: list[MailEnvelope] = []
            for value in selected:
                item = self._fetch_uid(conn, str(value))
                if item:
                    messages.append(item)
            # On the first scan we intentionally baseline at the newest UID so
            # messages older than the configured initial window stay ignored. On
            # incremental scans, advance only through the batch actually fetched;
            # otherwise a >500-message burst could be skipped permanently.
            if not cursor or previous_validity != validity:
                newest = max(last_uid, max(all_uids, default=last_uid))
            else:
                newest = max(last_uid, max(selected, default=last_uid))
            return messages, f'{validity}:{newest}'
        finally:
            try:
                conn.logout()
            except Exception:
                pass

    def fetch_recent(self, limit: int = 100):
        messages, _ = self.fetch_incremental(None, limit)
        yield from messages
