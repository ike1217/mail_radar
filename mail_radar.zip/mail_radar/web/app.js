const $ = (s) => document.querySelector(s);
const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

const LABELS = {
  class_cancellation:'Class cancellation', venue_change:'Venue change', assignment:'Assignment', exam:'Exam',
  registration:'Registration', holiday:'Holiday', administration:'Administration', lecture:'Lecture', seminar:'Seminar',
  conference:'Conference', workshop:'Workshop', competition:'Competition', volunteering:'Volunteering', networking:'Networking',
  festival:'Festival', wellbeing:'Wellbeing', internship:'Internship', graduate_programme:'Graduate programme',
  research_assistant:'Research assistant', teaching_assistant:'Teaching assistant', student_assistant:'Student assistant',
  part_time:'Part-time', job:'Job'
};
const LANG = {english:'English', cantonese:'Cantonese', mandarin:'Mandarin', bilingual:'Bilingual', chinese:'Chinese', unknown:'Language not specified'};
const COMPANY = {large:'Large / Global', mid:'Mid-size', startup:'Startup / Small', unknown:'Company size unknown'};
const PROVIDER_ICON = {microsoft:'M', gmail:'G', imap:'@', browser:'◉'};

function fmtDate(v){ if(!v) return null; const d=new Date(v); return Number.isNaN(d.getTime())?v:d.toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'}); }
function fmtDateTime(v){ if(!v) return 'never'; const d=new Date(v); return Number.isNaN(d.getTime())?v:d.toLocaleString(undefined,{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}); }
function maskEmail(v){ if(!v||!v.includes('@')) return v||''; const [u,d]=v.split('@'); return `${u.slice(0,2)}${u.length>2?'•••':''}@${d}`; }
function priorityLabel(n){ const p=n.priority||0; if(p>=80)return['P0','high']; if(p>=55)return['P1','medium']; return['P2','']; }

function card(n, mode){
  const [p,pc]=priorityLabel(n); const badges=[];
  badges.push(`<span class="badge blue">${esc(LABELS[n.subcategory]||n.subcategory)}</span>`);
  if(n.language&&n.language!=='unknown') badges.push(`<span class="badge">${esc(LANG[n.language]||n.language)}</span>`);
  if(n.action_required) badges.push('<span class="badge red">Action required</span>');
  if(n.registration_required) badges.push('<span class="badge amber">Registration</span>');
  if(n.llm_reviewed) badges.push('<span class="badge ai">AI reviewed</span>');
  if(mode==='career'&&n.company_size&&n.company_size!=='unknown') badges.push(`<span class="badge green">${esc(COMPANY[n.company_size]||n.company_size)}</span>`);
  const meta=[];
  if(n.event_date) meta.push(`📅 ${fmtDate(n.event_date)}`);
  if(n.deadline) meta.push(`⏰ Deadline: ${fmtDate(n.deadline)}`);
  if(n.location) meta.push(`📍 ${esc(n.location)}`);
  if(n.organizer) meta.push(`🏛 ${esc(n.organizer)}`);
  if(n.company_name) meta.push(`🏢 ${esc(n.company_name)}`);
  const link=n.url?`<a href="${esc(n.url)}" target="_blank" rel="noreferrer">Open source ↗</a>`:'';
  const source=[n.source_provider?String(n.source_provider).toUpperCase():'EMAIL',n.source_account?maskEmail(n.source_account):'',n.source_sender||''].filter(Boolean).join(' · ');
  return `<article class="card"><div class="card-top"><h3>${esc(n.title)}</h3><span class="priority ${pc}">${p}</span></div><div class="badges">${badges.join('')}</div><div class="meta">${meta.map(x=>`<div>${x}</div>`).join('')}</div>${n.summary?`<p class="summary">${esc(n.summary)}</p>`:''}<details class="explain"><summary>Why was this classified here?</summary><div>Rule: ${esc(n.rule_category)} / ${esc(n.rule_subcategory)} · ${Math.round((n.rule_confidence||0)*100)}%</div><div>${esc(n.rule_reason||'')}</div>${n.llm_reviewed?`<div>DeepSeek: ${esc(n.llm_category||'fallback')} · ${n.llm_confidence==null?'-':Math.round(n.llm_confidence*100)+'%'}</div><div>${esc(n.llm_reason||n.llm_error||'')}</div>`:''}</details><div class="card-footer"><span>${esc(source||n.source_subject||'Email')}</span>${link}</div></article>`;
}
function renderSimple(el,items,mode){ el.innerHTML=items.length?items.map(n=>card(n,mode)).join(''):'<div class="empty">No items</div>'; }
function renderActivity(items){ const el=$('#activityList'); if(!items.length)return renderSimple(el,[],'activity'); let current=''; const out=[]; for(const n of items){const group=`${LANG[n.language]||n.language} · ${LABELS[n.subcategory]||n.subcategory}`; if(group!==current){out.push(`<div class="group-title">${esc(group)}</div>`);current=group;}out.push(card(n,'activity'));}el.innerHTML=out.join(''); }
function renderCareer(items){ const el=$('#careerList'); if(!items.length)return renderSimple(el,[],'career'); let current=''; const out=[]; for(const n of items){const scope=n.job_scope==='internal'?'🏫 Internal':'🌏 External';const group=`${scope} · ${COMPANY[n.company_size]||n.company_size}`;if(group!==current){out.push(`<div class="group-title">${esc(group)}</div>`);current=group;}out.push(card(n,'career'));}el.innerHTML=out.join(''); }

function toast(message,error=false){ const el=document.createElement('div');el.className=`toast${error?' error':''}`;el.textContent=message;document.body.appendChild(el);setTimeout(()=>el.remove(),6000); }
async function jsonOrError(response){ const data=await response.json().catch(()=>({})); if(!response.ok)throw new Error(data.detail||data.message||`Request failed (${response.status})`); return data; }
async function loadDashboard(){ const data=await jsonOrError(await fetch('/api/dashboard')); $('#totalCount').textContent=data.total_count;$('#schoolCount').textContent=data.school.length;$('#activityCount').textContent=data.activity.length;$('#careerCount').textContent=data.career.length;$('#aiCount').textContent=data.llm_reviewed_count;$('#ignoredCount').textContent=data.ignored_count;renderSimple($('#schoolList'),data.school,'school');renderActivity(data.activity);renderCareer(data.career); }

function accountCard(a){
  const state=!a.enabled?'Paused':(!a.credential_available?'Reconnect required':(a.last_error?'Needs attention':'Active'));
  const stateClass=a.enabled&&a.credential_available&&!a.last_error?'':'paused';
  const error=a.last_error?`<div class="account-error">${esc(a.last_error)}</div>`:'';
  const browserActions=a.provider==='browser'?`<button data-account-action="sync-visible" data-id="${a.id}">Visible sync</button><button data-account-action="reconnect-browser" data-id="${a.id}">Reconnect</button>`:'';
  return `<article class="account-card ${a.last_error?'error':''} ${a.enabled?'':'disabled'}"><div class="account-card-top"><div class="account-provider"><span class="provider-icon">${esc(PROVIDER_ICON[a.provider]||'@')}</span><div><h3>${esc(a.provider_label||a.provider)}</h3><p class="account-email">${esc(a.email)}</p></div></div><span class="account-state ${stateClass}">${esc(state)}</span></div><div class="account-meta"><span>${esc(a.sync_mode||'Sync')} · every ${Math.round((a.interval_seconds||300)/60)} min</span><span>Last sync: ${esc(fmtDateTime(a.last_sync_at))} · ${a.messages_scanned||0} messages checked</span></div>${error}<div class="account-actions"><button data-account-action="sync" data-id="${a.id}">Sync now</button>${browserActions}<button data-account-action="${a.enabled?'pause':'enable'}" data-id="${a.id}">${a.enabled?'Pause':'Resume'}</button><button class="remove" data-account-action="remove" data-id="${a.id}">Remove</button></div></article>`;
}
async function loadAccounts(){ const data=await jsonOrError(await fetch('/api/accounts')); $('#accountList').innerHTML=data.accounts.length?data.accounts.map(accountCard).join(''):'<div class="account-empty">No mailbox connected yet. Click Connect Webmail to add Outlook, Gmail, iCloud, Yahoo, QQ, 163/126, Zoho, Fastmail, Proton, or a custom webmail site.</div>'; return data; }

function populateBrowserProviders(providers){
  const select=$('#browserProvider');
  const current=select.value;
  select.innerHTML=(providers||[]).map(p=>`<option value="${esc(p.key)}">${esc(p.label)}</option>`).join('');
  if(current && [...select.options].some(o=>o.value===current)) select.value=current;
  else if([...select.options].some(o=>o.value==='auto')) select.value='auto';
  $('#customWebmailRow').hidden=select.value!=='custom';
}
async function loadSetup(){
  const data=await jsonOrError(await fetch('/api/accounts/setup'));
  $('#msTenant').value=data.microsoft_tenant_id||'organizations';
  $('#gmailConfigHint').textContent=data.gmail_configured?'Google OAuth configuration is already saved. You can connect without selecting the JSON file again.':'First-time Gmail API setup requires the Desktop app OAuth JSON file.';
  populateBrowserProviders(data.browser_providers||[]);
  if(!data.browser_connector_available) toast('Webmail browser connector is not installed. Run the launcher once to install dependencies.',true);
  return data;
}
async function refreshAll(){ await Promise.all([loadDashboard(),loadAccounts(),loadCalendar()]); }
function openDialog(id){ document.getElementById(id).showModal(); }
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>document.getElementById(b.dataset.close).close()));

$('#refreshBtn').addEventListener('click',async()=>{try{await refreshAll();toast('Dashboard refreshed');}catch(e){toast(e.message,true);}});
$('#seedBtn').addEventListener('click',async()=>{try{await jsonOrError(await fetch('/api/demo/seed',{method:'POST'}));await refreshAll();toast('Demo data loaded');}catch(e){toast(e.message,true);}});
$('#syncAllBtn').addEventListener('click',async()=>{const b=$('#syncAllBtn');b.disabled=true;b.textContent='Syncing…';try{const r=await jsonOrError(await fetch('/api/accounts/sync-all',{method:'POST'}));await refreshAll();toast(r.errors?.length?`Synced ${r.synced_accounts} mailbox(es); ${r.errors.length} need attention.`:`Synced ${r.synced_accounts} mailbox(es).`,!!r.errors?.length);}catch(e){toast(e.message,true);}finally{b.disabled=false;b.textContent='Sync all';}});

$('#addBrowserBtn').addEventListener('click',async()=>{try{await loadSetup();}catch{}openDialog('browserDialog');});
$('#advancedBtn').addEventListener('click',()=>openDialog('advancedDialog'));
$('#browserProvider').addEventListener('change',()=>{$('#customWebmailRow').hidden=$('#browserProvider').value!=='custom';});
$('#browserForm').addEventListener('submit',async e=>{
  e.preventDefault(); const b=$('#browserSubmit'); b.disabled=true; b.textContent='Waiting for sign-in…';
  const provider=$('#browserProvider').value;
  const payload={email:$('#browserEmail').value.trim(),provider,custom_url:provider==='custom'?($('#browserCustomUrl').value.trim()||null):null,interval_seconds:Number($('#browserInterval').value),message_limit:Number($('#browserLimit').value)};
  try{
    toast('A webmail window will open. Sign in there and leave it on the inbox until Mail Radar confirms the connection.');
    const result=await jsonOrError(await fetch('/api/accounts/browser/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));
    $('#browserDialog').close(); await refreshAll();
    toast(result.last_error?'Webmail session saved. Initial headless scan needs attention; try Visible sync.':'Webmail connected and scanned.',!!result.last_error);
  }catch(err){toast(err.message,true);}finally{b.disabled=false;b.textContent='Open Webmail & Connect';}
});

$('#addMicrosoftBtn').addEventListener('click',async()=>{try{await loadSetup();}catch{}$('#advancedDialog').close();openDialog('microsoftDialog');});
$('#addGmailBtn').addEventListener('click',async()=>{try{await loadSetup();}catch{}$('#advancedDialog').close();openDialog('gmailDialog');});
$('#addImapBtn').addEventListener('click',()=>{$('#advancedDialog').close();openDialog('imapDialog');});
$('#microsoftForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('#msSubmit');b.disabled=true;b.textContent='Waiting for Microsoft…';const payload={client_id:$('#msClientId').value.trim()||null,tenant_id:$('#msTenant').value.trim()||'organizations',login_hint:$('#msLoginHint').value.trim()||null,interval_seconds:Number($('#msInterval').value),message_limit:Number($('#msLimit').value),remember_app_setup:$('#msRemember').checked};try{toast('Complete Microsoft sign-in in the browser window that opens.');await jsonOrError(await fetch('/api/accounts/microsoft/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));$('#microsoftDialog').close();await refreshAll();toast('Microsoft mailbox connected and scanned.');}catch(err){toast(err.message,true);}finally{b.disabled=false;b.textContent='Open Microsoft Sign-In';}});
$('#gmailForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('#gmailSubmit');b.disabled=true;b.textContent='Waiting for Google…';let clientJson=null;const file=$('#googleJsonFile').files?.[0];if(file)clientJson=await file.text();const payload={client_config_json:clientJson,interval_seconds:Number($('#gmailInterval').value),message_limit:Number($('#gmailLimit').value),remember_client_config:$('#gmailRemember').checked};try{toast('Complete Google sign-in in the browser window that opens.');await jsonOrError(await fetch('/api/accounts/gmail/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));$('#gmailDialog').close();$('#googleJsonFile').value='';await refreshAll();toast('Gmail connected and scanned.');}catch(err){toast(err.message,true);}finally{b.disabled=false;b.textContent='Open Google Sign-In';}});
$('#imapProvider').addEventListener('change',()=>{$('#customImapRows').hidden=$('#imapProvider').value!=='custom';});
$('#imapForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('#imapSubmit');b.disabled=true;b.textContent='Connecting…';const payload={email:$('#imapEmail').value.trim(),password:$('#imapPassword').value,provider:$('#imapProvider').value,imap_host:$('#imapHost').value.trim()||null,imap_port:Number($('#imapPort').value||993),username:$('#imapUsername').value.trim()||null,folder:$('#imapFolder').value.trim()||'INBOX',interval_seconds:Number($('#imapInterval').value),message_limit:Number($('#imapLimit').value),remember_password:$('#imapRemember').checked};try{await jsonOrError(await fetch('/api/accounts/imap/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));$('#imapPassword').value='';$('#imapDialog').close();await refreshAll();toast('IMAP mailbox connected and scanned.');}catch(err){toast(err.message,true);}finally{b.disabled=false;b.textContent='Connect & Scan Inbox';}});

$('#accountList').addEventListener('click',async e=>{
  const btn=e.target.closest('[data-account-action]'); if(!btn)return;
  const id=btn.dataset.id; const action=btn.dataset.accountAction; btn.disabled=true;
  try{
    if(action==='remove'){
      if(!confirm('Remove this mailbox connection and its saved authorization/session? Existing classified notices will stay in the dashboard.'))return;
      await jsonOrError(await fetch(`/api/accounts/${id}`,{method:'DELETE'})); toast('Mailbox connection removed.');
    }else{
      if(action==='reconnect-browser') toast('A webmail window will open. Sign in again and leave it on the inbox.');
      if(action==='sync-visible') toast('Opening a visible webmail window for this scan.');
      await jsonOrError(await fetch(`/api/accounts/${id}/${action}`,{method:'POST'}));
      const messages={sync:'Mailbox synced.','sync-visible':'Visible webmail sync completed.','reconnect-browser':'Webmail session reconnected.',pause:'Mailbox paused.',enable:'Mailbox resumed.'};
      toast(messages[action]||'Mailbox updated.');
    }
    await refreshAll();
  }catch(err){toast(err.message,true);}finally{btn.disabled=false;}
});


let calendarEvents=[];
let calendarAnchor=new Date();
calendarAnchor.setDate(1); calendarAnchor.setHours(12,0,0,0);
let calendarFilter='all';
let openedCalendarEvent=null;

function safeColor(v){ return /^#[0-9a-f]{6}$/i.test(String(v||'')) ? v : '#65758b'; }
function calendarDayKey(v){ const d=new Date(v); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function monthGridStart(anchor){ const d=new Date(anchor.getFullYear(),anchor.getMonth(),1,12); const mondayOffset=(d.getDay()+6)%7; d.setDate(d.getDate()-mondayOffset); return d; }
function addCalendarDays(d,n){ const x=new Date(d); x.setDate(x.getDate()+n); return x; }
function eventMatchesFilter(ev){ if(calendarFilter==='all') return true; if(calendarFilter==='class') return ev.kind==='class'; if(calendarFilter==='deadline') return ev.kind==='deadline'; return ev.kind===calendarFilter; }
function eventTimeLabel(ev){ if(ev.all_day) return 'Time not specified'; const start=new Date(ev.start_at), end=new Date(ev.end_at); const f=x=>x.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'}); return `${f(start)} – ${f(end)}`; }
function eventTypeLabel(ev){ const map={class:'Class',exam:'Exam',school:'School notice',activity:'Activity',career:'Career',deadline:'Deadline'}; return map[ev.kind]||ev.kind||'Event'; }
function compactCalendarTitle(value){
  let text=String(value||'').replace(/\s+/g,' ').trim();
  text=text.replace(/^(?:re|fw|fwd)\s*:\s*/i,'');
  text=text.replace(/\bThis is an external email\.?/gi,'').trim();
  const markers=[' Dear ',' Please see the details below',' Further details',' Best regards',' Thank you for your'];
  for(const marker of markers){
    const idx=text.toLowerCase().indexOf(marker.toLowerCase());
    if(idx>12){ text=text.slice(0,idx).trim(); break; }
  }
  if(text.length>96) text=text.slice(0,93).replace(/[\s,;:.!?-]+$/,'')+'…';
  return text||'Untitled event';
}
function calendarLocationLabel(ev){
  const raw=String(ev.location||'').trim();
  if(raw) return raw;
  return 'Location TBA';
}
function openEventDetails(ev){
  openedCalendarEvent=ev;
  const start=new Date(ev.start_at);
  $('#eventDialogTitle').textContent=ev.title||'Event';
  $('#eventDialogDate').textContent=start.toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  $('#eventDialogTime').textContent=eventTimeLabel(ev);
  $('#eventDialogLocation').textContent=calendarLocationLabel(ev);
  $('#eventDialogType').textContent=eventTypeLabel(ev)+(ev.course_code?` · ${ev.course_code}`:'');
  $('#eventDialogSource').textContent=ev.source||'Mail Radar';
  $('#eventDialogSender').textContent=[ev.source_account,ev.source_sender].filter(Boolean).join(' · ')||'—';
  $('#eventDialogDetails').textContent=ev.details||'No additional details.';
  const link=$('#eventDialogLink');
  if(ev.url){ link.href=ev.url; link.hidden=false; } else { link.removeAttribute('href'); link.hidden=true; }
  const del=$('#eventDeleteBtn');
  del.hidden=!ev.editable;
  del.dataset.eventId=ev.editable?String(ev.id):'';
  openDialog('eventDialog');
}
function renderCalendar(){
  const title=$('#calendarTitle'), grid=$('#calendarGrid'), legend=$('#calendarLegend');
  title.textContent=calendarAnchor.toLocaleDateString(undefined,{month:'long',year:'numeric'});
  const filtered=calendarEvents.filter(eventMatchesFilter);
  const grouped={};
  filtered.forEach(ev=>{ const key=calendarDayKey(ev.start_at); (grouped[key] ||= []).push(ev); });
  Object.values(grouped).forEach(arr=>arr.sort((a,b)=>new Date(a.start_at)-new Date(b.start_at)));

  const visibleKinds=new Map();
  filtered.forEach(ev=>{
    const key=ev.kind==='class'?(ev.course_code||ev.title):eventTypeLabel(ev);
    if(!visibleKinds.has(key)) visibleKinds.set(key,{label:key,color:safeColor(ev.color)});
  });
  legend.innerHTML=[...visibleKinds.values()].slice(0,12).map(x=>`<span class="legend-pill"><span class="legend-swatch" style="background:${esc(x.color)}"></span>${esc(x.label)}</span>`).join('');

  const parts=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d=>`<div class="calendar-weekday">${d}</div>`);
  const start=monthGridStart(calendarAnchor); const todayKey=calendarDayKey(new Date());
  for(let i=0;i<42;i++){
    const day=addCalendarDays(start,i); const key=calendarDayKey(day); const events=grouped[key]||[];
    const inMonth=day.getMonth()===calendarAnchor.getMonth(); const isToday=key===todayKey;
    const visible=events.slice(0,4);
    const eventHtml=visible.map(ev=>`<button type="button" class="calendar-event calendar-event-${esc(ev.kind||'event')}" style="--event-color:${esc(safeColor(ev.color))}" data-calendar-event="${esc(ev.id)}"><strong title="${esc(compactCalendarTitle(ev.title))}">${esc(compactCalendarTitle(ev.title))}</strong><span>${esc(eventTimeLabel(ev))}</span><small>${esc(calendarLocationLabel(ev))}</small></button>`).join('');
    const more=events.length>4?`<div class="calendar-more">+${events.length-4} more event${events.length-4===1?'':'s'}</div>`:'';
    parts.push(`<div class="calendar-cell ${inMonth?'':'other-month'} ${isToday?'today':''}"><div class="calendar-date"><strong>${day.getDate()}</strong><small>${day.toLocaleDateString(undefined,{month:'short'})}</small></div><div class="calendar-events">${eventHtml}${more}</div></div>`);
  }
  grid.innerHTML=parts.join('');
  grid.querySelectorAll('[data-calendar-event]').forEach(btn=>btn.addEventListener('click',()=>{ const ev=calendarEvents.find(x=>String(x.id)===btn.dataset.calendarEvent); if(ev) openEventDetails(ev); }));
}
async function loadCalendar(){ const data=await jsonOrError(await fetch('/api/calendar/events')); calendarEvents=data.events||[]; renderCalendar(); return data; }
$('#calendarPrevBtn').addEventListener('click',()=>{ calendarAnchor=new Date(calendarAnchor.getFullYear(),calendarAnchor.getMonth()-1,1,12); renderCalendar(); });
$('#calendarNextBtn').addEventListener('click',()=>{ calendarAnchor=new Date(calendarAnchor.getFullYear(),calendarAnchor.getMonth()+1,1,12); renderCalendar(); });
$('#calendarTodayBtn').addEventListener('click',()=>{ const now=new Date(); calendarAnchor=new Date(now.getFullYear(),now.getMonth(),1,12); renderCalendar(); });
$('#calendarRefreshBtn').addEventListener('click',async()=>{ try{await loadCalendar();toast('Calendar refreshed');}catch(e){toast(e.message,true);} });
$('#calendarFilters').addEventListener('click',e=>{ const btn=e.target.closest('[data-calendar-filter]'); if(!btn)return; calendarFilter=btn.dataset.calendarFilter; document.querySelectorAll('[data-calendar-filter]').forEach(x=>x.classList.toggle('active',x===btn)); renderCalendar(); });

$('#eventDeleteBtn').addEventListener('click',async()=>{
  const ev=openedCalendarEvent;
  if(!ev?.editable)return;
  if(!confirm(`Delete “${ev.title||'this event'}” from the timetable?`))return;
  const btn=$('#eventDeleteBtn'); btn.disabled=true;
  try{
    await jsonOrError(await fetch(`/api/calendar/events/${encodeURIComponent(ev.id)}`,{method:'DELETE'}));
    $('#eventDialog').close(); openedCalendarEvent=null;
    await loadCalendar(); toast('Event deleted.');
  }catch(err){toast(err.message,true);}finally{btn.disabled=false;}
});

function localDateInput(date){
  const y=date.getFullYear(), m=String(date.getMonth()+1).padStart(2,'0'), d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}
function mondayFor(date){
  const d=new Date(date); d.setHours(12,0,0,0); const offset=(d.getDay()+6)%7; d.setDate(d.getDate()-offset); return d;
}
function manualCourseRow(values={}){
  const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const weekday=Number.isInteger(values.weekday)?values.weekday:0;
  return `<div class="manual-course-row">
    <label>Course title <input class="manual-title" required maxlength="255" placeholder="e.g. Machine Learning lecture" value="${esc(values.title||'')}" /></label>
    <label>Code <input class="manual-code" maxlength="80" placeholder="Optional" value="${esc(values.course_code||'')}" /></label>
    <label>Day <select class="manual-weekday">${days.map((day,i)=>`<option value="${i}" ${i===weekday?'selected':''}>${day.slice(0,3)}</option>`).join('')}</select></label>
    <label>Start <input class="manual-start" type="time" required value="${esc(values.start_time||'09:00')}" /></label>
    <label>End <input class="manual-end" type="time" required value="${esc(values.end_time||'10:00')}" /></label>
    <label>Location <input class="manual-location" maxlength="255" placeholder="Room / building / online" value="${esc(values.location||'')}" /></label>
    <button type="button" class="ghost manual-row-remove" title="Remove this course">×</button>
  </div>`;
}
function addManualCourseRow(values={}){
  $('#manualCourseRows').insertAdjacentHTML('beforeend',manualCourseRow(values));
}
function setExamRequired(enabled){
  ['#manualExamTitle','#manualExamDate','#manualExamStart','#manualExamEnd'].forEach(sel=>$(sel).required=enabled);
}
function resetManualScheduleForm(){
  $('#manualScheduleForm').reset();
  const monday=mondayFor(new Date());
  $('#manualWeekStart').value=localDateInput(monday);
  $('#manualRepeatWeeks').value='1';
  $('#manualCourseRows').innerHTML='';
  addManualCourseRow();
  $('#manualAddExam').checked=false;
  $('#manualExamFields').hidden=true;
  setExamRequired(false);
  $('#manualExamDate').value=localDateInput(monday);
}
$('#manualWeekBtn').addEventListener('click',()=>{resetManualScheduleForm();openDialog('manualScheduleDialog');});
$('#addCourseRowBtn').addEventListener('click',()=>addManualCourseRow());
$('#manualCourseRows').addEventListener('click',e=>{
  const btn=e.target.closest('.manual-row-remove'); if(!btn)return;
  btn.closest('.manual-course-row')?.remove();
});
$('#manualAddExam').addEventListener('change',()=>{
  const enabled=$('#manualAddExam').checked;
  $('#manualExamFields').hidden=!enabled; setExamRequired(enabled);
  if(enabled&&!$('#manualExamDate').value)$('#manualExamDate').value=$('#manualWeekStart').value;
});
$('#manualWeekStart').addEventListener('change',()=>{
  if(!$('#manualAddExam').checked||$('#manualExamDate').value)return;
  $('#manualExamDate').value=$('#manualWeekStart').value;
});
$('#manualScheduleForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const classes=[...document.querySelectorAll('.manual-course-row')].map(row=>({
    title:row.querySelector('.manual-title').value.trim(),
    course_code:row.querySelector('.manual-code').value.trim()||null,
    weekday:Number(row.querySelector('.manual-weekday').value),
    start_time:row.querySelector('.manual-start').value,
    end_time:row.querySelector('.manual-end').value,
    location:row.querySelector('.manual-location').value.trim()||null,
    details:null,
  }));
  let exam=null;
  if($('#manualAddExam').checked){
    exam={
      title:$('#manualExamTitle').value.trim(),
      course_code:$('#manualExamCode').value.trim()||null,
      exam_date:$('#manualExamDate').value,
      start_time:$('#manualExamStart').value,
      end_time:$('#manualExamEnd').value,
      location:$('#manualExamLocation').value.trim()||null,
      details:null,
    };
  }
  if(!classes.length&&!exam){toast('Add at least one course or an exam.',true);return;}
  const payload={week_start:$('#manualWeekStart').value,repeat_weeks:Number($('#manualRepeatWeeks').value||1),classes,exam};
  const btn=$('#manualScheduleSubmit'); btn.disabled=true; btn.textContent='Adding…';
  try{
    const result=await jsonOrError(await fetch('/api/timetable/week',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));
    $('#manualScheduleDialog').close();
    const selected=new Date(`${payload.week_start}T12:00:00`); calendarAnchor=new Date(selected.getFullYear(),selected.getMonth(),1,12);
    await loadCalendar();
    const parts=[];
    if(result.class_count)parts.push(`${result.class_count} class${result.class_count===1?'':'es'}`);
    if(result.exam_count)parts.push(`${result.exam_count} exam`);
    const skipped=result.skipped_duplicates?` ${result.skipped_duplicates} duplicate${result.skipped_duplicates===1?' was':'s were'} skipped.`:'';
    toast(`${parts.length?parts.join(' + '):'No new events'} added.${skipped}`);
  }catch(err){toast(err.message,true);}finally{btn.disabled=false;btn.textContent='Add to calendar';}
});
$('#clearTimetableBtn').addEventListener('click',async()=>{
  if(!confirm('Clear all manually added classes and exams? Email-derived calendar notices will stay.'))return;
  const btn=$('#clearTimetableBtn'); btn.disabled=true;
  try{
    const result=await jsonOrError(await fetch('/api/timetable',{method:'DELETE'}));
    await loadCalendar(); toast(result.deleted_count?`Deleted ${result.deleted_count} timetable event${result.deleted_count===1?'':'s'}.`:'Timetable is already empty.');
  }catch(err){toast(err.message,true);}finally{btn.disabled=false;}
});

async function loadAISettings(){const data=await jsonOrError(await fetch('/api/settings/ai'));$('#aiEnabled').checked=!!data.enabled;$('#aiModel').value=data.model||'deepseek-flash';$('#aiKeyStatus').textContent=data.api_key_configured?'An encrypted API key is already saved. Leave the field blank to keep it.':'No API key is saved yet.';return data;}
$('#aiSettingsBtn').addEventListener('click',async()=>{try{await loadAISettings();}catch(e){toast(e.message,true);}openDialog('aiDialog');});
$('#aiForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('#aiSubmit');b.disabled=true;const payload={enabled:$('#aiEnabled').checked,api_key:$('#aiKey').value.trim()||null,model:$('#aiModel').value.trim()||'deepseek-flash'};try{const result=await jsonOrError(await fetch('/api/settings/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}));$('#aiKey').value='';$('#aiDialog').close();toast(result.enabled?'DeepSeek review enabled.':'DeepSeek review disabled.');}catch(err){toast(err.message,true);}finally{b.disabled=false;}});

async function initialLoad(){try{await Promise.all([loadSetup(),refreshAll()]);}catch(e){toast(e.message,true);}}
initialLoad();
setInterval(()=>{refreshAll().catch(()=>{});},30000);
