from __future__ import annotations

import os
from pathlib import Path

from app.config import get_settings
from app.paths import local_config_path, user_data_dir


def test_runtime_data_is_outside_source_tree():
    source_root = Path(__file__).resolve().parents[1]
    data_root = user_data_dir().resolve()
    assert data_root != source_root
    assert source_root not in data_root.parents
    assert data_root not in source_root.parents
    assert Path(get_settings().browser_profiles_dir).resolve().is_relative_to(data_root)
    assert local_config_path().resolve().is_relative_to(data_root)


def test_test_data_dir_override_is_active():
    assert os.environ.get('MAIL_RADAR_DATA_DIR')
