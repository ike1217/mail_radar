from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db import Base
from app.services.pipeline import ingest_email


def test_pipeline_stores_audit_and_source_fields(tmp_path: Path):
    engine = create_engine(f"sqlite:///{tmp_path / 'test.db'}", connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    try:
        rows = ingest_email(
            db,
            subject='Urgent venue change',
            sender='cs@hku.hk',
            body="Tomorrow's class has a classroom change to Room CPD-LG.18.",
            source_provider='gmail',
            source_account='student@gmail.com',
        )
        assert len(rows) == 1
        n = rows[0]
        assert n.category == 'school'
        assert n.rule_category == 'school'
        assert n.rule_confidence > 0
        assert n.decision_source == 'rule'
        assert n.source_provider == 'gmail'
        assert n.source_account == 'student@gmail.com'
    finally:
        db.close()


def test_same_notice_from_two_mailboxes_is_deduplicated(tmp_path: Path):
    engine = create_engine(f"sqlite:///{tmp_path / 'dedupe.db'}", connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    try:
        received = datetime(2026, 10, 2, 12, 0, tzinfo=timezone.utc)
        a = ingest_email(db, 'Assignment reminder', 'teacher@hku.hk', 'Submit Assignment 2 by 3 Oct 2026.', received_at=received, graph_message_id='microsoft:1', source_provider='microsoft', source_account='a@x.com')
        b = ingest_email(db, 'Assignment reminder', 'teacher@hku.hk', 'Submit Assignment 2 by 3 Oct 2026.', received_at=received, graph_message_id='gmail:2', source_provider='gmail', source_account='b@gmail.com')
        assert a[0].id == b[0].id
    finally:
        db.close()
