from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db import Base
from app.models import MailAccount


def test_multiple_provider_accounts_can_coexist(tmp_path: Path):
    engine = create_engine(f"sqlite:///{tmp_path / 'accounts.db'}", connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    try:
        db.add_all([
            MailAccount(provider='microsoft', email='student@university.edu', folder='INBOX', provider_label='Microsoft 365'),
            MailAccount(provider='gmail', email='personal@gmail.com', folder='INBOX', provider_label='Gmail'),
            MailAccount(provider='imap', email='me@icloud.com', folder='INBOX', provider_label='iCloud Mail', host='imap.mail.me.com', port=993),
        ])
        db.commit()
        assert db.query(MailAccount).count() == 3
    finally:
        db.close()
