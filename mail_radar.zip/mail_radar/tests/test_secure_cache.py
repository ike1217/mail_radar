from pathlib import Path

from app.services.secure_cache import EncryptedFileStore


def test_encrypted_store_roundtrip(tmp_path: Path):
    data = tmp_path / 'cache.bin'
    key = tmp_path / 'cache.key'
    store = EncryptedFileStore(data, key)
    store.write_text('{"token":"secret-value"}')
    assert store.read_text() == '{"token":"secret-value"}'
    assert b'secret-value' not in data.read_bytes()
    store.clear()
    assert not data.exists()
    assert not key.exists()
