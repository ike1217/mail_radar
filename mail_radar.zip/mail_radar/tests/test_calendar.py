from __future__ import annotations

from datetime import datetime
from pathlib import Path

from fastapi.testclient import TestClient

from app.db import Base, SessionLocal, engine
from app.main import app
from app.models import TimetableEvent
from app.services.calendar_service import _compact_calendar_title, _extract_location, infer_time_range
from app.timetable_seed import default_timetable_events, seed_default_timetable
from app.timezones import get_timezone


def test_distribution_contains_no_personal_default_timetable():
    assert default_timetable_events() == []


def test_compat_seed_is_noop():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        before = db.query(TimetableEvent).count()
        seed_default_timetable(db)
        after = db.query(TimetableEvent).count()
    finally:
        db.close()
    assert after == before


def test_calendar_api_starts_without_private_class_records():
    Base.metadata.create_all(bind=engine)
    with TestClient(app) as client:
        response = client.get('/api/calendar/events')
    assert response.status_code == 200
    payload = response.json()
    assert isinstance(payload['events'], list)


def test_email_time_range_parser_handles_12h_and_missing_time():
    tz = get_timezone('Asia/Hong_Kong')
    base = datetime(2026, 10, 8, 12, 0, tzinfo=tz)
    start, end, all_day = infer_time_range('Seminar 7:00 PM - 9:50 PM', base)
    assert not all_day
    assert (start.hour, start.minute) == (19, 0)
    assert (end.hour, end.minute) == (21, 50)

    start, end, all_day = infer_time_range('Conference on 8 Oct', base)
    assert all_day
    assert start.hour == 0
    assert end.date() > start.date()


def test_calendar_ui_has_navigation_filters_and_detail_location():
    root = Path(__file__).resolve().parents[1]
    html = (root / 'web' / 'index.html').read_text(encoding='utf-8')
    js = (root / 'web' / 'app.js').read_text(encoding='utf-8')
    assert 'CALENDAR & TIMETABLE' in html
    assert 'calendarPrevBtn' in html and 'calendarNextBtn' in html and 'calendarTodayBtn' in html
    assert 'eventDialogLocation' in html and 'eventDialogDetails' in html
    assert '/api/calendar/events' in js
    assert 'Time not specified' in js
    assert html.index('id="eventDialog"') < html.index('/static/app.js')


def test_calendar_event_compaction_and_location_fallback():
    title = ('SHL Reminder: Your Assessment Invitation for JEC Management Trainee Programme 17:30 '
             'This is an external email. Jardine Engineering Corporation reminds you to complete the assessments Dear Tianqi')
    compact = _compact_calendar_title(title)
    assert 'This is an external email' not in compact
    assert 'Dear Tianqi' not in compact
    assert compact.startswith('SHL Reminder: Your Assessment Invitation')

    text = 'Venue : CPD LG.03\nDate : 17 October 2026\nTime : 2:00 pm - 5:00 pm'
    assert _extract_location(text) == 'CPD LG.03'


def test_manual_week_add_exam_delete_and_clear():
    Base.metadata.create_all(bind=engine)
    with TestClient(app) as client:
        client.delete('/api/timetable')
        payload = {
            'week_start': '2026-10-05',
            'repeat_weeks': 2,
            'classes': [
                {
                    'title': 'Logic Workshop',
                    'course_code': 'COMP-LOGIC',
                    'weekday': 1,
                    'start_time': '13:00',
                    'end_time': '14:00',
                    'location': 'THA',
                    'details': None,
                },
                {
                    'title': 'AI Lab',
                    'course_code': 'COMP-AI',
                    'weekday': 3,
                    'start_time': '12:00',
                    'end_time': '13:00',
                    'location': 'LF8',
                    'details': None,
                },
            ],
            'exam': {
                'title': 'Logic Midterm',
                'course_code': 'COMP-LOGIC',
                'exam_date': '2026-10-21',
                'start_time': '10:00',
                'end_time': '11:30',
                'location': 'Exam Hall',
                'details': None,
            },
        }
        response = client.post('/api/timetable/week', json=payload)
        assert response.status_code == 200, response.text
        result = response.json()
        assert result['class_count'] == 4
        assert result['exam_count'] == 1

        # A repeated save should not duplicate identical rows.
        repeated = client.post('/api/timetable/week', json=payload)
        assert repeated.status_code == 200
        assert repeated.json()['created_count'] == 0
        assert repeated.json()['skipped_duplicates'] == 5

        events = client.get('/api/calendar/events').json()['events']
        manual = [event for event in events if event.get('editable')]
        assert len(manual) == 5
        assert sum(event['kind'] == 'exam' for event in manual) == 1
        assert all(event['source'].startswith('Manual') for event in manual)

        victim = next(event for event in manual if event['kind'] == 'exam')
        deleted = client.delete(f"/api/calendar/events/{victim['id']}")
        assert deleted.status_code == 200
        assert victim['id'] not in {event['id'] for event in client.get('/api/calendar/events').json()['events']}

        cleared = client.delete('/api/timetable')
        assert cleared.status_code == 200
        assert cleared.json()['deleted_count'] == 4
        assert not [event for event in client.get('/api/calendar/events').json()['events'] if event.get('editable')]


def test_manual_calendar_ui_has_add_exam_and_delete_controls():
    root = Path(__file__).resolve().parents[1]
    html = (root / 'web' / 'index.html').read_text(encoding='utf-8')
    js = (root / 'web' / 'app.js').read_text(encoding='utf-8')
    assert 'manualWeekBtn' in html
    assert 'manualScheduleDialog' in html
    assert 'manualAddExam' in html
    assert 'eventDeleteBtn' in html
    assert 'clearTimetableBtn' in html
    assert '/api/timetable/week' in js
    assert "method:'DELETE'" in js
