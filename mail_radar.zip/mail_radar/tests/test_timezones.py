from datetime import datetime

from app.timezones import get_timezone
from app.services.extractor import parse_dates


def test_hong_kong_timezone_is_resolvable_or_safe_fallback():
    tz = get_timezone('Asia/Hong_Kong')
    assert tz is not None
    now = datetime.now(tz)
    assert now.tzinfo is not None


def test_invalid_timezone_never_crashes_date_parsing():
    dates = parse_dates('Event on 31 Oct 2026', None, 'Not/A_Real_Timezone')
    assert dates
    assert dates[0][0].tzinfo is not None
