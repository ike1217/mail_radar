from app.services.classifier import classify

DOMAINS = ["hku.hk", "info.hku.hk"]


def test_venue_change_school():
    c = classify("Urgent venue change", "Tomorrow's class has a classroom change", None, "cs@hku.hk", DOMAINS)
    assert c.category == "school"
    assert c.subcategory == "venue-change"


def test_external_internship():
    c = classify("Microsoft Internship", "Software Engineer Internship. Apply now.", None, "careers@hku.hk", DOMAINS)
    assert c.category == "career"
    assert c.company_size == "large"


def test_conference_activity():
    c = classify("AI Conference", "Register now for the conference", "School of Computing", "bulkemail@info.hku.hk", DOMAINS)
    assert c.category == "activity"
