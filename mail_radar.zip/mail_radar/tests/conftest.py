from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# Tests must never touch a developer/user's real Mail Radar data directory.
_TEST_DATA = tempfile.mkdtemp(prefix='mail-radar-tests-')
os.environ.setdefault('MAIL_RADAR_DATA_DIR', _TEST_DATA)

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
