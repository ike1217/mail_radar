from app.services.privacy_filter import redact_for_llm


def test_privacy_redaction():
    text = "Contact student123@example.edu, UID u1234567, phone 9123 4567."
    redacted, changed = redact_for_llm(text)
    assert changed
    assert "student123@example.edu" not in redacted
    assert "u1234567" not in redacted
    assert "9123 4567" not in redacted
    assert "[EMAIL]" in redacted
