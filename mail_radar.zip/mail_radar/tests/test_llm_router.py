from app.services.classifier import Classification
from app.services.llm_router import decide_llm_review


def test_llm_disabled_by_default():
    c = Classification("school", "general", 0.4, "weak")
    d = decide_llm_review(c, "Test", "deadline tomorrow")
    assert d.should_review is False
