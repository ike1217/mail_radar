from app.services.splitter import split_email


def test_hku_digest_split():
    body = """HKU Daily Notices\nToday's Highlights\nActivity A\nSchool A | 29 SEP 2026\nActivity B\nSchool B | 30 SEP 2026"""
    chunks = split_email("HKU Daily Notices", body, "text")
    assert len(chunks) == 2
    assert chunks[0].title == "Activity A"
    assert chunks[1].organizer == "School B"
