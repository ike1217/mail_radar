from types import SimpleNamespace

from app.services.account_manager import AccountManager


def test_session_only_imap_username_override_is_preserved():
    manager = AccountManager()
    manager._session_imap_credentials[77] = {'password': 'secret', 'username': 'special-login'}
    account = SimpleNamespace(id=77, remember_credentials=False)
    password, username = manager._imap_credentials(account)
    assert password == 'secret'
    assert username == 'special-login'
