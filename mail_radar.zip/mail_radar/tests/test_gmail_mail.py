import base64

import pytest

from app.services.gmail_mail import GmailMailClient, GoogleClientConfigStore


def test_google_client_requires_desktop_app_json():
    with pytest.raises(ValueError):
        GoogleClientConfigStore.validate({'web': {'client_id': 'x'}})
    data = {'installed': {'client_id': 'x', 'auth_uri': 'https://example.com/auth', 'token_uri': 'https://example.com/token'}}
    assert GoogleClientConfigStore.validate(data) is data


def test_gmail_body_decoder_and_headers():
    html = '<p>Hello HKU</p>'
    encoded = base64.urlsafe_b64encode(html.encode()).decode().rstrip('=')
    raw = {
        'id': 'abc',
        'historyId': '123',
        'internalDate': '1790964000000',
        'payload': {
            'headers': [
                {'name': 'Subject', 'value': 'Daily Notice'},
                {'name': 'From', 'value': 'HKU <bulk@example.edu>'},
                {'name': 'Message-ID', 'value': '<m1@example.edu>'},
            ],
            'parts': [{'mimeType': 'text/html', 'body': {'data': encoded}}],
        },
    }
    env = GmailMailClient._to_envelope(raw, 'student@gmail.com')
    assert env is not None
    assert env.subject == 'Daily Notice'
    assert env.sender == 'bulk@example.edu'
    assert 'Hello HKU' in env.body
    assert env.body_type == 'html'
    assert env.history_id == '123'
