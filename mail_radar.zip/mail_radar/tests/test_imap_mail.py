from app.services.imap_mail import infer_provider, provider_label, resolve_host


def test_provider_inference_covers_common_services():
    assert infer_provider('u1234567@connect.hku.hk') == 'outlook'
    assert infer_provider('student@gmail.com') == 'gmail'
    assert infer_provider('name@icloud.com') == 'icloud'
    assert infer_provider('person@qq.com') == 'qq'
    assert infer_provider('person@163.com') == '163'
    assert infer_provider('person@126.com') == '126'
    assert infer_provider('person@example.edu') == 'custom'


def test_provider_hosts():
    assert resolve_host('auto', 'u1234567@connect.hku.hk')[1] == 'outlook.office365.com'
    assert resolve_host('gmail', 'x@example.com')[1] == 'imap.gmail.com'
    assert resolve_host('icloud', 'x@icloud.com')[1] == 'imap.mail.me.com'
    assert resolve_host('qq', 'x@qq.com')[1] == 'imap.qq.com'
    assert resolve_host('163', 'x@163.com')[1] == 'imap.163.com'
    assert resolve_host('custom', 'x@example.com', 'mail.example.com') == ('custom', 'mail.example.com')
    assert provider_label('fastmail') == 'Fastmail'


def test_incremental_cursor_does_not_skip_large_burst(monkeypatch):
    from app.services.imap_mail import IMAPConfig, IMAPMailboxClient, MailEnvelope

    class FakeConn:
        def uid(self, command, *args):
            if command == 'search':
                return 'OK', [b' '.join(str(i).encode() for i in range(1, 601))]
            raise AssertionError(command)

        def logout(self):
            pass

    client = IMAPMailboxClient(IMAPConfig(email='x@example.com', password='p', provider='custom', host='imap.example.com'))
    monkeypatch.setattr(client, '_connect', lambda: FakeConn())
    monkeypatch.setattr(client, '_select', lambda conn: '42')
    monkeypatch.setattr(
        client,
        '_fetch_uid',
        lambda conn, uid: MailEnvelope(uid=uid, subject='s', sender='a@example.com', received_at=None, body='b', body_type='text', internet_message_id=None),
    )

    first, cursor = client.fetch_incremental('42:0', limit=100)
    assert len(first) == 500
    assert cursor == '42:500'

    second, cursor2 = client.fetch_incremental(cursor, limit=100)
    assert len(second) == 100
    assert second[0].uid == '501'
    assert second[-1].uid == '600'
    assert cursor2 == '42:600'


def test_initial_imap_scan_baselines_after_latest_window(monkeypatch):
    from app.services.imap_mail import IMAPConfig, IMAPMailboxClient, MailEnvelope

    class FakeConn:
        def uid(self, command, *args):
            if command == 'search':
                return 'OK', [b' '.join(str(i).encode() for i in range(1, 601))]
            raise AssertionError(command)

        def logout(self):
            pass

    client = IMAPMailboxClient(IMAPConfig(email='x@example.com', password='p', provider='custom', host='imap.example.com'))
    monkeypatch.setattr(client, '_connect', lambda: FakeConn())
    monkeypatch.setattr(client, '_select', lambda conn: '42')
    monkeypatch.setattr(
        client,
        '_fetch_uid',
        lambda conn, uid: MailEnvelope(uid=uid, subject='s', sender='a@example.com', received_at=None, body='b', body_type='text', internet_message_id=None),
    )

    messages, cursor = client.fetch_incremental(None, limit=100)
    assert len(messages) == 100
    assert messages[0].uid == '501'
    assert messages[-1].uid == '600'
    assert cursor == '42:600'
