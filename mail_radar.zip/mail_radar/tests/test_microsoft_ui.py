from pathlib import Path


def test_multi_provider_ui_and_passwordless_connectors():
    root = Path(__file__).resolve().parents[1]
    html = (root / 'web/index.html').read_text(encoding='utf-8')
    js = (root / 'web/app.js').read_text(encoding='utf-8')
    assert 'Connect Webmail' in html
    assert 'Microsoft 365' in html
    assert 'Gmail' in html
    assert 'Other IMAP' in html
    assert 'No mailbox password is entered into Mail Radar.' in html
    assert '/api/accounts/browser/connect' in js
    assert '/api/accounts/microsoft/connect' in js
    assert '/api/accounts/gmail/connect' in js
    assert '/api/accounts/imap/connect' in js
    assert '/api/accounts/sync-all' in js


def test_current_deepseek_alias_is_used():
    root = Path(__file__).resolve().parents[1]
    env = (root / '.env.example').read_text(encoding='utf-8')
    assert 'DEEPSEEK_MODEL=deepseek-flash' in env
