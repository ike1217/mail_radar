from pathlib import Path

from app.schemas import BrowserConnectRequest
from app.services.browser_mail import BrowserMailboxClient, detect_provider, provider_options


def test_browser_connector_has_major_webmail_providers():
    keys = {item['key'] for item in provider_options()}
    assert {'auto', 'outlook', 'gmail', 'yahoo', 'icloud', 'qq', '163', '126', 'zoho', 'fastmail', 'proton', 'custom'} <= keys


def test_browser_auto_detects_hku_and_common_domains():
    assert detect_provider('u1234567@connect.hku.hk') == 'outlook'
    assert detect_provider('me@gmail.com') == 'gmail'
    assert detect_provider('me@icloud.com') == 'icloud'


def test_browser_request_accepts_custom_webmail():
    req = BrowserConnectRequest(
        email='student@example.com',
        provider='custom',
        custom_url='https://webmail.example.com/',
        interval_seconds=300,
        message_limit=30,
    )
    assert req.provider == 'custom'
    assert req.custom_url.startswith('https://')


def test_browser_profile_name_does_not_expose_password_or_need_credentials(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    client = BrowserMailboxClient('gmail', 'student@example.com')
    assert 'student_example.com' in client.profile_dir.name
    assert not client.session_available()


def test_browser_rows_include_generic_fallbacks_for_known_providers():
    client = BrowserMailboxClient('outlook', 'student@connect.hku.hk')
    selectors = client._row_selectors()
    assert '[role="option"]' in selectors
    assert '[role="row"]' in selectors
    assert '[role="main"] [role="option"]' in selectors


def test_outlook_has_broad_message_list_selectors():
    client = BrowserMailboxClient('outlook', 'student@connect.hku.hk')
    selectors = client._row_selectors()
    assert any('data-testid' in s and 'message' in s.lower() for s in selectors)


def test_outlook_accepts_office365_web_host_and_virtualized_rows():
    client = BrowserMailboxClient('outlook', 'student@connect.hku.hk')
    assert 'outlook.office365.com' in client.definition.inbox_hosts
    selectors = client._row_selectors()
    assert any('data-is-focusable' in s for s in selectors)
    assert any('MailList' in s or 'MessageList' in s for s in selectors)


def test_adaptive_message_text_scoring_distinguishes_mail_from_navigation():
    client = BrowserMailboxClient('outlook', 'student@connect.hku.hk')
    assert client._looks_like_navigation_row('Inbox 12')
    assert client._looks_like_navigation_row('收件箱 3')
    assert client._messageish_text_score('Unread, Alice, Project update, 10:32 AM') >= 4
    assert client._messageish_text_score('bob@example.com Assignment deadline Oct 5') >= 4
