from pathlib import Path
import re


def test_primary_ui_is_english_only():
    root = Path(__file__).resolve().parents[1]
    for relative in ("web/index.html", "web/app.js"):
        text = (root / relative).read_text(encoding="utf-8")
        assert not re.search(r"[\u4e00-\u9fff]", text), f"CJK text found in {relative}"
