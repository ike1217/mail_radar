"""Portable local launcher for Mail Radar.

Run with:
    py launch.py
or:
    python launch.py

Private data and the virtual environment are stored per OS user outside the source
folder, so copying the project to another computer does not copy mail history,
browser sessions, tokens, passwords, or a machine-specific .venv.
"""
from __future__ import annotations

import hashlib
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQ = ROOT / 'requirements.txt'


def data_root() -> Path:
    override = os.environ.get('MAIL_RADAR_DATA_DIR', '').strip()
    if override:
        root = Path(override).expanduser().resolve()
    elif os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or os.environ.get('APPDATA')
        root = Path(base) / 'MailRadar' if base else Path.home() / 'AppData' / 'Local' / 'MailRadar'
    elif platform.system() == 'Darwin':
        root = Path.home() / 'Library' / 'Application Support' / 'MailRadar'
    else:
        base = os.environ.get('XDG_DATA_HOME')
        root = (Path(base) if base else Path.home() / '.local' / 'share') / 'mail_radar'
    root.mkdir(parents=True, exist_ok=True)
    return root


DATA_ROOT = data_root()
VENV = DATA_ROOT / f'venv-py{sys.version_info.major}{sys.version_info.minor}'
MARKER = VENV / '.mail_radar_requirements.sha256'




def migrate_legacy_private_data() -> None:
    """Move private runtime files created by Mail Radar <=7.0 out of the source tree.

    This both preserves an existing user's data and makes the project folder safe to copy.
    Existing device-local destinations are never overwritten; conflicts are moved into a
    timestamped backup under the private data directory.
    """
    import shutil
    from datetime import datetime

    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    backup_root = DATA_ROOT / ('legacy_backup_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    pairs = [
        (ROOT / 'mail_radar.db', DATA_ROOT / 'mail_radar.db'),
        (ROOT / '.browser_profiles', DATA_ROOT / 'browser_profiles'),
        (ROOT / '.secrets', DATA_ROOT / 'secrets'),
        (ROOT / '.mail_radar_config.json', DATA_ROOT / 'config.json'),
        (ROOT / '.env', DATA_ROOT / '.env'),
    ]
    moved_any = False
    for src, dst in pairs:
        if not src.exists():
            continue
        moved_any = True
        try:
            if not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
                print(f'Migrated private legacy data: {src.name} -> {dst}')
            else:
                backup_root.mkdir(parents=True, exist_ok=True)
                target = backup_root / src.name
                shutil.move(str(src), str(target))
                print(f'Legacy private data conflict preserved at: {target}')
        except Exception as exc:
            print(f'[WARN] Could not move legacy private item {src}: {exc}')
    if moved_any:
        print('Legacy personal data is no longer stored in the source folder.')


def venv_python() -> Path:
    return VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def run(cmd: list[str], *, env: dict[str, str] | None = None, check: bool = True) -> subprocess.CompletedProcess:
    printable = ' '.join(f'"{x}"' if ' ' in str(x) else str(x) for x in cmd)
    print(f'\n> {printable}')
    return subprocess.run(cmd, cwd=ROOT, env=env, check=check)


def requirement_hash() -> str:
    return hashlib.sha256(REQ.read_bytes()).hexdigest()


def ensure_venv() -> Path:
    py = venv_python()
    if py.exists():
        probe = subprocess.run([str(py), '-c', 'import sys; print(sys.version_info[:2])'], cwd=ROOT, capture_output=True)
        if probe.returncode == 0:
            return py
        print('Existing local environment is not usable on this device; rebuilding it...')
        import shutil
        shutil.rmtree(VENV, ignore_errors=True)
    print('Creating a device-local Mail Radar virtual environment...')
    VENV.parent.mkdir(parents=True, exist_ok=True)
    run([sys.executable, '-m', 'venv', str(VENV)])
    if not py.exists():
        raise RuntimeError('Virtual environment was created but its Python executable was not found.')
    return py


def ensure_dependencies(py: Path) -> None:
    wanted = requirement_hash()
    installed = MARKER.read_text(encoding='utf-8').strip() if MARKER.exists() else ''
    if installed == wanted:
        print('Dependencies are already installed for this device.')
        return
    print('Installing/updating Mail Radar dependencies...')
    run([str(py), '-m', 'pip', 'install', '--upgrade', 'pip', 'setuptools', 'wheel'])
    run([str(py), '-m', 'pip', 'install', '-r', str(REQ)])
    MARKER.write_text(wanted, encoding='utf-8')


def ensure_timezone_works(py: Path) -> None:
    probe = subprocess.run(
        [str(py), '-c', "from zoneinfo import ZoneInfo; print(ZoneInfo('Asia/Hong_Kong'))"],
        cwd=ROOT, text=True, capture_output=True,
    )
    if probe.returncode == 0:
        print('Timezone data:', probe.stdout.strip())
        return
    print('IANA timezone data is unavailable. Installing tzdata...')
    run([str(py), '-m', 'pip', 'install', '--upgrade', 'tzdata>=2025.2'])
    second = subprocess.run(
        [str(py), '-c', "from zoneinfo import ZoneInfo; print(ZoneInfo('Asia/Hong_Kong'))"],
        cwd=ROOT, text=True, capture_output=True,
    )
    if second.returncode != 0:
        raise RuntimeError('Timezone data still cannot be loaded:\n' + (second.stderr or second.stdout))


def ensure_sqlalchemy_works(py: Path) -> None:
    probe = subprocess.run([str(py), '-c', 'import sqlalchemy; print(sqlalchemy.__version__)'], cwd=ROOT, text=True, capture_output=True)
    if probe.returncode == 0:
        print('SQLAlchemy:', probe.stdout.strip())
        return
    if os.name != 'nt':
        raise RuntimeError('SQLAlchemy import failed:\n' + (probe.stderr or probe.stdout))
    print('SQLAlchemy binary extension was blocked/broken on this Windows PC.')
    print('Reinstalling the official pure-Python SQLAlchemy build...')
    env = os.environ.copy()
    env['DISABLE_SQLALCHEMY_CEXT'] = '1'
    run([str(py), '-m', 'pip', 'uninstall', '-y', 'sqlalchemy'], env=env, check=False)
    run([str(py), '-m', 'pip', 'install', '--no-binary=sqlalchemy', '--no-cache-dir', 'sqlalchemy>=2,<3'], env=env)
    second = subprocess.run([str(py), '-c', 'import sqlalchemy; print(sqlalchemy.__version__)'], cwd=ROOT, text=True, capture_output=True, env=env)
    if second.returncode != 0:
        raise RuntimeError('SQLAlchemy still cannot be imported:\n' + (second.stderr or second.stdout))


def _system_browser_exists() -> bool:
    candidates: list[Path] = []
    if os.name == 'nt':
        for env_name in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
            base = os.environ.get(env_name)
            if not base:
                continue
            base_path = Path(base)
            candidates += [
                base_path / 'Microsoft/Edge/Application/msedge.exe',
                base_path / 'Google/Chrome/Application/chrome.exe',
            ]
    elif platform.system() == 'Darwin':
        candidates += [
            Path('/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'),
            Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
        ]
    else:
        import shutil
        return any(shutil.which(name) for name in ('microsoft-edge', 'microsoft-edge-stable', 'google-chrome', 'chromium', 'chromium-browser'))
    return any(p.exists() for p in candidates)


def ensure_browser_runtime(py: Path) -> None:
    if _system_browser_exists():
        print('System Edge/Chrome detected; Webmail Login can reuse it.')
        return
    print('No system Edge/Chrome detected. Installing Playwright Chromium for this device...')
    result = run([str(py), '-m', 'playwright', 'install', 'chromium'], check=False)
    if result.returncode != 0:
        print('[WARN] Playwright Chromium installation failed. You can still install Edge/Chrome and retry.')


def main() -> int:
    os.chdir(ROOT)
    print('Mail Radar v7.3 Portable & Private')
    print('===================================')
    print('Source folder:', ROOT)
    print('Private data:', DATA_ROOT)
    print('Bootstrap Python:', sys.executable)
    if sys.version_info < (3, 10):
        print('Python 3.10+ is required. Python 3.12 is recommended.')
        return 2

    try:
        migrate_legacy_private_data()
        py = ensure_venv()
        ensure_dependencies(py)
        ensure_timezone_works(py)
        ensure_sqlalchemy_works(py)
        ensure_browser_runtime(py)
        print('\nRunning environment self-check...')
        doctor = run([str(py), 'doctor.py'], check=False)
        if doctor.returncode != 0:
            print('\nEnvironment check reported a problem. Fix the message above and run `py launch.py` again.')
            return doctor.returncode
        print('\nStarting Mail Radar. Keep this window open while using the dashboard.')
        run([str(py), 'run.py'])
        return 0
    except KeyboardInterrupt:
        print('\nMail Radar stopped.')
        return 0
    except Exception as exc:
        print(f'\n[ERROR] {exc}')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
