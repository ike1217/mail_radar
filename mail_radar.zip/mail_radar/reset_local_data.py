"""Delete this OS user's local Mail Radar data.

This does not modify the source code. It removes the local database, browser sessions,
OAuth/token caches, saved IMAP credentials, and local AI configuration.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from app.paths import user_data_dir

root = user_data_dir()
print(f'Local Mail Radar data: {root}')
answer = input('Type DELETE to remove all local Mail Radar data on this device: ').strip()
if answer != 'DELETE':
    print('Cancelled.')
    raise SystemExit(0)

for child in list(root.iterdir()) if root.exists() else []:
    # Keep device-local venv to avoid reinstalling dependencies; everything else is private state.
    if child.name.startswith('venv-py'):
        continue
    if child.is_dir():
        shutil.rmtree(child, ignore_errors=True)
    else:
        try:
            child.unlink()
        except OSError:
            pass
print('Local Mail Radar data cleared. The next launch will start with no mailboxes or mail history.')
