#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PYTHON_BIN:-python3}"
if [[ ! -d .venv ]]; then "$PYTHON_BIN" -m venv .venv; fi
source .venv/bin/activate
python -m pip install -r requirements.txt
[[ -f .env ]] || cp .env.example .env
mkdir -p .secrets
python run.py
