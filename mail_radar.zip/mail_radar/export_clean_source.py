"""Create a clean source ZIP that never includes local/private Mail Radar data."""
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'mail_radar_clean_source.zip'
SKIP_PARTS = {'.git', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache'}
SKIP_NAMES = {'.env', 'mail_radar.db', '.mail_radar_config.json'}

with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in ROOT.rglob('*'):
        rel = path.relative_to(ROOT)
        if any(part in SKIP_PARTS or part in {'.browser_profiles', '.secrets', '.venv'} for part in rel.parts):
            continue
        if path.name in SKIP_NAMES:
            continue
        if path.is_file():
            z.write(path, Path('mail_radar') / rel)
print(OUT)
