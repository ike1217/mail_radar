from app.paths import user_data_dir

print(user_data_dir())
