# Mail Radar 7.3 — Portable & Private

Mail Radar is a local multi-mailbox information hub for automatically triaging email into **School**, **Activities**, and **Career**, with an integrated Calendar for notices that contain dates/deadlines.

## What changed in 7.3

- Webmail message-list recognition now has an adaptive fallback for virtualized Outlook/Gmail layouts instead of relying only on fixed CSS/ARIA selectors.
- Outlook Web accepts both `outlook.office.com` and `outlook.office365.com`, probes focusable virtual-list rows, and retries the Inbox entry if the provider restores another pane after sign-in.
- Empty inboxes are detected separately from selector failures, and failures now include privacy-safe DOM counts (never message contents) to make provider UI changes diagnosable.

This release fixes the two portability/privacy problems that can occur when a previously-used project folder is copied to another computer:

1. **Personal data no longer lives inside the source folder.** Mail history, connected-account metadata, browser cookies/sessions, OAuth tokens, saved app passwords, AI keys and local settings are stored in the current OS user's private Mail Radar data directory.
2. **The Python virtual environment is device-local.** Copying the source folder to another PC no longer carries a broken `.venv` created on the original PC.
3. **No personal timetable is embedded in the distribution.** Calendar data is local to each user/device. Email-derived dates still appear automatically in Calendar.
4. **First Webmail scan is visible.** After login, the first mailbox read runs in a normal visible browser window for better cross-device compatibility. Background scans can then run headlessly.
5. **Browser runtime fallback is automatic.** The launcher prefers installed Edge/Chrome and can install Playwright Chromium if neither exists.
6. **Legacy cleanup/migration is automatic.** If an older version left `mail_radar.db`, `.browser_profiles`, `.secrets`, `.mail_radar_config.json`, or `.env` in the project folder, `launch.py` moves them to the private per-user data directory instead of leaving them in a folder you may share.

## Private data locations

Typical locations:

- Windows: `%LOCALAPPDATA%\MailRadar`
- macOS: `~/Library/Application Support/MailRadar`
- Linux: `~/.local/share/mail_radar`

To print the exact location:

```powershell
py show_local_data.py
```

You can copy/share the **source folder** without copying mailbox records or login sessions.

> Do not manually copy the private data directory to another person/device. Browser login sessions are intentionally device/user specific.

## Fastest startup

Python 3.10+ is required; Python 3.12 is recommended.

From the extracted `mail_radar` folder:

```powershell
py launch.py
```

The launcher automatically:

- creates/reuses a device-local virtual environment;
- installs dependencies;
- checks `tzdata`;
- applies the pure-Python SQLAlchemy fallback on Windows if Application Control blocks the native extension;
- detects Edge/Chrome or installs Playwright Chromium as fallback;
- runs environment diagnostics;
- starts Mail Radar at `http://127.0.0.1:8000`.

## Connecting mailboxes

### Recommended: Connect Webmail

Choose **Connect Webmail**, select/auto-detect the provider, then sign in on the provider's own page. Mail Radar does not ask for your webmail password.

Built-in provider presets include Microsoft 365 / Outlook, Gmail / Google Workspace, Yahoo, AOL, iCloud, QQ, 163, 126, Zoho, Fastmail, Proton, Yandex, GMX, mail.com, plus Custom Webmail.

The first scan is visible for compatibility. Later background scans run automatically. If a provider redesign breaks its normal selector, Mail Radar automatically tries adaptive row detection first; **Visible sync** and **Reconnect** remain recovery options.

### Advanced connectors

Microsoft Graph, Gmail API, and IMAP remain available as fallbacks. API connectors are usually more stable than browser scraping when an organization allows them.

## Calendar

Mail Radar automatically adds email notices with recognizable event dates/deadlines to the Calendar. Clicking an event shows date/time, location, details, source mailbox/sender and source URL when available.

This distribution intentionally contains **no user's private class timetable**. Each installation starts with an empty local timetable unless events are learned/imported on that device.

## DeepSeek second-pass review

Rules handle clear notices first. Ambiguous/high-impact notices can be reviewed by DeepSeek. The saved API key is stored in the device-local encrypted vault, outside the source tree. Personal identifiers are redacted before LLM review unless raw sending is explicitly enabled.

## Reset this device's Mail Radar data

Stop Mail Radar, then run:

```powershell
py reset_local_data.py
```

Type `DELETE` when prompted. This clears mail history, connected accounts, browser sessions, tokens and saved local settings for the current OS user. The device-local Python environment is kept so the next launch is fast.

## Sharing the project safely

The safest way to create a source ZIP is:

```powershell
py export_clean_source.py
```

It creates `mail_radar_clean_source.zip` and excludes runtime/private artifacts.

## Troubleshooting another PC

If Webmail login works but reading does not:

1. Use **Visible sync** once.
2. Keep the inbox visible and wait for the scan to finish.
3. Use **Reconnect** if the login session expired.
4. Run `py launch.py` again so browser/runtime checks can repair the environment.
5. If it still fails, copy the `Diagnostics:` portion of the error (it contains DOM counts, not message contents) when reporting the issue.
6. If browser scraping remains incompatible with a provider redesign, switch that mailbox to the provider's API/IMAP advanced connector where available.

Browser automation is best-effort because third-party mail sites can change their HTML/UI. Mail Radar never assumes a browser session is portable between computers.

## Developer tests

```powershell
py -m pytest -q
```

Tests use an isolated temporary `MAIL_RADAR_DATA_DIR` and do not touch your real mailbox database or browser sessions.
