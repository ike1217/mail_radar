from __future__ import annotations

import importlib
import os
import platform
import sqlite3
import sys
from pathlib import Path

from app.paths import browser_profiles_dir, secrets_dir, user_data_dir

CORE = {
    'fastapi': 'fastapi',
    'uvicorn': 'uvicorn',
    'sqlalchemy': 'sqlalchemy',
    'pydantic-settings': 'pydantic_settings',
    'beautifulsoup4': 'bs4',
    'requests': 'requests',
    'cryptography': 'cryptography',
    'playwright': 'playwright',
}

OPTIONAL = {
    'msal (Microsoft Graph advanced connector)': 'msal',
    'openai SDK (DeepSeek second-pass review)': 'openai',
    'google-api-python-client (Gmail API advanced connector)': 'googleapiclient',
    'google-auth (Gmail API advanced connector)': 'google.auth',
    'google-auth-oauthlib (Gmail API advanced connector)': 'google_auth_oauthlib',
}


def _check_writable(path: Path, label: str) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / '.write_test'
        probe.write_text('ok', encoding='utf-8')
        probe.unlink(missing_ok=True)
        print(f'[ OK ] {label}: {path}')
        return True
    except Exception as exc:
        print(f'[FAIL] {label}: {exc}')
        return False


def check() -> int:
    print('Mail Radar environment check')
    print('============================')
    print(f'Python:      {sys.version.split()[0]}')
    print(f'Platform:    {platform.platform()}')
    print(f'Source:      {Path.cwd()}')
    print(f'Private data:{user_data_dir()}')

    if sys.version_info < (3, 10):
        print('[FAIL] Python 3.10+ is required. Python 3.12 is recommended on Windows.')
        return 1

    missing_core = []
    for package, module in CORE.items():
        try:
            importlib.import_module(module)
            print(f'[ OK ] {package}')
        except Exception as exc:
            print(f'[FAIL] {package}: {type(exc).__name__}: {exc}')
            missing_core.append(package)
    if missing_core:
        print('\nMissing/broken core dependencies: ' + ', '.join(missing_core))
        return 2

    print('\nOptional / advanced features')
    for package, module in OPTIONAL.items():
        try:
            importlib.import_module(module)
            print(f'[ OK ] {package}')
        except Exception:
            print(f'[WARN] {package} is unavailable. Core Webmail Login still works.')

    try:
        from zoneinfo import ZoneInfo
        print(f"[ OK ] IANA timezone data: {ZoneInfo('Asia/Hong_Kong').key}")
    except Exception as exc:
        print(f'[FAIL] Timezone data: {type(exc).__name__}: {exc}')
        return 3

    try:
        import sqlalchemy
        print(f'[ OK ] SQLAlchemy import: {sqlalchemy.__version__}')
    except Exception as exc:
        print(f'[FAIL] SQLAlchemy import: {exc}')
        return 4

    if not _check_writable(user_data_dir(), 'Private data directory'):
        return 5
    if not _check_writable(secrets_dir(), 'Secret vault directory'):
        return 6
    if not _check_writable(browser_profiles_dir(), 'Browser profile directory'):
        return 7

    try:
        conn = sqlite3.connect(':memory:')
        conn.execute('select 1')
        conn.close()
        print('[ OK ] SQLite')
    except Exception as exc:
        print(f'[FAIL] SQLite: {exc}')
        return 8

    print('\nEnvironment looks ready. Personal mail data is device-local and outside the source folder.')
    return 0


if __name__ == '__main__':
    raise SystemExit(check())
