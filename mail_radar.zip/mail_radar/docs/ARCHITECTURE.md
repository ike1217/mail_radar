# Mail Radar v7.3 architecture

## Device-local privacy boundary

The source directory contains code only. Runtime state is resolved through `app.paths` into a per-OS-user data directory:

```text
Windows  %LOCALAPPDATA%\MailRadar
macOS    ~/Library/Application Support/MailRadar
Linux    ~/.local/share/mail_radar
```

That directory contains the SQLite database, browser profiles/cookies, token caches, encrypted credential vault, local settings, and the device-local Python environment. Copying the source tree to another computer therefore does not copy mailbox history or authentication state.

`MAIL_RADAR_DATA_DIR` can override this path for tests/advanced deployments.

## Ingestion

Multiple mailbox accounts feed one pipeline. The primary connector is browser-session webmail; Microsoft Graph, Gmail API, and IMAP are optional advanced connectors.

Browser-session behavior:

1. User signs in on the provider's own page.
2. Session lives only in that device/user's private browser profile directory.
3. The initial mailbox scan is visible for cross-device/UI compatibility.
4. Background sync may run headlessly.
5. If a provider redesign breaks headless extraction, the UI exposes Visible sync and Reconnect.

## Processing

```text
raw message
→ content cleanup
→ digest segmentation
→ local classification + field extraction
→ optional privacy-filtered DeepSeek review
→ ranking
→ device-local Notice database
```

## Calendar

The calendar merges:

1. locally stored `TimetableEvent` rows created/imported by that installation; and
2. `Notice` rows with `event_date` and/or `deadline`.

The distribution does **not** seed a private timetable. Email-derived dates appear automatically. When an email has a date but no explicit clock time, Calendar returns `all_day=true` and the UI displays `Time not specified`.

Endpoints:

```text
GET /api/calendar/events
GET /api/timetable
```

## Portability and legacy migration

`launch.py` stores the virtual environment outside the source tree so a copied project never reuses a machine-specific `.venv` from another PC.

When upgrading from <=7.0, the launcher detects and moves legacy project-local private files (`mail_radar.db`, `.browser_profiles`, `.secrets`, `.mail_radar_config.json`, `.env`) into the current user's private data directory. Existing destinations are never overwritten; conflicts are preserved in a timestamped backup.

## Reliability

- `tzdata` is installed/checkable on Windows and minimal Python environments.
- `get_timezone()` falls back safely to UTC.
- Windows SQLAlchemy DLL-policy failures fall back to the pure-Python build.
- Edge/Chrome are preferred for Webmail Login; Playwright Chromium is installed as a fallback when no supported system browser is detected.
- The initial Webmail scan is visible to reduce device/layout-dependent headless failures.
